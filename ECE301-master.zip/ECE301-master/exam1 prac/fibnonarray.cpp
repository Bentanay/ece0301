#include <iostream>
#include <mgl2/mgl.h>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;

int fib(int);

int main(){
	
	
	int num;
	cin >> num;
	
	
	
	cout << fib(num);
	
	return 0;
	
	
}

int fib(int num){
	
	int fibber,index1 =  0, index2 =1, temp;
	
	if(num==1){
		return 0;
	}else if(num==2){
		return 1;
	}
	
	else {
	for(int i = 2; i < num; i++ ){
		
		fibber = index1 + index2; 
		
		temp = index2; 
		index2  = fibber; 
		index1 = temp;
			
	}
}
	
	return fibber;
}

