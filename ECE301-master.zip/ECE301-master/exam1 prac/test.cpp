#include <iostream>
#include <mgl2/mgl.h>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;

int fib(int , int[]);

int main(){
	
	
	int num;
	cin >> num;
	
	int array[num];
	array[0] = 0;
	array[1] = 1;
	
	cout << fib(num,array);
	
	return 0;
	
	
}

int fib(int num,int array[]){
	
	if( num == 1){
		return 1;
	}else if(num == 0){
		return 0;
	}
	else{
	
	
	for(int i = 2; i < num; i++ ){
		
		array[i] = array[i-1] + array[i-2];
	}
	
	}
	
	return array[num-1];
}
