#include <iostream>
#include <mgl2/mgl.h>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;

int fib(int );

int main(){
	
	
	int num;
	cin >> num;
	
	
	cout << fib(num);
	
	return 0;
	
	
}

int fib(int num){
	
	int fibber;
	
	if(num == 1)
		return  0;
	else if(num==2)
		return 1;
	else{
		fibber = fib(num-1) + fib(num-2);
		return fibber;
	}
	
	

}
