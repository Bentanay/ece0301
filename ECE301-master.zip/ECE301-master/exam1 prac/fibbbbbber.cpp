
#include <iostream>
#include <mgl2/mgl.h>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;

int fibber(int);

int main(){
	int num;
	cin >> num;
	
	cout << fibber(num);
	
	return 0;
}


int fibber(int N){
	
	int fibberrr;
	
	if(N==1){
		return 0;
	}else if(N ==2){
		return 1;
	}
	else{
		
		fibberrr = fibber(N-1) + fibber(N-2);
		return fibberrr;
	}
	
	
	
}


 
