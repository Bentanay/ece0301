#include <iostream>
#include <mgl2/mgl.h>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;

int totalhand(int);

int main(){
	
	int nummer;
	cin >> nummer;
	
	cout << totalhand(nummer);
	
	return 0;
}

int totalhand(int num){
	
	int totalnum =0 ;
	
	if(num == 1){
		return 0;
	}
	else{
		
		totalnum += num-1 + totalhand(num-1);
		return totalnum;
	}
	
	
	
}
