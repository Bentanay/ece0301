#include <iostream> //For use of cin and cout.
#include <string>  //For use of the string class.
using namespace std;

/* 
Background: The following are propositions, i.e. statements that are objectively true or false: 
P1 Pigs can fly.
P2 Earth is flat.
P3 The moon is cheese.
We will refer to these as elementary propositions, because they cannot be divided into phrases or clauses, each of which 
is also a proposition. By contrast, a compound proposition is composed of two or more propositions, 
such as:
Pigs can fly, and the moon is not cheese.
Clearly, the truth value of a compound proposition depends on the truth values of the elementary propositions from which it is formed. 
In this assignment, you will write a program that evaluates and displays the truth values for 8 compound propositions, given the truth 
values of the elementary propositions.
*/

int main()
{
	//Printing out Intro Message.
	cout << "ECE 301 Propositional Logic Example" << endl << endl;
	
	//Declaring 3 string variables for storing proposition 1, 2, and 3.
	string prop1 = "Pigs can fly.", prop2 = "Earth is flat.", prop3 ="The moon is cheese.";
	
	//Printing out each proposition on a newline. 
	cout << "P1: " << prop1 << endl;
	cout << "P2: " << prop2 << endl;
	cout << "P3: " << prop3 << endl << endl;
	
	//Declaring 3 boolean varibales to store the truth values of the propisition.
	bool prop1bool, prop2bool, prop3bool;
	
	cout << "Enter P1 truth value: ";
	cin >> prop1bool; //Prompting and storing the truth value for proposition1. 
	
	cout << "Enter P2 truth value: ";
	cin >> prop2bool; //Prompting and storing the truth value for proposition2. 
	
	cout << "Enter P3 truth value: ";
	cin >> prop3bool; //Prompting and storing the truth value for proposition3. 
	
	
	//Displaying what the user entered.
	cout << endl<<boolalpha << "You entered: P1 = " << prop1bool << ", P2 = " << prop2bool << ", P3 = " << prop3bool << "." << endl << endl;
	
	bool prop4bool; //Declaring variable to store the truth value of propisition 4.
	prop4bool = prop1bool && !prop2bool && prop3bool; //Assigning the truth condition for proposition 4. 
	
	//Outputting the truth table to terminal. Boolalpha displays true or false instead of 0 or 1.
	cout << "Truth table:\n";
	cout << "Proposition\tTruth Value\n";
	cout << "-----------\t-----------\n";
	cout << "P1\t\t" <<boolalpha<<prop1bool <<endl;
	cout << "P2\t\t" <<boolalpha<<prop2bool <<endl;
	cout << "P3\t\t" <<boolalpha<<prop3bool <<endl;
	cout << "P4\t\t" <<boolalpha<<prop4bool <<endl;
	
	//Declaring proposition 5 boolean to store the truth value for proposition 5 and assigning it the truth condition. 
	bool prop5bool = !prop1bool || prop2bool || prop3bool;
	
	cout << "P5\t\t" <<boolalpha<<prop5bool <<endl; //Printing out the truth value of proposition 5. 
	
	//Declaring proposition 6 boolean to store the truth value for proposition 6 and assigning it the truth condition. 
	//prop6bool is marked true if one of them is true because it will only add up to one if one of them is true.
	bool prop6bool = (prop1bool + prop2bool + prop3bool) == 1;
	
	//Declaring proposition 7 boolean to store the truth value for proposition 7 and assigning it the truth condition. 
	//it will only evaluate to 0 if all of them are false.
	bool prop7bool = (prop1bool + prop2bool + prop3bool) == 0;
	
	//Declaring proposition 8 boolean to store the truth value for proposition 8 and assigning it the truth condition. 
	//It will only evaluate to true if 2 or more are true, and it will only be greater or equal to 2 if two or more are true.
	bool prop8bool = (prop1bool + prop2bool + prop3bool) >= 2;
	
	//Declaring proposition 9 boolean to store the truth value for proposition 9 and assigning it the truth condition. 
	//It will only be true if p1 is false, and only 1 (prop2 or prop3) is true, and if thats the case than it would be equivalent to 1 and the whole
	//expression gets marked as true.
	bool prop9bool = !prop1bool && ((prop2bool + prop3bool) ==1);
	
	
	cout << "P6\t\t" <<boolalpha<<prop6bool <<endl; //Printing out the truth value of proposition 6. 
	cout << "P7\t\t" <<boolalpha<<prop7bool <<endl; //Printing out the truth value of proposition 7. 
	cout << "P8\t\t" <<boolalpha<<prop8bool <<endl; //Printing out the truth value of proposition 8. 
	cout << "P9\t\t" <<boolalpha<<prop9bool <<endl; //Printing out the truth value of proposition 9. 
	
	
	return 0; 
}

