
#include <iostream>
#include <mgl2/mgl.h>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;


////////////////////START CLASS DECLARATION//////////////////////////////////
////////////////////START CLASS DECLARATION//////////////////////////////////
////////////////////START CLASS DECLARATION//////////////////////////////////

class SortableArray{
	private: 
		double *aptr; //pointer for a double
		unsigned int SIZE; //int variable for number of elements in the array
	public:
		SortableArray(); //constructor
		SortableArray(unsigned int); //overloaded constructor that accepts int parameter
		~SortableArray(); //destructor
		int getlength();
		void initzero(); //intialzing the arrays to zeros
		double * getptr(); //returns the pointer
		void printdata(ofstream &, bool); //printing the data to the file
		void mergesub(double *, double *, unsigned int, unsigned int, unsigned int);//merges two subarrays
};

//constructor function
SortableArray::SortableArray(){
			
	aptr = new double[10]; //allocates memory for an array with 10 elements 
	SIZE = 10; //sets size equal to ten
	initzero(); //initializing the array to zero
	
}


//overloaded constructor that accepts int parameter
SortableArray::SortableArray(unsigned int num){
	
	SIZE = num; //sets size to num
	aptr = new double[SIZE]; //allocates space for that array
	initzero();  //initalizing the array with all zeros. 
	
	
}

//decstructor function
SortableArray::~SortableArray(){
	
	delete aptr; //deletes the pointer
	
}

int SortableArray::getlength(){
	
	
	return SIZE; //returns the size
	
}

//function for initialzing the array with zeros
void SortableArray::initzero(){
	
	//for loop for putting zeros in every element of the array 
	for(int i =0; i<SIZE; i++ ){
		
		*(aptr + i) = 0;
	}
	
	
}

//function that gets the pointer
double * SortableArray::getptr(){
	
	return aptr; //returns the pointer.
	
}


//function that prints the data out
void SortableArray::printdata(ofstream &textout, bool type){
	
	
	if(!type){
		//printing the data.
		textout << "ECE 0301 - Sorting Arrays" << endl;
		textout << "Unsorted Array:" << endl;
		
		//prints out each element of the array using a for loop
		for(int i = 0; i < SIZE; i++){
			
			//printing each element on each line
			textout << *(aptr + i) << endl;
			
		}
	}
	else{
		//printing the title.
		textout << "Sorted Array:" << endl;
		
		//prints out each element of the array using a for loop
		for(int i = 0; i < SIZE; i++){
			
			//printing each element on each line
			textout << *(aptr + i) << endl;
			
		}
	}

}

//function that merges two subarrays
void SortableArray::mergesub(double *prearr, double *postarr, unsigned int num, unsigned int start, unsigned int end){
	
	//INITALIZING ALL THE POINTERS
	double *blackptr = prearr + start; //start of pre merge array
	double *grayptr  = prearr+num; //start of second array
	double *redptr = prearr+num; //start of second array reference
	double *blueptr = prearr + end; //end of second array
	double *greenptr = postarr + start; //start of beginning of postmerge array
	
	//while black is less than red pointer and gray pointer is less than blue
	while(blackptr < redptr && grayptr < blueptr){
		//if the value in blackptr is less than the value gray
		if(*blackptr < *grayptr){
			//setting it over to the post merge array
			*greenptr = *blackptr;
			//incrementing both black and green pointers
			blackptr++;
			greenptr++;
		} else{
			//setting it over to the post merge array
			*greenptr = *grayptr;
			//incrementing both gray and green ptr
			grayptr++;
			greenptr++;
			
		}
				
		
	}
	
	//filling in the rest of the green array but checking which array hasnt been completed yet. 
	while(blackptr<redptr){
		//setting it over to post merge array and incrememnting both until the end of the array is reached
		*greenptr = *blackptr;
		greenptr++;
		blackptr++;
	}
	while(grayptr < blueptr){
		//setting it over to post merge array and incrememnting both until the end of the array is reached
		*greenptr = *grayptr;
		greenptr++;
		grayptr++;
		
	}
	

}

////////////////////END CLASS DECLARATION//////////////////////////////////
////////////////////END CLASS DECLARATION//////////////////////////////////
////////////////////END CLASS DECLARATION//////////////////////////////////


//FUNCTION DECLARATORS STORED HERE//////////////////////////////
//FUNCTION DECLARATORS STORED HERE//////////////////////////////

SortableArray fileread(ifstream &); //prototype for file read function



//FUNCTION DECLARATORS STORED HERE//////////////////////////////
//FUNCTION DECLARATORS STORED HERE//////////////////////////////



//MAIN FUNCTION////////////////////////////////////////////////////
////////////MAIN FUNCTION////////////////////////////////////////////////////
//////////////////////MAIN FUNCTION////////////////////////////////////////////////////
int main(){
	
	ifstream textin("ece_0301_unsorted_array.txt"); //for reading the array data in
	
	SortableArray unsortarr = fileread(textin); //calling the constructor for the object
	
	
	ofstream textout("ece0301_merge_sort_results.txt"); //defining the ofstream object

	unsortarr.printdata(textout,false); //printing the data out
	
	//making a new object
	SortableArray sortarr = SortableArray(unsortarr.getlength());
	
	
	//calling the merge
	unsortarr.mergesub(unsortarr.getptr(),sortarr.getptr(),6,2,11);
	
	//reprinting out the array
	sortarr.printdata(textout, true);
	
	
	//closing the input and output files
	textin.close();
	textout.close();
	
	return 0;
}

SortableArray fileread(ifstream &textin){
	
	string line1, arraynumstr; //initializing variable to store line one. and store the size of the array
	int arraynum; //to store the string to int number for array size
	getline(textin, line1); //get the line and store it in the line1
	
	string line1substr = line1.substr(0,9); //extracing the beginning part of the line
	
	//making sure the file header is correct
	if(line1substr != "LENGTH = "){
		cout << "ERROR! Invalid input file header.";
		exit(-1);
	}
	
	
	arraynumstr = line1.substr(8,line1.length()); //getting the rest of the line
	arraynum = stoi(arraynumstr); //converting the string to an actual number
	
	SortableArray newarray = SortableArray(arraynum); //creating an object
	
	
	//settup for the for loop//
	string eachline; //using for storing each line.
	double eachlinenum; //using for converting the string to a double.
	double *ptr = newarray.getptr();
	
	
	for(int i =0; i < arraynum; i ++){
		
		//getting each line from the file and storing it in the next element of the array
		getline(textin, eachline);
		eachlinenum = stod(eachline);
		*(ptr+i) = eachlinenum;
		
		
	}
	

	
	return newarray; //returning the object
	
	
}



//MAIN FUNCTION////////////////////////////////////////////////////
////////////MAIN FUNCTION////////////////////////////////////////////////////
//////////////////////MAIN FUNCTION////////////////////////////////////////////////////

