
#include <iostream>
#include <mgl2/mgl.h>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;


//including the sortable array 
#include "SortableArray.cpp"




//FUNCTION DECLARATORS STORED HERE//////////////////////////////
//FUNCTION DECLARATORS STORED HERE//////////////////////////////

SortableArray fileread(ifstream &); //prototype for file read function



//FUNCTION DECLARATORS STORED HERE//////////////////////////////
//FUNCTION DECLARATORS STORED HERE//////////////////////////////



//MAIN FUNCTION////////////////////////////////////////////////////
////////////MAIN FUNCTION////////////////////////////////////////////////////
//////////////////////MAIN FUNCTION////////////////////////////////////////////////////
int main(){
	
	SortableArray array = SortableArray(256); //creating an object with 256 elements
	
	array.random(-1,1); //filling the array with random numbers
	
	
	ofstream textout("ece0301_merge_sort_results.txt"); //defining the ofstream object

	array.printdata(textout,false); //printing the data out
	
	
	array.mergesort(); //calling the complete merge sort function
	
	
	array.printdata(textout, true); //print the sorted data out.
	
	
	//closing the output file
	textout.close();
	
	return 0;
}

SortableArray fileread(ifstream &textin){
	
	string line1, arraynumstr; //initializing variable to store line one. and store the size of the array
	int arraynum; //to store the string to int number for array size
	getline(textin, line1); //get the line and store it in the line1
	
	string line1substr = line1.substr(0,9); //extracing the beginning part of the line
	
	//making sure the file header is correct
	if(line1substr != "LENGTH = "){
		cout << "ERROR! Invalid input file header.";
		exit(-1);
	}
	
	
	arraynumstr = line1.substr(8,line1.length()); //getting the rest of the line
	arraynum = stoi(arraynumstr); //converting the string to an actual number
	
	SortableArray newarray = SortableArray(arraynum); //creating an object
	
	
	//settup for the for loop//
	string eachline; //using for storing each line.
	double eachlinenum; //using for converting the string to a double.
	double *ptr = newarray.getptr();
	
	
	for(int i =0; i < arraynum; i ++){
		
		//getting each line from the file and storing it in the next element of the array
		getline(textin, eachline);
		eachlinenum = stod(eachline);
		*(ptr+i) = eachlinenum;
		
		
	}
	

	
	return newarray; //returning the object
	
	
}



//MAIN FUNCTION////////////////////////////////////////////////////
////////////MAIN FUNCTION////////////////////////////////////////////////////
//////////////////////MAIN FUNCTION////////////////////////////////////////////////////


