
#include <iostream>
#include <mgl2/mgl.h>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>
#include <ctime> 
#include <cstdlib>

using namespace std;



int main(){
	
	
	
	srand(time(0));
	for( int i = 0; i < 20; i++){
		
		
		
		
		
		double rand1 = static_cast<double>(rand()) / RAND_MAX;
		double rand2 = 2*rand1 - 1;
		cout << rand2 << endl;
		
		
	}
	
	
	
	
	return 0;
}
