
#ifndef SORTABLEARRAY_H
#define SORTABLEARRAY_H
#include <fstream> 
using namespace std;


//sortable Array class declaration
class SortableArray{
	private: 
		double *aptr; //pointer for a double
		unsigned int SIZE; //int variable for number of elements in the array
		void mergesub(double *, double *, unsigned int, unsigned int, unsigned int);//merges two subarrays
		void splitarr(double *, double *, unsigned int, unsigned int); //spilts an array into two subarrays
	public:
		SortableArray(); //constructor
		SortableArray(unsigned int); //overloaded constructor that accepts int parameter
		~SortableArray(); //destructor
		int getlength();
		void initzero(); //intialzing the arrays to zeros
		double * getptr(); //returns the pointer
		void printdata(ofstream &, bool); //printing the data to the file
		void mergesort();//THE COMPLETE MERGE SORT FUNCTION
		void random(int, int); //fills the array with random numbers
};

#endif
