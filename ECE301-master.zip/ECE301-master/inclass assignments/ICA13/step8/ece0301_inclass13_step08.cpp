#include "Signal.cpp"
#include "Lhdeccic.cpp"
#include "Folhdeccic.cpp"
#include <iostream>

using std:: cout;
using std:: endl;
using std:: string;
using std:: ofstream;
using std:: vector;

int main(){

	ofstream out("ECE 0301 - Differential Equation Reports.txt");
	Folhdeccic obj = Folhdeccic(2,-1.25,120);
	obj.setlabel("x");
	obj.printinfo(out);
	obj.writesolution(out);

	out.close();

	return 0;
}
