#include "Folhdeccic.h"

//calling default constructor of the base class
Folhdeccic::Folhdeccic():Lhdeccic::Lhdeccic(){
	fillsolutionsig();
}

//calling overloarding constructor for the base class and passing the values in
Folhdeccic::Folhdeccic(double bset, double iset, double kset):Lhdeccic::Lhdeccic(bset, iset, kset){
	fillsolutionsig();
}

//virtual function for getting the differential equation
string Folhdeccic::getdiffequation() const{
	//checking whether b is positive or negative and printing out with the correct sign
	if(getb() > 0)
		return getlabel() + "\'(t) + " + textNum(getb()) + " " + getlabel() + "(t) = 0";
	else
		return getlabel() + "\'(t) - " + textNum(-1*getb()) + " " + getlabel() + "(t) = 0";

}

//virtual function for printing out the information to a file
void Folhdeccic::printinfo(ofstream &out) const{
	//printing out header and then the equation
	out << "---------------------------------" << endl;
	out << "First-Order Differential Equation" << endl;
	out << "---------------------------------" << endl;
	out << getdiffequation() << endl << endl; //gets the differential Equation
	out << "Initial Condition" << endl;
	out << "-----------------" << endl;
	out << getic() << endl << endl; //prints out initial conditions satement



}

//function for printing out the initial condition
string Folhdeccic::getic() const{
		return getlabel() + "(" + textNum(geti0()) + ") = " + textNum(getk0());
}

//function for filling the solution signal with values
void Folhdeccic::fillsolutionsig(){
	Signal *ptr = getsignalptr(); //declaring a signal pointer
	ptr -> setnSamples(501); //setting samples
	ptr -> setFrequency(100.0 / (1.0/getb())); //setting samp freq
	ptr -> setiTime(geti0()); //setting initial time
	ptr -> fillExpon(1.0/getb(),getk0()); //filling the signal with an exponential
	ptr -> roundsig(); //for rounding the signal to integer values
}


///////////////////////////ACCESSOR FUNCTIONS///////////////////////////////////////////////////////////
void Folhdeccic::firstsetb(double bset){
	setb(bset);
	fillsolutionsig(); //call to refill the solution signal

} //for setting b


void Folhdeccic::firstseti0(double iset){
	seti0(iset);
	fillsolutionsig(); //call to refill the solution
} //for setting io


void Folhdeccic::firstsetk0(double kset){
	setk0(kset);
	fillsolutionsig(); //call to refill the solution
} //for setting k0
