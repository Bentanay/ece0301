#include "Signal.cpp"
#include "Lhdeccic.cpp"
#include "Folhdeccic.cpp"
#include "Solhdeccic.cpp"
#include <iostream>

using std:: cout;
using std:: endl;
using std:: string;
using std:: ofstream;
using std:: vector;

int main(){

	//declaring an ofstream and opening it for writing
	ofstream out("ECE 0301 - Differential Equation Reports.txt");
	
	
	Solhdeccic obj1 = Solhdeccic(101,-5,100,-100,2);
	obj1.setlabel("g");
	obj1.printinfo(out);
	obj1.writesolution(out);
	
	
	
	
	

	out.close(); //closing the output file

	return 0;
}
