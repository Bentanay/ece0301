#include "Solhdeccic.h"

////////////////CONSTRUCTORS/////////////////////////////////////
//default constructor
Solhdeccic::Solhdeccic():Lhdeccic::Lhdeccic(2,0,0){
  seta(3);
  setk1(1);
  setlabel("y");
  fillsolutionsig();
}

//overloaeded constructor
Solhdeccic::Solhdeccic(double bset,double iset,double k0set,double k1set ,double aset):Lhdeccic::Lhdeccic(bset,iset,k0set){
  seta(aset);
  setk1(k1set);
  setlabel("y");
  fillsolutionsig();
}

////////////////GETTERS/////////////////////////////////////
//getting the coefficient a
double Solhdeccic::geta() const{
  return a;
}
//getting the initial value for the derivative
double Solhdeccic::getk1() const{
    return k1;
}

//getting a string for the initial conditions
string Solhdeccic::getdiffequation() const{
  string str; //declaring a string for storing the return string
  //if structor for determining which statement to print based on the signs of a and b
  if(geta() >= 0 && getb()>= 0 ) //both positive
   str =getlabel() + "\'\'(t) + " + textNum(geta()) + " " + getlabel() + "\'(t) + " + textNum(getb()) + " " + getlabel() + "(t) = 0";
  else if(geta()>= 0 && getb() < 0) //b is neg
    str =getlabel() + "\'\'(t) + " + textNum(geta()) + " " + getlabel() + "\'(t) - " + textNum(-1*getb()) + " " + getlabel() + "(t) = 0";
  else if(geta() < 0 && getb() >= 0) //a is neg
    str =getlabel() + "\'\'(t) - " + textNum(-1*geta()) + " " + getlabel() + "\'(t) + " + textNum(getb()) + " " + getlabel() + "(t) = 0";
  else //both are neg
    str =getlabel() + "\'\'(t) - " + textNum(-1*geta()) + " " + getlabel() + "\'(t) - " + textNum(-1*getb()) + " " + getlabel() + "(t) = 0";

   return str;
}

//for getting the initial conditions
string Solhdeccic::getic() const{
  //returning the string with all the initial conditions printed out
  return getlabel() + "(" + textNum(geti0()) + ") = " + textNum(getk0()) + ", " + getlabel() + "\'(" + textNum(geti0()) + ") = " + textNum(getk1());
}

////////////////SETTERS/////////////////////////////////////
//setting the coefficient a
void Solhdeccic::seta(double aset){
  a = aset;
}
//setting the initial value for the derivative
void Solhdeccic::setk1(double k1set){
  k1 = k1set;
}


////////////////OTHER FUNCTIONS/////////////////////////////////////
//function for printing out the info to a text file
void Solhdeccic::printinfo(ofstream &out) const{
  out << "----------------------------------" << endl;
	out << "Second-Order Differential Equation" << endl;
	out << "----------------------------------" << endl;
	out << getdiffequation() << endl << endl; //gets the differential Equation
	out << "Initial Condition" << endl;
	out << "-----------------" << endl;
	out << getic() << endl << endl; //prints out initial conditions satement
}
//functiion for filling the solution signal with values
void Solhdeccic::fillsolutionsig(){

  Signal *ptr = getsignalptr(); //declaring a signal pointer for the first exponential

  ptr -> setnSamples(501); //setting samples
  ptr -> setiTime(geti0()); //setting initial time


  double root1,root2; //for storing the solution to the quadratic
  double tao; //for storing the greater time constant
  double c1, c2; //determining the coefficients of the solution to the overdamped case


  //using quadratic formula to solve for the roots.
  root1 = -1*geta()/2.0 + sqrt(pow(geta(),2) - (4*getb()))/2.0;
  root2 = -1*geta()/2.0 - sqrt(pow(geta(),2) - (4*getb()))/2.0;

  //if statement for checking if there are two real roots or if there is a double root.
  if(pow(geta(),2) > 4*getb()){
    //if structure for determining which root to use for the time constant.
    if(root1 >= root2)
      tao = root1;
    else
      tao = root2;

    ptr -> setFrequency(100.0/fabs(tao)); //setting the sampling frequency

    //calculating the coefficients to the Equation
    c1 = (getk0()*root2 - getk1())/(root2 - root1);
    c2 = (-1*getk0()*root1 + getk1())/(root2 - root1);

    //filling the signal with exponential values corresponding to the first exponential in the equation
    ptr->fillExpon(fabs(1.0/root1),c1);

    Signal sig2; //declaring a signal for the second exponential
    sig2.setnSamples(501); //setting samples
    sig2.setiTime(geti0()); //setting initial time
    sig2.setFrequency(100.0/fabs(tao)); //setting the sampling frequency
    sig2.fillExpon(fabs(1.0/root2),c2); //filling the signal with exponential values

    *ptr = *ptr + sig2; //adding the two exponentials.
  }
  else if(pow(geta(),2) == 4*getb()){ //if there is a double root
    root1 = -1*geta()/2.0; //getting lamba one
    ptr -> setFrequency(100.0/(1.0/fabs(root1))); //setting the sampling frequency

    c1 = getk0(); //calculating the first constant
    c2 = getk1() + (getk0()*geta())/2.0; //calculating the second constant

    ptr -> fillLinear(c2, c1); //filling the signal with linear values

    Signal sig2 = Signal(501,(100.0/(1.0/fabs(root1))),geti0()); //declaring a signal to store the linear function
    sig2.fillExpon((1/fabs(root1)),1);

    *ptr = *ptr *sig2; //multiplying the two signals
  }
  else if(pow(geta(),2) < 4*getb()){
    root1 = geta() / 2.0; //for storing sigma
    root2 = sqrt(4*getb()-pow(geta(),2))/2.0; //for storing omega

    ptr -> setFrequency(100.0/(1.0/fabs(root1))); //setting the sampling frequency
    c1 = getk0();
    c2 = (getk1() - (root1*getk0()))/root2;

    ptr -> fillExpon(1.0/root1,1); //filling the solution signal with an exponential functions

    Signal sig2 = Signal(501,(100.0/(1.0/fabs(root1))),geti0()); //declaring a signal to store the sin function
    sig2.sinsignal(c1,(root2/(2*4*atan(1))),0); //filling it with a sinusoidual signal
    Signal sig3 = Signal(501,(100.0/(1.0/fabs(root1))),geti0()); //declaring a signal to store the sin function
    sig3.sinsignal(c2,(root2/(2*4*atan(1))),-4*atan(1)/2); //filling it with a sinusoidual signal

    *ptr = *ptr * (sig2+sig3); //setting the solution signal equal to the expression for the underdamped case.

  }

  ptr -> roundsig(); //rounding the solution signals to the nearest integer



}
