#ifndef SIGNAL
#define SIGNAL

#include <iostream>
#include <cmath>
#include <fstream>
#include <vector>
#include <string>

using std:: cout;
using std:: endl;
using std:: string;
using std:: ofstream;
using std:: vector;

class Signal{
	private:
		int nsamples; //for storing the number of samples
		double sampfreq; //for storing the sample frequency
		double itime; //for storing the inital time
		string label; //for storing the label of the signal
		string filename; //for storing the filename template
		string equation; //for storing the mathematical equation of the signal
		vector<double> sig; //for storing the signal array
		vector<double> time; //for storing the time array


	public:

		//cosntructors
		Signal(); //defualt constructor
		Signal(int, double, double); //overloaded constructor

		//mutators
		void setnSamples(int); //mutator for setting number of samples
		void setFrequency(double); //mutator for setting the sampling frequency
		void setiTime(double); //mutator for setting the inital time
		void setLabel(string); //mutator for setting the label.
		void setEquation(string); //mutator for setting the mathematical expression
		void fillTime(); //for filling the time array.
		void constsignal(double); //function for creating a constant signal
		void sinsignal(double, double, double); //function for filling the signal with a sine wave.
		void fillExpon(double,double); //function for filling the signal with an exponential functions
		void fillLinear(double,double); //function for filling the signal with a linear function



		//accessors
		int getnSamples() const; //getter for getting the num of smaples
		double getFrequency() const; //getter for getting the smapling frequencies
		double getiTime() const; //getter for getting the initial time
		string getLabel() const; //getter for getting the label
		string getFilename() const; //getter for getting the filename
		string getEquation() const; //getter for getting the equation
		vector<double> getSig() const; //getter for getting the signal vector
		vector<double> getTime() const; //getter for getting the time vector
		double getSig(unsigned int ) const; //getter for getting an index of the signal vector
		double getTime(unsigned int ) const; //getter for getting an index of the time vector

		//other
		void printinfo() const; //function for printing info out to a file.
		string textNum(double x) const; //function for converting a double to a string
		Signal & operator=( const Signal &); //function for copying signals over.
		void roundsig(); //function for rounding the signal.
		Signal operator+(const Signal &); //function for adding two signals
		Signal operator*(const Signal &); //function for multiplying two signals




};



#endif
