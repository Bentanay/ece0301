

#ifndef SOLHDECCIC_H
#define SOLHDECCIC_H


class Solhdeccic:public Lhdeccic{

	private:
		double a;
		double k1;

	public:
		//CONSTRUCTORS
		Solhdeccic(); //default constructor
		Solhdeccic(double,double,double,double,double); //overloaeded constructor

		//getters
		double geta() const; //getting the coefficient a
		double getk1() const; //getting the initial value for the derivative
		virtual string getdiffequation() const; //getting a string for the initial conditions
		virtual string getic() const; //for getting the initial conditions

		//setters
		void seta(double); //setting the coefficient a
		void setk1(double); //setting the initial value for the derivative

		//other functions
		virtual void printinfo(ofstream &) const; //function for printing out the info to a text file
		//pure virtual function so it must be overridden
		virtual void fillsolutionsig(); //functiion for filling the solution signal with values

};


#endif
