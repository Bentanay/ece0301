#ifndef LHDECCIC_H
#define LHDECCIC_H

class Lhdeccic{

		private:

			double b; //parameter b
			double i0; //initial time
			double k0; //initial value
			string label; //for storing a string label
			Signal sig1; //signal object from the signal class

		public:
			//constructors
			Lhdeccic(); //default contructor
			Lhdeccic(double,double,double); //overloaded constructor


			//ascessor functions
			double getb() const; //for returning b
			double geti0() const; //for returning i0
			double getk0() const; //for returning k0
			string getlabel() const; //for getting the variable we are solving for
			Signal * getsignalptr(); //for getting the pointer to the signal object

			//mutatuor functions
			virtual void setb(double); //for setting b
			virtual void seti0(double); //for setting io
			virtual void setk0(double); //for setting k0
			virtual void setlabel(string); //fpr setting the variable we are solving for

			//other functions
			string textNum(double) const; //function for converting a double to a string
			//no definitions for these virtual functions.
			virtual string getdiffequation() const = 0; //function for returning the differential equation as a string
			virtual void printinfo(ofstream &) const = 0; //function for printing the information to a text file
			virtual string getic() const = 0; //function for printing out the initial condition
			virtual void fillsolutionsig() = 0; //function for filling the solution signal with values
			string getsolutionequation() const; //function for returning a text representation of the equation of the solution
			virtual void writesolution(ofstream &) const; //function that writes solution of a differentia equation to a text file


};



#endif
