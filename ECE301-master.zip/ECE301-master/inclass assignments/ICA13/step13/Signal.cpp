#include "Signal.h"


Signal::Signal(){

	setnSamples(101);
	setFrequency(100);
	setiTime(0);
	setLabel("x");
	setEquation(textNum(0));



}
Signal:: Signal(int n, double f, double t){
	setnSamples(n);
	setFrequency(f);
	setiTime(t);
	setLabel("x");
	setEquation(textNum(0));
}


//mutator for setting number of samples
void Signal::setnSamples(int n ){
	nsamples = n;
	sig.resize(nsamples); //resizing the vector
	time.resize(nsamples); //resizing the vector
	fillTime(); //refilling the time vector

}

//mutator for setting the sampling freq
void Signal::setFrequency(double f ){
	sampfreq = f;
	fillTime();

}

//mutator for setting the initial time.
void Signal::setiTime(double i ){
	itime = i;
	fillTime();

}

//getter for getting the num of smaples
int Signal::getnSamples() const{
	return nsamples;

}
//getter for getting the smapling frequencies
double Signal::getFrequency() const{
	return sampfreq;

}

//getter for getting the initial time
double Signal::getiTime() const{
	return itime;

}

//mutator for setting the label.
void Signal::setLabel(string str){

	label = str;
	filename = "diff_eqn_soln_" +label;

}

//getter for getting the label
string Signal::getLabel() const{
	return label;

}


//getter for getting the filename
string Signal::getFilename() const{
	return filename;

}

//getter for getting the equation
string Signal::getEquation() const{

	return equation;
}

//mutator for setting the mathematical expression
void Signal::setEquation(string str){
	equation = str;

}

//function for printing out the data to a text file.
void Signal::printinfo() const{
	//creating an ofstream object
	ofstream out(filename + ".txt");

	//printing the header to the file.
	out << "Time-Domain Signal Samples" << endl;
	out << "N = " << nsamples << endl;
	out << "fs = " << sampfreq << endl;
	out << "t0 = " << itime << endl;
	out << "Signal label: " << label << endl;
	out << "Mathematical expression" << endl;
	out << label << "(t) = " << equation << endl;

	//printing the data to the file.
	out << "Time and signal samples in .csv format" << endl;
	out << "t, " << label << "(t)" << endl;
	out << "-------" << endl;

	//for loop for looping through both vectors and printing it out to the file
	for(int i = 0; i < nsamples; i++){
		if(i != nsamples-1){
			out << time[i] << ", " << sig[i] << endl;
		}else{
			out << time[i] << ", " << sig[i];
		}
	}


	out.close(); //closing the output file


}

//getter for getting the signal vector
vector<double> Signal::getSig() const{
	return sig;

}
//getter for getting the time vector
vector<double> Signal::getTime() const{
	return time;
}

//getter for getting an index of the signal vector
double Signal::getSig(unsigned int s) const{

	return sig[s];

}

//getter for getting an index of the time vector
double Signal:: getTime(unsigned int t) const{

	return time[t];
}

//function for filling the time array.
void Signal::fillTime(){

	//for loop for looping through the array and storing the proper value returned by the equation in it.
	for(int i =0; i < nsamples ; i++){

		time[i] = itime + i/sampfreq;

	}

}



// Convert num->string for mathmatetical function
string Signal::textNum(double x) const{
	if (x >= 100)
		return std::to_string(int(x));		// Large nums trunc. as int
	else
	{
		// Small nums get 3 digits
		string x_exp = std::to_string(x);
		// return 4 characters, or 5 if x<0
		return x_exp.substr(0, 4 + (x<0));
	}
}


//function for creating a constant signal
void Signal::constsignal(double k){

	 //function for looping through the elements of the vector and storing k in each one.
	 for(int i =0; i < nsamples; i++){
		 sig[i] = k;
	 }

	 //setting the equation equal to a constant.
	 setEquation(textNum(k));

}

//function for copying signals over.
Signal & Signal::operator=( const Signal &obj){



	//assigning all of the members over and making sure there is no self assignment.
	if(this != &obj){
		nsamples = obj.nsamples;
		sampfreq = obj.sampfreq;
		itime = obj.itime;
		equation = obj.equation;
		sig = obj.sig;
		time = obj.time;

	}

	return *this;

}

//function for filling the signal with a sine wave.
void Signal::sinsignal(double amp, double freq, double phase){

	//storing the sinusoidual signals in the signal vector.
	for(int i =0; i < nsamples; i++){

		sig[i] = amp* cos(2*4*atan(1)* freq * time[i] + phase);
	}

	//declaring several strings for storing the different part of the equation
	string amplitude =  textNum(amp), omega = textNum(2*4*atan(1)*freq), phasestr;

	//if statement for deciding whether to include the plase or the minus sign in the phasor.
	if(phase < 0){
		phasestr = textNum(-1*phase);
		setEquation(amplitude + " " + "cos" + "( "  + omega + "t - " + phasestr + " )" );
	}
	else{
		phasestr = textNum(phase);
		setEquation(amplitude + " " + "cos" + "( "  + omega + "t + " + phasestr + " )" );
	}


}



//function for rounding the signal.
void Signal::roundsig(){

	//goes through the vector and rounds all the values.
	for(int i = 0; i < nsamples; i++){
		sig[i] = round(sig[i]);

	}

}

//function for adding two signals
Signal Signal::operator+(const Signal &obj){

	//checking if they have the same num samples, itime, and samp freq
	if(!(nsamples == obj.nsamples && itime == obj.itime && sampfreq == obj.sampfreq)){

		cout << "ERROR! Attempt to multiply incompatible signals.";
		exit(-1);
	}

	//declaring another object
	Signal temper(nsamples, sampfreq, itime);

	//for adding the signal vectors and setting the time over.
	for(int i = 0; i < temper.nsamples; i++){

		temper.sig[i] = sig[i] + obj.sig[i];
		temper.time[i] = time[i];

	}

	//sets the equation to the addition of the two.
	if(obj.equation.substr(0,1) == "-")
		temper.setEquation(equation + " - " + obj.equation.substr(1,obj.equation.length()));
	else
		temper.setEquation(equation + " + " + obj.equation);



	return temper;

}

//function for multiplying two signals
Signal Signal::operator*(const Signal &obj){

	//checking if they have the same num samples, itime, and samp freq
	if(!(nsamples == obj.nsamples && itime == obj.itime && sampfreq == obj.sampfreq)){

		cout << "ERROR! Attempt to multiply incompatible signals.";
		exit(-1);
	}

	//declaring another object
	Signal temper(nsamples, sampfreq, itime);

	//for adding the signal vectors and setting the time over.
	for(int i = 0; i < temper.nsamples; i++){

		temper.sig[i] = sig[i] * obj.sig[i];
		temper.time[i] = time[i];

	}

	//sets the equation to the addition of the two.
	temper.setEquation("( " +  obj.equation + " )( " + equation + " )");

	return temper;


}

//function for filling the signal with an exponential functions
void Signal::fillExpon(double tc,double A){

	//for loop for looping through the signal array
	for(int i =0; i < nsamples; i++){
		//filling it with the exponeitial

		sig[i] = A * exp(-1*(time[i]-itime)/tc);

	}

	//setting the equation the equation.
	//accounting for cases where the itime is zero or its a divide by one
	if(itime == 0 && tc == 1.0 ){ //itime is zero and its a divide by one
		setEquation(textNum(A) + " exp( -t )" );
	}

	else if(itime == 0 && tc != 1.0){ //itime is zero and it is not being divided by one

		setEquation(textNum(A) + " exp( -t / "  + textNum(tc) + " )" );


	}

	else if(itime != 0 && tc == 1.0){ //itime is not zero but its a divide by one

		if(itime < 0 ){ //for when itime is negative, adjusts the sign
			setEquation(textNum(A) + " exp( -(t + " + textNum(-1*itime)+") )");


		}
		else if(itime > 0 ){ //for when itime is negative, adjusts the sign
			setEquation(textNum(A) + " exp( -(t - " + textNum(itime)+ ") )");

		}
	}

	else{

		if(itime < 0 ){ //for when itime is negative, adjusts the sign
			setEquation(textNum(A) + " exp( -(t + " + textNum(-1*itime) +") / " + textNum(tc) + " )" );

		}
		else if(itime > 0 ){ //for when itime is negative, adjusts the sign
			setEquation(textNum(A) + " exp( -(t - " + textNum(itime) +") / " + textNum(tc) + " )" );
		}
	}

}
