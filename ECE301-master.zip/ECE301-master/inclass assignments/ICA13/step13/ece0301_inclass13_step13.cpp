#include "Signal.cpp"
#include "Lhdeccic.cpp"
#include "Folhdeccic.cpp"
#include "Solhdeccic.cpp"
#include <iostream>

using std:: cout;
using std:: endl;
using std:: string;
using std:: ofstream;
using std:: vector;

int main(){

	//declaring an ofstream and opening it for writing
	ofstream out("ECE 0301 - Differential Equation Reports.txt");

	//declaring a second order equation
	Solhdeccic obj2 = Solhdeccic(2,0,0,250,3);
	obj2.printinfo(out); //printing the info of the equation out
	obj2.writesolution(out); //printing out the solution


	out.close(); //closing the output file

	return 0;
}
