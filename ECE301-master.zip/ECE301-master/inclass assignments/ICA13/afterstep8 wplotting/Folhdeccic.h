

#ifndef FOLHDECCIC_H
#define FOLHDECCIC_H


class Folhdeccic:public Lhdeccic{

	private:

	public:

		//constructors
		Folhdeccic(); //default contstructor
		Folhdeccic(double,double,double); //overloarded constructo

		//other functions
		virtual string getdiffequation() const; //function for returning the differential equation as a string
		virtual void printinfo(ofstream &) const; //function for printing the information to a text file
		virtual string getic() const; //function for printing out the initial condition
		virtual void fillsolutionsig(); //function for filling the solution signal with values

		//accessors
		virtual void firstsetb(double); //for setting b
		virtual void firstseti0(double); //for setting io
		virtual void firstsetk0(double); //for setting k0



};


#endif
