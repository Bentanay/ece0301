#include "Signal.cpp"
#include "Lhdeccic.cpp"
#include "Folhdeccic.cpp"
#include "Solhdeccic.cpp"
#include <iostream>

using std:: cout;
using std:: endl;
using std:: string;
using std:: ofstream;
using std:: vector;

int main(){

	ofstream out("ECE 0301 - Differential Equation Reports.txt");
	
	Solhdeccic obj2;
	obj2.printinfo(out);
	obj2.writesolution(out);
	

	out.close();

	return 0;
}
