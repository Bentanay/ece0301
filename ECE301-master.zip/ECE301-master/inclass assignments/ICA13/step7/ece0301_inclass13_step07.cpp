#include "Signal.cpp"
#include "Lhdeccic.cpp"
#include "Folhdeccic.cpp"
#include <iostream>

using std:: cout;
using std:: endl;
using std:: string;
using std:: ofstream;
using std:: vector;

int main(){

	ofstream out("ECE 0301 - Differential Equation Reports.txt");
	Folhdeccic obj;
	obj.printinfo(out);
	obj.writesolution(out);

	Folhdeccic obj2 = Folhdeccic(10,-2.5,1);
	obj2.setlabel("x");
	obj2.printinfo(out);
	obj2.writesolution(out);

	out.close();

	return 0;
}
