#include "Lhdeccic.h"


//ACSESSOR FUNCTIONS//////////////////////////////////////////////////////////////////

//function for returning b
double Lhdeccic::getb() const{
	return b;
}

//function for returning io
double Lhdeccic::geti0() const{
	return i0;
}

//function for returning k0
double Lhdeccic::getk0() const{
	return k0;
}

//for getting the variable we are solving for
string Lhdeccic::getlabel() const{
	return label;
}


//for getting the pointer to the signal object
Signal * Lhdeccic::getsignalptr(){
	return &sig1;


}



///////MUTATOR FUNCTIONS//////////////////////////////////////////////////////////

//function for setting b
void Lhdeccic::setb(double set){
	 b= set;
}

//for setting initial time
void Lhdeccic::seti0(double set){
	i0 = set;
}

//for setting initial value
void Lhdeccic::setk0(double set){
	k0 = set;
}

void Lhdeccic::setlabel(string str){
	label = str;
	sig1.setLabel(str);
}

/////////////////CONSTRUCTORS////////////////////////////////
 //default contructor
Lhdeccic::Lhdeccic(){

	setb(1);
	seti0(0);
	setk0(1);
	setlabel("y");

}

 //overloaded constructor
Lhdeccic::Lhdeccic(double bset,double iset,double kset){


	setb(bset);
	seti0(iset);
	setk0(kset);
	setlabel("y");

}


//////////////////////////OTHER FUNCTIONS///////////////////////////////////////

//function for converting a double to a string
string Lhdeccic::textNum(double x) const{
	if (x >= 100)
		return std::to_string(int(x));		// Large nums trunc. as int
	else
	{
		// Small nums get 3 digits
		string x_exp = std::to_string(x);
		// return 4 characters, or 5 if x<0
		return x_exp.substr(0, 4 + (x<0));
	}

}

//function for returning a text representation of the equation of the solution
string Lhdeccic::getsolutionequation() const{
	return getlabel() + "(t) = " + sig1.getEquation();
}

//function that writes solution of a differentia equation to a text file
void Lhdeccic::writesolution(ofstream &out) const{
	out << "Solution" << endl << "--------" << endl << getsolutionequation() << endl << endl;
}








