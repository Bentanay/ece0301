//inlcuding preproccessor directives for executing main
#include <iostream>
#include <cmath>
#include <string>
using namespace std; 

//inclduing the class declaration and the memeber functions.
#include "Flashlight.h"
#include "Flashlight.cpp"


//MAIN FUNCTION
int main(){
	
	
	Flashlight flash1; //calling the constructor for a flashligh object.
	
	flash1.printdata(); //printing out the initial data.
	cout << endl;
	
	int choice = 0; //delcaring and initalzing choice to be zero. 
	
	//while loop for the menu
	while(choice !=4){
		
		//printing out the menu
		cout << endl <<"What would you like to do with the Flashlight?" << endl;
		cout << "(1) Change the battery voltage" << endl;
		cout << "(2) Change the bulb resistance" << endl;
		cout << "(3) Toggle the switch state" << endl;
		cout << "(4) Exit the program" << endl << endl;
		cout << "Your selection? ";
		//getting the choice from the user
		cin >> choice;
		
		//switch case for evaluating code to execute based on choice.
		switch(choice){
			case 1:
			
				double voltage; //delcaring voltage variable 
				
				//prompting and getting new battery voltage
				cout << "Enter the new battery voltage: ";
				cin >> voltage; 
				
				//setting and then reprinting the flashlight data.
				flash1.setBatVoltage(voltage); 
				flash1.printdata();
				break;
				
			case 2:
			
				double res; //delcaring resistance varibale
			
				//prompting and getting new resistance
				cout << "Enter the new bulb resistance";
				cin >> res;
				
				//setting and reprinting the flashlight data.
				flash1.setBulbRes(res);
				flash1.printdata();
				break;
				
				
			case 3:
				
				//flipping the switch on the flashlight and then reprinting the data
				flash1.toggleSwitch();
				flash1.printdata();
				break;
			
					
		}
	
	}
	
	
	return 0;
}
