#include <iostream> 
#include <string>
using namespace std;

//class declaration for NOTgate
class NOTgate{
	
	//private variables
	private:
		string inputlabel;
		bool logicval; 
	
	//public functions
	public: 
		void setInputLabel(string);
		void setLogicVal(bool);
		string getInputLabel();
		bool getLogicVal();
		string getOutputNodeLabel();
		bool getOutputNodeBool();
	

};

//setting the string passed in equal to the input label
void NOTgate::setInputLabel(string label){
	inputlabel = label;
}

//setting the boolean passed in equal to logicval.  
void NOTgate::setLogicVal(bool logic){
	logicval =logic;
}

//returning the label of the input node. 
string NOTgate::getInputLabel(){
	
	return inputlabel;
}

//returning the logic value going into the input. 
bool NOTgate::getLogicVal(){
	
	return logicval;
}

//returning the label for the output node. 
string NOTgate::getOutputNodeLabel(){
	
	//appending the not to the label
	return inputlabel + "_not";
}

//getting the output node 
bool NOTgate::getOutputNodeBool(){
	
	//returning the inverted bool val
	return !logicval;
	
}

int main(){
	
	string label, boolval; //declaring variables to store label and boolval
	NOTgate gate1;
	

	
	//diplaying program intro
	cout << "This program will simulate a not gate." << endl << endl;
	
	//Prompting and getting label for gate input.
	cout << "What is the label for the gate input? ";
	getline(cin, label); 
	
	//Prompting and getting the boolean value part .
	cout << "What is the logic value at the input (0/1)? ";
	getline(cin, boolval);
	bool boolvalnum = stoi(boolval);
	
	//calling the mutator functions to store the values. 
	gate1.setInputLabel(label);
	gate1.setLogicVal(boolvalnum);
	
	//printing out the not gate data.
	cout << "Here are the data on the not gate: " << endl;
    cout << "Input label: " << gate1.getInputLabel() << endl;
    cout << "Output label: " << gate1.getOutputNodeLabel() << endl;
    cout << "Logic value at input: " << gate1.getLogicVal() << endl;
    cout << "Logic value at output: " << gate1.getOutputNodeBool() <<endl;
	
	return 0;
}
