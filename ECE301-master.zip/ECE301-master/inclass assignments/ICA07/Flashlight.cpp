#include <iostream>
#include <cmath>
#include <string>
#include "Flashlight.h"
using namespace std; 

//constructor function for initalizing the battery voltage and bulb resistance and toggle state.
Flashlight::Flashlight(){
	
	batvoltage = 3.0; 
	bulbres = 100;
	switchything = false;
	
}

//function that sets the battery voltage
void Flashlight::setBatVoltage(double voltage){
	batvoltage = voltage;
}

//function that sets the bulb resistance
void Flashlight::setBulbRes(double res){
	bulbres = res;
}

//function that toggles that switchs state.
void Flashlight::toggleSwitch(){
	switchything = !switchything;
}


//function that gets the battery voltage
double Flashlight::getBatVoltage() const{
	return batvoltage;
}

//function that gets the bulb resistance
double Flashlight::getBulbRes() const{
	return bulbres;
}

//function that gets the toggle state of the switch
bool Flashlight::getToggleState() const{
	return switchything;
}

//function that calculates the current through the bulb
double Flashlight::getCurrent() const{
	return batvoltage/ bulbres;
}

//function that calculates the power disappated from the bulb.
double Flashlight::getPower() const{
	return pow(batvoltage,2)/bulbres;
}

//function that prints all of the flashlight data out.
void Flashlight::printdata() const{
	

	cout << "Here are the data on the Flashlight: " << endl;
	cout << "The battery voltage is " << getBatVoltage() << "." << endl;
	cout << "The bulb resistance is " << getBulbRes() << "." << endl;
	cout << "The switch is " << (getToggleState() == false ? "open" : "closed") << "." << endl;
	cout << "The Flashlight is " << (getToggleState() == false ?  "off" : "on") << "." <<endl;
	cout << "The bulb current is " << (getToggleState() == false ? 0 : getCurrent()) << " Amperes." << endl;
	cout << "The bulb power is " << (getToggleState() == false ? 0: getPower()) << " watts." <<endl;
	
} 


