#ifndef FLASHLIGHT_H //include guard //always write this for all of your h files!!
#define FLASHLIGHT_H
//class declaration for flashlight.
class Flashlight{
	//private variables
	private: 
		double batvoltage; //storing the flashlight's battery voltage.
		double bulbres; //storing the bulb resistance
		bool switchything; //storing the toggle state of the flashlight.
		
	public:
		Flashlight(); //constrcutor
		void setBatVoltage(double); //setting battery voltage
		void setBulbRes(double); // setting bulb resistance
		void toggleSwitch();  //toggling the switch
		double getBatVoltage() const; //getting battery voltage
		double getBulbRes() const; //getting bulb resistance
		bool getToggleState() const; //getting the switch state.
		double getCurrent() const; //getting the current through the bulb
		double getPower() const; //getting the power dissapated.
		void printdata() const; //printing out flashlight data.
		
};
#endif
