// This program demonstrates a simple class.
#include <iostream>
#include <cmath>
using namespace std;

// ComplexNum class declaration.
class ComplexNum
{
   private:
      double real;
      double imaginary;
   public:
      void setReal(double);
      void setImagine(double);
      double getReal() const;
      double getImagine() const;
      double getMag() const;
      double getPhase() const;

};

//setting the real number that is passed in. 
void ComplexNum::setReal(double r) 
{
   real = r; 
}

//setting the iamginary number that is passed in. 
void ComplexNum::setImagine(double i)
{
   imaginary = i;
}

//function for getting the magnitude.
double ComplexNum::getMag() const
{
	
	// returning the magnitude by squaring both real and imaginery then summing those
	//and then square rooting it.
	return sqrt((real*real) + (imaginary*imaginary));
	
}

//function for getting the magnitude.
double ComplexNum::getPhase() const
{
	//returning the arctangent of the real and imaginary numbers
	//which is just the phase angle.
	return atan2(imaginary,real);
}

//function for getting the real part.
double ComplexNum::getReal() const
{
	//returning the real part of the complex num
	return real;
}

//function for getting the imaginary part.
double ComplexNum::getImagine() const
{
	// returning imaginary part of the complex num.
	return imaginary;
}



//*****************************************************
// Function main                                      *
//*****************************************************

int main()
{
	double realtemp, imaginetemp; //declaring temporary variables to store the real and imaginary numbers.
	ComplexNum eq1;
	
	//declaring variables for holding the results of the accessor functions.
	double real,imagine,mag,phase;  
	
	//diplaying program intro
	cout << "This program will calculate the magnitude and phase angle\nof a complex number " << endl << endl;
	
	//Prompting and getting the real part .
	cout << "What is the real part? ";
	cin >> realtemp;
	
	//Prompting and getting the imaginary part .
	cout << "What is the imaginary part? ";
	cin >> imaginetemp;
	
	//calling the mutator functions to store the values. 
	eq1.setReal(realtemp);
	eq1.setImagine(imaginetemp);
	
	//getting the values of the real and the imaginary part.
	real = eq1.getReal();
	imagine = eq1.getImagine();
	
	//getting the magnitude and the phase angle
	mag = eq1.getMag();
	phase = eq1.getPhase();
	
	//displaying all the information to the user.
	cout << "Here are the data on complex number z:\n";
	cout << "Real part: " << real << endl;
	cout << "Imaginary part: " << imagine << endl;
	cout << "Magnitude: " << mag << endl;
	cout << "Phase angle (radians): " << phase << endl;
	
	
   
   return 0;
}
