#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;


//Prototype for OR gate function.
bool Orgate(bool,bool,bool);

//Prototype for OR gate function.
bool ANDgate(bool,bool,bool);

//Prototype of printing out the truth table function
void PrintTruth(ofstream &, bool);

//Function for printing out the minterms.
string Minterm(int);

//function for printing out the maxterms.
string Maxterm(int);





//////////////////////////////////////////////////////
//MAIN FUNCTION
/////////////////////////////////////////////////////

int main(){
	
	//Displaying introductory message.
	cout<< "ECE 0301: Boolean Functions of 3 Variables.\nRealization in Canonical Forms." << endl << endl;
	
	//defining an ofstream object
	ofstream textout("Bool_func_3var_CSOP_CPOS.txt");
	
	//defining an ifstream object
	ifstream textin("Bool_func_3var.txt");
	
	//Displaying intro message to the output file. 
	textout<< "ECE 0301: Boolean Functions of 3 Variables.\nRealization in Canonical Forms." << endl << endl;
	

	//PrintTruth(textout, 0); 	//Printing out truth table for the OR gate.
	//textout<< endl;
	//PrintTruth(textout, 1);		//Printing out truth table for the AND gate.
	
	//reading in from the input file, declaring variable to store it.
	int innum;
	textin >> innum;
	
	textout << Minterm(innum) << endl;
	textout << Maxterm(innum) << endl;
	
	
	textout.close(); //closing the file.
	textin.close();
	return 0;
}


//Function that accepts three bool inputs, and "sends" them through an OR gate. 
bool ORgate(bool x, bool y, bool z){
	
	//if structure for the OR gate. if all are zero, outputs a zero.
	if(x||y||z){
		return true;
	}
	else{
		return false;
	
	}
}

//Function that accepts three bool inputs, and "sends" them through an AND gate. 
bool ANDgate(bool x, bool y, bool z){
	
	//if structure for the AND gate. if all are one, outputs a one.
	if(x && y && z){
		return true;
	}
	else{
		return false;
	}
}


//Function that prints out the 8 row truth table.
void PrintTruth(ofstream &textout, bool gateselect){
	
	
	if(gateselect){
		//Prinitng out the truth table header in the proper format.
		textout << "Truth table for AND gate.\n\n";
		textout << "x       y       z       f(x,y,z)\n";
		textout << "--------------------------------\n";
		
	
		bool x=0,y=0,z=0,f; //defining bool variables;
		int i,j,k; 	//defining loop variables;
	
		
		
		//For looping through every possible combination of x,y,z.
		for(i = 0; i<2; i++){
			
			x = i;//setting value to boolean x.
			
			for(j = 0; j<2; j++){
				
				y=j; //setting value to boolean y
				
				for(k=0; k<2; k++){
					
					z=k; //setting value to boolean y
					
					//calling Orgate function to get the output f.
					f= ANDgate(x,y,z);
					//Printing to output.
					textout << x << "       " << y << "       " << z << "       " <<f << endl;	
					
				}	
					
			}	
		
		}		
	} else{
		
	
	
		//Prinitng out the truth table header in the proper format.
		textout << "Truth table for OR gate.\n\n";
		textout << "x       y       z       f(x,y,z)\n";
		textout << "--------------------------------\n";
		
	
		bool x=0,y=0,z=0,f; 	//defining bool variables;
		int i,j,k; 	//defining loop variables;
	
		
		
		//For looping through every possible combination of x,y,z.
		for(i = 0; i<2; i++){
			
			x = i;//setting value to boolean x.
			
			for(j = 0; j<2; j++){
				
				y=j; //setting value to boolean y
				
				for(k=0; k<2; k++){
					
					z=k; //setting value to boolean y
					
					//calling Orgate function to get the output f.
					f= ORgate(x,y,z);
					//Printing to output.
					textout << x << "       " << y << "       " << z << "       " <<f << endl;	
					
				}	
					
			}	
		
		}
	
	}	
	
}

//Minterm function, returns a minterm for a given index! 
string Minterm(int index){
	//declaring bool variables. 
	bool x,y,z;
	
	//output statement variabes.
	string minterm, xret,yret,zret; 
	
	
	//input validation
	if(index < 0 || index > 7){
		
		//printing out failure, and exiting program.
		cout << "ERROR! Invalid minterm index.";
		exit(0);
		
		
	}
	else{
		
		
		
		//converting from dec to bin.
		//DETERMINING MSB
		if(index>=4){
			x=1;
		}
		else{
			x = 0;
		}
		
		//DETERMINING MIDDLE BIT		 
		if((index/2)%2 == 0){
			y=0;
		}else{
			y=1;
		}
		
		//DETERMINING LSB
		if(index%2 ==0){
			z=0;
		}else{
			z=1;
		}
			
		//Setting the printout variables to the corresponding string
		xret = x == 0 ? "x'" : "x";
		yret = y == 0 ? "y'" : "y";
		zret = z == 0 ? "z'" : "z";
		
		//Setting minterm equal to the string that will be returned
		minterm = "m" + to_string(index) +" = "+ xret + yret + zret;
		
		
		
	}
	
	return minterm;
	
}

//FUNCTION FOR PRINTING OUT THE MAXTERMS!! 
string Maxterm(int index){
	//declaring bool variables. 
	bool x,y,z;
	
	//output statement variabes.
	string maxterm, xret,yret,zret; 
	
	
	//input validation
	if(index < 0 || index > 7){
		
		//printing out failure, and exiting program.
		cout << "ERROR! Invalid maxterm index.";
		exit(0);
		
		
	}
	else{
		
		//converting from dec to bin.
		//DETERMINING MSB
		if(index>=4){
			x=1;
		}
		else{
			x = 0;
		}
		
		//DETERMINING MIDDLE BIT		 
		if((index/2)%2 == 0){
			y=0;
		}else{
			y=1;
		}
		
		//DETERMINING LSB
		if(index%2 ==0){
			z=0;
		}else{
			z=1;
		}
			
		//Setting the printout variables to the corresponding string, output to be a zero.
		xret = x == 1 ? "x'" : "x";
		yret = y == 1 ? "y'" : "y";
		zret = z == 1 ? "z'" : "z";
		
		
		//Setting maxterm equal to the string that will be returned
		maxterm = "M" + to_string(index) +" = "+ xret +" + "+ yret +" + "+ zret;
		
		
		
	}
	
	return maxterm;
	
}

	


