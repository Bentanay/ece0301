#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;


//Prototype for OR gate function.
bool Orgate(bool,bool,bool);

//Prototype for OR gate function.
bool ANDgate(bool,bool,bool);

//Prototype of printing out the truth table function
void PrintCSOP(ofstream &, int);

//Function for printing out the minterms.
string Minterm(int);

//function for printing out the maxterms.
string Maxterm(int);

//overloading function for minterm that returns a truth value for any minterm.
bool Minterm(bool,bool,bool,int);

//overloading function for minterm that returns a truth value for any maxterm.
bool Maxterm(bool,bool,bool,int);

//function for returning the canonical sum of products
string CSOP(int);

//overloading the CSOP function. this function retyrns the truth value for any CSOP expression.
bool CSOP(bool, bool, bool, int);



//////////////////////////////////////////////////////
//MAIN FUNCTION
/////////////////////////////////////////////////////

int main(){
	
	//Displaying introductory message.
	cout<< "ECE 0301: Boolean Functions of 3 Variables.\nRealization in Canonical Forms." << endl << endl;
	
	//defining an ofstream object
	ofstream textout("Bool_func_3var_CSOP_CPOS.txt");
	
	//defining an ifstream object
	ifstream textin("Bool_func_3var.txt");
	
	//Displaying intro message to the output file. 
	textout<< "ECE 0301: Boolean Functions of 3 Variables.\nRealization in Canonical Forms." << endl << endl;
	
	
	//reading in from the input file, declaring variable to store it.
	int innum;
	textin >> innum;
	
	
	textout << CSOP(innum); //printing out the CSOP expression 
	textout << endl << endl;
	PrintCSOP(textout, innum); //printing out the truth table for the CSOP expression. 
	
	textout.close(); //closing the file.
	textin.close(); //closing the file.
	return 0;
}


//Function that accepts three bool inputs, and "sends" them through an OR gate. 
bool ORgate(bool x, bool y, bool z){
	
	//if structure for the OR gate. if all are zero, outputs a zero.
	if(x||y||z){
		return true;
	}
	else{
		return false;
	
	}
}

//Function that accepts three bool inputs, and "sends" them through an AND gate. 
bool ANDgate(bool x, bool y, bool z){
	
	//if structure for the AND gate. if all are one, outputs a one.
	if(x && y && z){
		return true;
	}
	else{
		return false;
	}
}


//Function that prints out the 8 row truth table.
void PrintCSOP(ofstream &textout, int index){
	

	bool x=0,y=0,z=0,f; //defining bool variables;
	int i,j,k; 	//defining loop variables;
	
		
	//printing out for which index was selected.
	textout << "Truth table for CSOP form of function " << index << ".\n\n";
	
	//Prinitng out the truth table header in the proper format.
	textout << "x       y       z       f(x,y,z)\n";
	textout << "--------------------------------\n";
	
	//For looping through every possible combination of x,y,z.
	for(i = 0; i<2; i++){
		
		x = i;//setting value to boolean x.
		
		for(j = 0; j<2; j++){
			
			y=j; //setting value to boolean y
			
			for(k=0; k<2; k++){
				
				z=k; //setting value to boolean y
				
				//calling Minterm function to get the output f.
				f= CSOP(x,y,z,index);
				//Printing to output.
				textout << x << "       " << y << "       " << z << "       " <<f << endl;	
				
			}	
				
		}	
	
	}		 		
	 

	
}

//Minterm function, returns a minterm for a given index! 
string Minterm(int index){
	//declaring bool variables. 
	bool x,y,z;
	
	//output statement variabes.
	string minterm, xret,yret,zret; 
	
	
	//input validation
	if(index < 0 || index > 7){
		
		//printing out failure, and exiting program.
		cout << "ERROR! Invalid minterm index.";
		exit(0);
		
		
	}
	else{
		
		
		
		//converting from dec to bin.
		//DETERMINING MSB
		if(index>=4){
			x=1;
		}
		else{
			x = 0;
		}
		
		//DETERMINING MIDDLE BIT		 
		if((index/2)%2 == 0){
			y=0;
		}else{
			y=1;
		}
		
		//DETERMINING LSB
		if(index%2 ==0){
			z=0;
		}else{
			z=1;
		}
			
		//Setting the printout variables to the corresponding string
		xret = x == 0 ? "x'" : "x";
		yret = y == 0 ? "y'" : "y";
		zret = z == 0 ? "z'" : "z";
		
		//Setting minterm equal to the string that will be returned
		minterm = xret + yret + zret;
		
		
		
	}
	
	return minterm;
	
}

//FUNCTION FOR PRINTING OUT THE MAXTERMS!! 
string Maxterm(int index){
	//declaring bool variables. 
	bool x,y,z;
	
	//output statement variabes.
	string maxterm, xret,yret,zret; 
	
	
	//input validation
	if(index < 0 || index > 7){
		
		//printing out failure, and exiting program.
		cout << "ERROR! Invalid maxterm index.";
		exit(0);
		
		
	}
	else{
		
		//converting from dec to bin.
		//DETERMINING MSB
		if(index>=4){
			x=1;
		}
		else{
			x = 0;
		}
		
		//DETERMINING MIDDLE BIT		 
		if((index/2)%2 == 0){
			y=0;
		}else{
			y=1;
		}
		
		//DETERMINING LSB
		if(index%2 ==0){
			z=0;
		}else{
			z=1;
		}
			
		//Setting the printout variables to the corresponding string, output to be a zero.
		xret = x == 1 ? "x'" : "x";
		yret = y == 1 ? "y'" : "y";
		zret = z == 1 ? "z'" : "z";
		
		//Setting maxterm equal to the string that will be returned
		maxterm = "M" + to_string(index) +" = "+ xret +" + "+ yret +" + "+ zret;
		
		
		
	}
	
	return maxterm;
	
}

//overloading function for minterm that returns a truth value for any minterm.
bool Minterm(bool x,bool y,bool z,int index){
	
	
	bool xindex, yindex, zindex; //setting the variables for determining which variables need to be complemented. 
	bool result; //used for the return of the function.
	
	//converting the dec to bin.
	if(index>=4){
			xindex=1;
		}
		else{
			xindex = 0; 
		}
		
		//DETERMINING MIDDLE BIT		 
		if((index/2)%2 == 0){
			yindex=0; 
		}else{
			yindex=1;
		}
		
		//DETERMINING LSB
		if(index%2 ==0){
			zindex=0;
		}else{
			zindex=1; 
	}
	
	//Taking any complements that are needed defined by the minterm expression.
	if(xindex == 0){
		x = !x; //inverting x.
	}
	if(yindex == 0){
		y = !y;  //inverting y.
	}
	if(zindex == 0){
		z = !z;  //inverting z.
	}
			
	//Getting the output of the minterm function using the input bools.
	result = ANDgate(x,y,z);
	
	return result; //returning the result.
	
	
}

//overloading function for minterm that returns a truth value for any maxterm.
bool Maxterm(bool x,bool y,bool z,int index){
	
	
	bool xindex, yindex, zindex; //setting the variables for determining which variables need to be complemented. 
	bool result; //used for the return of the function.
	
	//converting the dec to bin.
	if(index>=4){
			xindex=1;
		}
		else{
			xindex = 0; 
		}
		
		//DETERMINING MIDDLE BIT		 
		if((index/2)%2 == 0){
			yindex=0; 
		}else{
			yindex=1;
		}
		
		//DETERMINING LSB
		if(index%2 ==0){
			zindex=0;
		}else{
			zindex=1; 
	}
	
	//Taking any complements that are needed defined by the minterm expression.
	if(xindex == 1){
		x = !x; //inverting x.
	}
	if(yindex == 1){
		y = !y;  //inverting y.
	}
	if(zindex == 1){
		z = !z;  //inverting z.
	}
			
	//Getting the output of the minterm function using the input bools.
	result = ORgate(x,y,z);
	
	return result; //returning the result.
	
	
}

string CSOP(int index){
	
	//ERROR CHECKING THE INDEX
	if(index < 0 || index > 255){
		//Printing out the error message
		cout << "ERROR! Function index out of range.";
		exit(0); //exit the program
		
	}
	else{
		
		string CSOP = ""; //declaring the return string
		bool bit = 7; //for storing the bit.
		int funcindex = 255, bitcounter = 7; //declaring and initialzing some values for the loop. 
		
		
		do{
			
			bit = (index >> bitcounter)%2==0 ? 0 : 1; //bit shifting to determine if the next bit is a zero or a one. 
			
			if(bit != 0){ //if the bit is a one
				
				//checks if the CSOP expression will only have one term. gets rid of the plussign if so. 
				if(index ==1 || index == 2 || index == 4 || index == 8 || index == 16 || index == 32 || index == 64 || index == 128){
					CSOP += Minterm(7-bitcounter); //Concatenating next minterm onto the existing CSOP expression.
					
				}
				//if not, checks if the it is the last section of the CSOP expression.
				else if(funcindex-pow(2,bitcounter)>0){
					
					CSOP += Minterm(7-bitcounter) + " + "; //Concatenating next minterm onto the existing CSOP expression, adds a plus sign.
					
				}
				//else adds the term without a plus sign. 
				else{
					CSOP += Minterm(7-bitcounter); //Concatenating next minterm onto the existing CSOP expression.
					
				}

					
			}
				
			
			funcindex = funcindex - pow(2,bitcounter); //decreasing the function index by the bit number.
			bitcounter--; //decreasing bit counter. 
			
		}while(funcindex >0); //do while loop, while the function index is greater than zero .
		
		
		CSOP = "CSOP: f" + to_string(index) + " = " + CSOP;
		return CSOP; //return the CSOP expression. 
			
		
		
	}
	
}

//overloading function for the CSOP expression. returns the truth value for any CSOP expression. 
bool CSOP(bool x, bool y, bool z, int index){
	
	if(index < 0 || index > 255){
		//Printing out the error message
		cout << "ERROR! Function index out of range.";
		
	}else{
		
		bool bit = 7; //for storing the bit.
		int funcindex = 255, bitcounter = 7; //declaring and initialzing some values for the loop. 
		bool returnbool = false; //storing the return value. 
		
		
		do{
			
			bit = (index >> bitcounter)%2==0 ? 0 : 1; //bit shifting to determine if the next bit is a zero or a one. 
			
			if(bit != 0){ //if the bit is a one
				
					returnbool = returnbool || Minterm(x,y,z,7-bitcounter); //logical or on the bool variable and the bool returned from minterm. 
				

			}
				
			
			funcindex = funcindex - pow(2,bitcounter); //decreasing the function index by the bit number.
			bitcounter--; //decreasing bit counter. 
			
		}while(funcindex >0); //do while loop, while the function index is greater than zero .
		
		
		return returnbool;
	}
	
	return 0;
	
}
	

	

	





