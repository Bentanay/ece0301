#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;


//Prototype for OR gate function.
bool Orgate(bool,bool,bool);

//Prototype for OR gate function.
bool ANDgate(bool,bool,bool);

//Prototype of printing out the truth table function
void PrintTruth(ofstream &, bool);



//////////////////////////////////////////////////////
//MAIN FUNCTION
/////////////////////////////////////////////////////

int main(){

	//Displaying introductory message.
	cout<< "ECE 0301: Boolean Functions of 3 Variables.\nRealization in Canonical Forms." << endl << endl;

	//defining an ofstream object
	ofstream textout("Bool_func_3var_CSOP_CPOS.txt");

	//Displaying intro message to the output file.
	textout<< "ECE 0301: Boolean Functions of 3 Variables.\nRealization in Canonical Forms." << endl << endl;


	PrintTruth(textout, 0); 	//Printing out truth table for the OR gate.
	textout<< endl;
	PrintTruth(textout, 1);		//Printing out truth table for the AND gate.

	textout.close(); //closing the file.
	return 0;
}


//Function that accepts three bool inputs, and "sends" them through an OR gate.
bool ORgate(bool x, bool y, bool z){

	//if structure for the OR gate. if all are zero, outputs a zero.
	if(x||y||z){
		return true;
	}
	else{
		return false;

	}
}

//Function that accepts three bool inputs, and "sends" them through an AND gate.
bool ANDgate(bool x, bool y, bool z){

	//if structure for the AND gate. if all are one, outputs a one.
	if(x && y && z){
		return true;
	}
	else{
		return false;
	}
}


//Function that prints out the 8 row truth table.
void PrintTruth(ofstream &textout, bool gateselect){


	if(gateselect){
		//Prinitng out the truth table header in the proper format.
		textout << "Truth table for AND gate.\n\n";
		textout << "x\ty\tz\tf(x,y,z)\n";
		textout << "--------------------------------\n";


		bool x=0,y=0,z=0,f; //defining bool variables;
		int i,j,k; 	//defining loop variables;



		//For looping through every possible combination of x,y,z.
		for(i = 0; i<2; i++){

			x = i;//setting value to boolean x.

			for(j = 0; j<2; j++){

				y=j; //setting value to boolean y

				for(k=0; k<2; k++){

					z=k; //setting value to boolean y

					//calling Orgate function to get the output f.
					f= ANDgate(x,y,z);
					//Printing to output.
					textout << x << "\t" << y << "\t" << z << "\t" <<f << endl;

				}

			}

		}
	} else{



		//Prinitng out the truth table header in the proper format.
		textout << "Truth table for OR gate.\n\n";
		textout << "x\ty\tz\tf(x,y,z)\n";
		textout << "--------------------------------\n";


		bool x=0,y=0,z=0,f; 	//defining bool variables;
		int i,j,k; 	//defining loop variables;



		//For looping through every possible combination of x,y,z.
		for(i = 0; i<2; i++){

			x = i;//setting value to boolean x.

			for(j = 0; j<2; j++){

				y=j; //setting value to boolean y

				for(k=0; k<2; k++){

					z=k; //setting value to boolean y

					//calling Orgate function to get the output f.
					f= ORgate(x,y,z);
					//Printing to output.
					textout << x << "\t" << y << "\t" << z << "\t" <<f << endl;

				}

			}

		}


	}


}
