
#include <iostream>	//Including iostream package. 
using namespace std; //Using the standarad namespace.

int main(){
	
	//Outputting program details to the console. 
	cout << "ECE 0301 DC Resistive Circuit Simulation" <<endl;
	cout << "Modeled after www.falstad.com/circuit/" <<endl;
	cout << "Circuits -> Basics -> Ohm\'s Law" <<endl;
	
	//Declaring and intializing 3 variables for voltage source and two resistors.  
	double Vs = 120.0, R1= 10.0, R2 = 15.0;
	
	//Printing out the voltage source and the values of the two resistors.
	cout << "Vs = " << Vs << " Volts\n"; //Printing out the voltage of the source.
	cout << "R1 = " << R1 << " Ohms\n"; //Printing out the resistance of R1.
	cout << "R2 = " << R2 << " Ohms\n"; //Printing out the resistance of R2.
	
	//Declaring variables for the current through and the power dissipated by R1 and R2.
	double currentThruR1, currentThruR2, powerDissR1, powerDissR2;
	currentThruR1 = Vs / R1; //Calculating the current through R1 using Ohm's Law. 
	currentThruR2 = Vs / R2; //Calculating the current through R2 using Ohm's Law. 
	powerDissR1 = currentThruR1 * Vs; //Calculating the power dissipated for resistor 1.
	powerDissR2 = currentThruR2 * Vs; //Calculating the power dissipated for resister 2.
	
	cout << "I1 = " << currentThruR1 << " Amperes\n"; //Printing out the current through R1.
	cout << "P1 = " <<  powerDissR1 << " Watts\n"; //Printing out the power dissipated by R1.
	cout << "I2 = " << currentThruR2 << " Amperes\n"; //Printing out the current through R2.
	cout << "P2 = " <<  powerDissR2 << " Watts\n"; //Printing out the power dissipated by R2.
	
	//Declaring variables for energies used during time periods, the current coming from the source, and the power of the source.
	double oneSecEnergy, oneHourEnergy, oneDayEnergy, oneYearEnergy, currentAtSource, powerAtSource;
	
	currentAtSource = currentThruR1+currentThruR2; //Calculating the total current from the power source by adding the two currents through the resistors.
	powerAtSource = Vs*currentAtSource;  //Calculating the power at the source using P =IV.
	oneSecEnergy = powerAtSource*1; //Calculating the total energy by multiplying it by the given time period in seconds.
	oneHourEnergy = powerAtSource*3600; //Calculating the total energy by multiplying it by the given time period in seconds.
	oneDayEnergy = powerAtSource*3600*24;//Calculating the total energy by multiplying it by the given time period in seconds.
	oneYearEnergy =powerAtSource*3600*24*365; //Calculating the total energy by multiplying it by the given time period in seconds.
	
	//Printing out the different energies supplied during different time periods.
	cout << "Energy supplied in one second = " << oneSecEnergy << " Joules\n";
	cout << "Energy supplied in one hour = " << oneHourEnergy << " Joules\n";
	cout << "Energy supplied in one day = " << oneDayEnergy << " Joules\n";
	cout << "Energy supplied in one year = " << oneYearEnergy << " Joules\n";
	
	const double costPerkWH = 0.10; //Declaring a constant to store the cost per kWH.
	double joules_to_kWH = 1/1000.0/3600.0; //Converting from joules to kWH.
	
	//Declaring the variables to store the prices for different supplying energies during different time periods.
	double priceForOneSecEnergy,priceForOneHourEnergy,pricePerOneDayEnergy,pricePerOneYearEnergy;
	
	priceForOneSecEnergy = oneSecEnergy*joules_to_kWH*costPerkWH; //Taking the energy calculated above, converting to kWH, and multiplying it by the cost per kWH.
	priceForOneHourEnergy = oneHourEnergy*joules_to_kWH*costPerkWH; //Taking the energy calculated above, converting to kWH, and multiplying it by the cost per kWH.
	pricePerOneDayEnergy = oneDayEnergy*joules_to_kWH*costPerkWH; //Taking the energy calculated above, converting to kWH, and multiplying it by the cost per kWH.
	pricePerOneYearEnergy = oneYearEnergy*joules_to_kWH*costPerkWH; //Taking the energy calculated above, converting to kWH, and multiplying it by the cost per kWH.
	
	//Printing out the cost for different supplying energies during different time periods. 
	cout << "Cost of supplying energy for one second at $0.10/kWh = $" << priceForOneSecEnergy <<endl;
	cout << "Cost of supplying energy for one hour at $0.10/kWh = $" << priceForOneHourEnergy <<endl;
	cout << "Cost of supplying energy for one day at $0.10/kWh = $" << pricePerOneDayEnergy <<endl;
	cout << "Cost of supplying energy for one year at $0.10/kWh = $" << pricePerOneYearEnergy <<endl;
	
	return 0;
	
}



