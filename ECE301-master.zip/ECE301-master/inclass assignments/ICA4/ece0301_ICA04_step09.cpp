#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;


int main()
{
	//Printing out program introduction
	cout << "ECE 0301: Circuit Solver for Voltage Divider\nand Wheatstone bridge example circuits.\n\n";
	
	//Creating a file object for input.
	ifstream individer("divider_wheatstone_circuits.txt");
	string input; //Declaring variable.
	
	
	//Creating a file object for output.
	ofstream divider("divider_wheatstone_solutions.txt");
	
	
	
	//Pritning out file introduction
	divider << "ECE 0301: Circuit Solver for Voltage Divider\nand Wheatstone bridge example circuits.\n-----\n";
	
	int count = 0; //FOR COUNTING THE NUMBER OF CIRCUIT SOLUTIONS.
	
	individer >> input; //Getting the first line from the file.
	
	do{
		//ACCOUNTING FOR ERRONEOUS TITLES.
		if(input != "Divider" && input != "Wheatstone"){
			
			cout << "ERROR! Invalid header.";
			return -1; //Ending the program.
			
		}
		
			
		if(input =="Divider"){
			
			if(count != 0){
			
				divider << "-----\n";
			}
			
			count++;

			//Declaring varibles for storing calculations numbers. 
			double Vs = 0;
			int R1, R2;
			
			//Declaring variables to hold the numbers read from the file. 
			int R1read, R2read;
			
			//Reading in the values from the file.
			individer >> Vs;
			individer >> R1read;
			individer >> R2read;
			
			//initalizing R1 and R2 with the varaibles read.
			R1 = R1read;
			R2 = R2read;
		
			double iloop, vdropR1, vdropR2; //Defining a varibale for the loop current. 
			
			
			//inputting the amount of circuits to solve.
			double n;
			individer >> n;
			
			//PRINTING OUTPUT TO THE FILE.
	        divider << "Circuit #" << count<<" (Voltage Divider)\n";
	        divider <<"---\n";
	        
	        
	        
	        
	        //FOR LOOP FOR LOOPING THROUGH ALL OF THE SOLUTIONS.
	        for (int i =1; i <= n; i++){  //Outer loop for looping through R1. 
				

				for (int j = 1; j <= n; j++) { //inner loop for looping through R2.
					R1 = i*R1read; //Multiplying R1 by the outer loop number.
					R2 = j*R2read; //Multiplying R2 by the inner loop number.

					
					iloop= Vs/(R1+R2); //Calculating iloop.
					vdropR1 = iloop*R1; //Voltage drop over resistor 1.
					vdropR2 = iloop*R2;//Voltage drop over resistor 2.
					
					
					//OUTPUTTING CIRCUIT INFO.
					divider << "Source voltage: Vs = " << Vs << " Volts.\n";
					divider << "Resistor: R1 = " << R1 << " Ohms.\n";
					divider << "Resistor: R2 = " << R2 << " Ohms.\n\n";
	        
					divider << "Loop current: I = " << iloop << " Amperes.\n";
					divider << "Resistor voltage: V1 = " << vdropR1 << " Volts.\n";
					divider << "Resistor voltage: V2 = " << vdropR2 << " Volts.\n";
					
					//Omitting the last 3 dashed line at the very end of the file and adding 5 dashes after a circuit solutions
					if(i == n && j==n){
						
					}	
					else{
						
						divider <<"---\n";
					}
	        
				
				}

			}
	        
				
				
				
		}
		if(input ==  "Wheatstone"){
			
			if(count != 0){
			
				divider << "-----\n";
			}
			
			
			count++;

			
			double Vs, Is;//Declaring variables for inputting from file.
			double R1, R2, R3, R4, R5; //Declaring variables for inputting from file. For storing values of the resistors.
			
			//Declaring variables to store the initial resistors values.
			double  R1read, R2read, R3read, R4read, R5read;
			
			individer >> Vs >> Is >> R1read >> R2read >> R3read >> R4read >> R5read; //Reading in all the variables.
			
			
			//Assinging the initial reads to R1-R5.
			R1 = R1read;
			R2 = R2read;
			R3 = R3read;
			R4 = R4read;
			R5 = R5read;
			
			//inputting the amount of circuits to solve.
			double n;
			individer >> n;
			
			//BEGINNING THE ERROR CHECKING
			//Declaring varibales for error checking and definting two of thec conditions that cannot be true during calculation.
			bool condition1 = (-1* pow(10,-13) < (Vs-(Is*R4)) && (Vs-(Is*R4)) < pow(10,-13));
			bool condition2 = (-1* pow(10,-13) < (Vs+(Is*R5)) && (Vs+(Is*R5)) < pow(10,-13));

			
			
			
			
			double I1, I2, I3, I4, I5; //Decalring varibables for calculations. These are the variables for holding the currenst through each resistor.
			double V1, V2, V3, V4, V5; //Declaring variables for calculations. These are for holding the voltage drop across each. 
			double a, b, c, d, e, f, w, x, y, z; //Decalring varibables for calculations.
			
			//Printing out headers. 
	        divider << "Circuit #"<< count <<" (Wheatstone Bridge)\n";
			
			for(int i = 1; i <= n; i++){ //for loop that multiples R1 by n.
				
				for(int j = 1; j <= n; j++){ //for loop that multiples R2 by n.
					
					for(int k =1; k <= n; k++){ //for loop that multiples R3 by n.
						
						for(int l = 1; l <= n; l++){ //for loop that multiples R4 by n.
							
							for(int m =1; m <= n; m++){ //for loop that multiples R5 by n. 
								
								//CALCULATION SECTION FOR THE WHEATSTONE CIRCUIT.
								
								//ASSIGNING MULTIPLES FOR R1-R5.
								
								R1 = i*R1read;
								R2 = j*R2read;
								R3 = k*R3read;
								R4 = l*R4read;
								R5 = m*R5read;

								//Calcuting a,b,c,d,e, f using the algorithm provided.
								a = 1 + (static_cast<double>(R4)/R2); //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								b = Vs - (Is*R4); //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								c = 1 + (static_cast<double>(R5)/R3); //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								d = Vs + (Is*R5); //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								e = static_cast<double>(R1) / R2; //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								f = static_cast<double>(R1)/ R3; //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								
								//Using values a,b,c,d,e,f to calculate next set of values for the algroithm. 
								w = (a + e) /b; //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								x = f/b; //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								y = e /d; //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								z = (c+f)/d; //Matching up coeffcients to the letter coefficients provided in the simplied equation.
								
								//Using equations 4 and 5 to compute v3 and v2;
								V3 = (y-w)/((x*y)-(w*z));
								V2= (1-(x*V3))/w;
								
								//Using equation 3 to compute v1;
								V1 = (e*V2) +(f*V3);
							
								//using equation 1 and 2 to compute v4 and v5;
								V4 = Vs - V1 -V2;
								V5 = Vs - V1 - V3;
								
								//using the voltages and the resistor values to solve for the current through each resistor.
								I1 = V1/ R1; //Using ohm's law. 
								I2 = V2/ R2;//Using ohm's law.
								I3 = V3/ R3;//Using ohm's law.
								I4 = V4/ R4;//Using ohm's law.
								I5 = V5/ R5;//Using ohm's law.
								
								//checking for the round off errors
								if(R2 == 0 || R3 == 0 || condition1 || condition2){
									cout << "ERROR! Unstable floating-point division." << endl;
									return -1;
								}
								
								//printing out the first line only on the first run through.
								if(i == 1 && j == 1 && m ==1 && l == 1 && k == 1){
									divider <<"---\n";
								}
			
								
								//OUTPUTTING THE CALCULATIONS TO THE FILE.
						  
								divider << "Source voltage: Vs = " << Vs << " Volts.\n";
								divider << "Source current: Is = " << Is << " Amperes.\n";
					
						        divider << "Resistor: R1 = " << R1 << " Ohms.\n";
						        divider << "Resistor: R2 = " << R2 << " Ohms.\n";
						        divider << "Resistor: R3 = " << R3 << " Ohms.\n";
						        divider << "Resistor: R4 = " << R4 << " Ohms.\n";
						        divider << "Resistor: R5 = " << R5 << " Ohms.\n\n";
						        
						        divider << "Resistor voltage: V1 = " << V1 << " Volts.\n";
								divider << "Resistor current: I1 = " << I1 << " Amperes.\n";
								divider << "Resistor voltage: V2 = " << V2 << " Volts.\n";
								divider << "Resistor current: I2 = " << I2 << " Amperes.\n";
								divider << "Resistor voltage: V3 = " << V3 << " Volts.\n";
								divider << "Resistor current: I3 = " << I3 << " Amperes.\n";
								divider << "Resistor voltage: V4 = " << V4 << " Volts.\n";
								divider << "Resistor current: I4 = " << I4 << " Amperes.\n";
								divider << "Resistor voltage: V5 = " << V5 << " Volts.\n";
								divider << "Resistor current: I5 = " << I5 << " Amperes.\n";
								//END OF OUTPUTTING TO THE FILE SECTION
								
								
								//Omitting the last 3 dashed line at the very end of the file and adding 5 dashes after a circuit solutions
								if(i == n && j == n && m ==n && l == n && k ==n ){
									
								}
								else{
									divider <<"---\n";
								}
								
								
								
								
							}
							
						}
						
					}
					
				}
	

			}
		}
		
			
			
		
		
			
		
	}while(individer >> input);
	
	
	individer.close(); //closing the file.
		
		

		
}




			
			


