
#include <iostream>
#include <fstream>
using namespace std;





int main()
{
	//Printing out program introduction
	cout << "ECE 0301: Circuit Solver for Voltage Divider\nand Wheatstone bridge example circuits.\n\n";
	
	//Creating a file object for input.
	ifstream individer("divider_wheatstone_circuits.txt");
	string line1input; //Declaring variable.
	individer >> line1input; //Reading in first line. 

	
	//checking for proper file header. 
	if(line1input == "Wheatstone" || line1input =="Divider"){
	}
	else{
		cout << "ERROR! Invalid header.";
		return -1; //Ending the program.
	}
	
	//Declaring variables for inputting from file.
	double Vs = 0;
	int R1 = 0, R2 = 0;
	
	if(line1input =="Divider"){
		//Reading in the values from the file.
		individer >> Vs;
		individer >> R1;
		individer >> R2;
		
		individer.close(); //closing the file.
		
		
		//Creating a file object for output.
		ofstream divider2("divider_wheatstone_solutions.txt");
		

		double iloop, vdropR1, vdropR2; //Defining a varibale for the loop current. 
		
		iloop= Vs/(R1+R2);
		vdropR1 = iloop*R1;
		vdropR2 = iloop*R2;
		
		
		
		//Printing output to the file.
		divider2 << "ECE 0301: Circuit Solver for Voltage Divider\n";
        divider2 << "and Wheatstone bridge example circuits.\n";
        divider2 << "-----\n";
        divider2 << "Circuit #1 (Voltage Divider)\n";
        divider2 <<"---\n";
        
        divider2 << "Source voltage: Vs = " << Vs << " Volts.\n";
        divider2 << "Resistor: R1 = " << R1 << " Ohms.\n";
        divider2 << "Resistor: R2 = " << R2 << " Ohms.\n\n";
        
        divider2 << "Loop current: I = " << iloop << " Amperes.\n";
        divider2 << "Resistor voltage: V1 = " << vdropR1 << " Volts.\n";
        divider2 << "Resistor voltage: V2 = " << vdropR2 << " Volts.\n";
		
		
		divider2.close(); //Closing the file.
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
	
	

	return 0;
}
