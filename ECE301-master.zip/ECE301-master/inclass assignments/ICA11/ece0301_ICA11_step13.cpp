
#include <iostream>
#include <cmath>
#include <string>
#include <fstream>
#include <vector>


using std:: cout;
using std:: endl;
using std:: string;
using std:: ofstream;
using std:: vector;


class Signal{
	private:
		int nsamples; //for storing the number of samples
		double sampfreq; //for storing the sample frequency
		double itime; //for storing the inital time
		string label; //for storing the label of the signal
		string filename; //for storing the filename template
		string equation; //for storing the mathematical equation of the signal
		vector<double> sig; //for storing the signal array
		vector<double> time; //for storing the time array
		
		
	public:
		
		//cosntructors
		Signal(); //defualt constructor
		Signal(int, double, double); //overloaded constructor
		
		//mutators
		void setnSamples(int); //mutator for setting number of samples
		void setFrequency(double); //mutator for setting the sampling frequency
		void setiTime(double); //mutator for setting the inital time
		void setLabel(string); //mutator for setting the label.
		void setEquation(string); //mutator for setting the mathematical expression
		void fillTime(); //for filling the time array.
		void constsignal(double); //function for creating a constant signal
		void sinsignal(double, double, double); //function for filling the signal with a sine wave.
		
		//accessors
		int getnSamples() const; //getter for getting the num of smaples
		double getFrequency() const; //getter for getting the smapling frequencies
		double getiTime() const; //getter for getting the initial time
		string getLabel() const; //getter for getting the label
		string getFilename() const; //getter for getting the filename
		string getEquation() const; //getter for getting the equation
		vector<double> getSig() const; //getter for getting the signal vector
		vector<double> getTime() const; //getter for getting the time vector
		double getSig(unsigned int ) const; //getter for getting an index of the signal vector
		double getTime(unsigned int ) const; //getter for getting an index of the time vector
		
		//other
		void printinfo() const; //function for printing info out to a file.
		string textNum(double x); //function for converting a double to a string
		Signal & operator=( const Signal &); //function for copying signals over.
		void roundsig(); //function for rounding the signal.
		Signal operator+(const Signal &); //function for adding two signals
		
	
	
};


Signal::Signal(){
	
	nsamples = 101;
	sampfreq = 100;
	itime = 0;
	setLabel("x");
	equation = textNum(0);
	sig.resize(nsamples,0);
	time.resize(nsamples,0);
	fillTime();
	
	
	
}
Signal:: Signal(int n, double f, double t){
	nsamples= n;
	sampfreq = f; 
	itime = t; 
	setLabel("x");
	equation = textNum(0);
	sig.resize(nsamples,0);
	time.resize(nsamples,0);
	fillTime();
}


//mutator for setting number of samples
void Signal::setnSamples(int n ){
	nsamples = n;
	
}

//mutator for setting the sampling freq
void Signal::setFrequency(double f ){
	sampfreq = f;
	
}

//mutator for setting the initial time.
void Signal::setiTime(double i ){
	itime = i;
	
}

//getter for getting the num of smaples
int Signal::getnSamples() const{
	return nsamples;
	
} 
//getter for getting the smapling frequencies
double Signal::getFrequency() const{
	return sampfreq;
	
}
		
//getter for getting the initial time
double Signal::getiTime() const{
	return itime;
	
}

//mutator for setting the label.
void Signal::setLabel(string str){
	
	label = str;
	filename = "signal_" +label;
	
}

//getter for getting the label
string Signal::getLabel() const{
	return label;
	
}


//getter for getting the filename
string Signal::getFilename() const{
	return filename;
	
}

//getter for getting the equation
string Signal::getEquation() const{
	
	return equation;
}

//mutator for setting the mathematical expression
void Signal::setEquation(string str){
	equation = str;
	
}

//function for printing out the data to a text file.
void Signal::printinfo() const{
	//creating an ofstream object
	ofstream out(filename + ".txt");
	
	//printing the header to the file.
	out << "Time-Domain Signal Samples" << endl;
	out << "N = " << nsamples << endl;
	out << "fs = " << sampfreq << endl;
	out << "t0 = " << itime << endl;
	out << "Signal label: " << label << endl;
	out << "Mathematical expression" << endl;
	out << label << "(t) = " << equation << endl;
	
	//printing the data to the file.
	out << "Time and signal samples in .csv format" << endl;
	out << "t, " << label << "(t)" << endl;
	out << "-------" << endl;
	
	//for loop for looping through both vectors and printing it out to the file
	for(int i = 0; i < nsamples; i++){
		if(i != nsamples-1){ 
			out << time[i] << ", " << sig[i] << endl;
		}else{
			out << time[i] << ", " << sig[i];
		}
	}
	
	
	out.close(); //closing the output file
	
	
}

//getter for getting the signal vector
vector<double> Signal::getSig() const{
	return sig;
	
}
//getter for getting the time vector
vector<double> Signal::getTime() const{
	return time;
}

//getter for getting an index of the signal vector
double Signal::getSig(unsigned int s) const{
	
	return sig[s];
	
}

//getter for getting an index of the time vector
double Signal:: getTime(unsigned int t) const{
	
	return time[t];
}

//function for filling the time array.
void Signal::fillTime(){
	
	//for loop for looping through the array and storing the proper value returned by the equation in it.
	for(int i =0; i < nsamples ; i++){
		
		time[i] = itime + i/sampfreq;
		
		
	}
	
}


// Convert num->string for mathmatetical function
string Signal::textNum(double x){	
	if (x >= 100)
		return std::to_string(int(x));		// Large nums trunc. as int
	else
	{
		string x_exp = std::to_string(x);	// Small nums get 3 digits
		return x_exp.substr(0, 4);
	}
}	


//function for creating a constant signal
void Signal::constsignal(double k){
	 
	 //function for looping through the elements of the vector and storing k in each one.
	 for(int i =0; i < nsamples; i++){
		 sig[i] = k;
	 }
	 
	 //setting the equation equal to a constant.
	 setEquation(textNum(k));
	 
}

//function for copying signals over.
Signal & Signal::operator=( const Signal &obj){ 
	
	
	
	//assigning all of the members over and making sure there is no self assignment.
	if(this != &obj){
		nsamples = obj.nsamples;
		sampfreq = obj.sampfreq;
		itime = obj.itime;
		equation = obj.equation;
		sig = obj.sig;
		time = obj.time;
		
	}
	
	return *this;
	
}

//function for filling the signal with a sine wave.
void Signal::sinsignal(double amp, double freq, double phase){
	
	//storing the sinusoidual signals in the signal vector. 
	for(int i =0; i < nsamples; i++){
		
		sig[i] = amp* cos(2*4*atan(1)* freq * time[i] + phase);
	}
	
	//declaring several strings for storing the different part of the equation
	string amplitude =  textNum(amp), omega = textNum(2*4*atan(1)*freq), phasestr;
	
	//if statement for deciding whether to include the plase or the minus sign in the phasor.
	if(phase < 0){
		phasestr = textNum(-1*phase);
		setEquation(amplitude + " " + "cos" + "( "  + omega + "t - " + phasestr + " )" );
	}
	else{
		phasestr = textNum(phase);
		setEquation(amplitude + " " + "cos" + "( "  + omega + "t + " + phasestr + " )" );
	}

	
}

//function for rounding the signal.
void Signal::roundsig(){
	
	//goes through the vector and rounds all the values.
	for(int i = 0; i < nsamples; i++){
		sig[i] = round(sig[i]);

	}
	
}
	 
//function for adding two signals
Signal Signal::operator+(const Signal &obj){
	
	
	if(!(nsamples == obj.nsamples && itime == obj.itime && sampfreq == obj.sampfreq)){
		
		cout << "ERROR! Attempt to add incompatible signals.";
		exit(-1);
	}
	
	//declaring another object
	Signal temper(nsamples, sampfreq, itime);
	
	for(int i = 0; i < temper.nsamples; i++){
		
		temper.sig[i] = sig[i] + obj.sig[i];
		temper.time[i] = time[i];

	}
		
	temper.setEquation(obj.equation + " + " + equation); 
	
	return temper;
	
	
	
}
		


//MAIN FUNCTION
int main(){
	
	
	//delcaring a first signal object and initalizing it
	Signal obj1(401, 10000, -0.01);
	obj1.sinsignal(100,200, (-4*atan(1)/2)); 
	
	
	//creating a 2nd object
	Signal obj2(401, 10000, -0.01);
	obj2.setLabel("y");
	obj2.constsignal(250);
	
	
	Signal obj3; //declaring 3rd object

	obj3 = obj2 + obj1;

	obj3.roundsig();
	
	//printing the info to a text file and to the graph
	
	obj1.printinfo();
	obj2.printinfo(); 
	obj3.printinfo(); 

	
	
	return 0;
}

