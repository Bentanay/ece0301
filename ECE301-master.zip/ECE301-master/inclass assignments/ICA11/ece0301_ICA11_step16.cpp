
#include <iostream>
#include <cmath>
#include <string>
#include <fstream>
#include <vector>

#include "Signal.h"
#include "Signal.cpp"

using std:: cout;
using std:: endl;
using std:: string;
using std:: ofstream;
using std:: vector;


//MAIN FUNCTION
int main(){
	
	const double pi = 4* atan(1);
	
	
	//creates m signal, names it, and make its a sinusoid.
	Signal m(401, 10000, 0);
	m.setLabel("m");
	m.sinsignal(0.5,50,0);
	
	//creates w signal, names it, and make its a constant signal.
	Signal w(401, 10000, 0);
	w.setLabel("w");
	w.constsignal(1);
	
	//creates x signal, names it, and make its a the addition of m and w signal.
	Signal x(401, 10000, 0);
	x.setLabel("x");
	x= m+w;
	
	//creates y signal and makes it a sinusoid.
	Signal y(401, 10000, 0);
	y.setLabel("y");
	y.sinsignal(120, 2000, -pi/4.0);
	
	//created a z signal and makes it x times y. 
	Signal z(401, 10000, 0);
	z.setLabel("z");
	z = x*y;
	
	
	
	//rounding all the signals
	m.roundsig();
	w.roundsig();
	x.roundsig();
	y.roundsig();
	z.roundsig();
	
	
	//printing out all the info.
	m.printinfo();
	w.printinfo();
	x.printinfo();
	y.printinfo();
	z.printinfo();

	
	return 0;
}

