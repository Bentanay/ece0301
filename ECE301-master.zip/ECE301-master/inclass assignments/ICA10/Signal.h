
#ifndef SIGNAL_H
#define SIGNAL_H

#include <string>
#include <fstream> 
#include <iostream>

using std::cout; //using standard for cout statements.
using std::endl; //using standard for endl statements.
using std::string; //using standard for strings.
using std::ofstream; //using standard for ofstream objects
using std::ifstream; //using strandard for ifstream objects
using std::string; //using standard for strings


//Class Declaration for signal
class Signal{
	private:
		unsigned int nsamples; //for storing num of samples
		double frequency; //for storing the sampling frequency
		double itime;  //for storing the initial time
		double *sigptr; //pointer to an array that stores the signal samples
		double *timeptr;  //pointer to an array that stores the time samples
		string filename; //string for holding the filename for writing out the samples.
		
	public:
		
		Signal(); //default constructor
		Signal(unsigned int,double,double); //overloaded constructor
		~Signal(); //deconstructor
		void setnSamples(int); //mutator for setting number of samples
		void setFrequency(double); //mutator for setting the sampling frequency
		void setiTime(double); //mutator for setting the inital time
		void setFilename(string); //mutator for setting the file name.
		int getnSamples() const; //getter for getting the num of smaples
		double getFrequency() const; //getter for getting the smapling frequencies
		double getiTime() const; //getter for getting the initial time
		double * getSigPtr() const; //getter for getting the pointer to the sample array
		double * getTimePtr() const; //getter for getting the pointer to the time array
		void zerofill(); //function for initializing the array to all zeros.
		void filltime(); //function for initalizing the time array to equal divisions
		void writeinfo(); //function that writes the signal to a file.
		void fillsine(double, double, double); //function that fills signal array with a sinusoid signal
		void round(); //function for rounding the elements in the array
		void printgraph();  //function for using MATHGL to print a graph
		
		
	
};

#endif
