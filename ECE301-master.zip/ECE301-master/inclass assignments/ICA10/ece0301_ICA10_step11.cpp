#include <iostream>
#include <fstream> 
#include <cmath>
#include <string>
#include <mgl2/mgl.h>
#include "Signal.h"
#include "Signal.cpp"
using std::cout; //using standard for cout statements.
using std::endl; //using standard for endl statements.
using std::string; //using standard for strings.
using std::ofstream; //using standard for ofstream objects
using std::ifstream; //using strandard for ifstream objects
using std::string; //using standard for strings






//function for reading information from a text file
unsigned int readfile(double &, double &, double &, double &, double &);


//MAIN FUNCTION
int main(){
	
	//declaring variables for the object and for making the sinusoidual signal
	unsigned int nsample;
	double sampfreq, itime, amp, freq, phase;
	
	//calling the read file function to read all the data from the file/
	nsample = readfile(sampfreq, itime, amp, freq, phase);
	
	//declaring a signal object
	Signal obj1 = Signal(nsample,sampfreq,itime);
	
	//filling s(t) 
	obj1.fillsine(amp,freq,phase);
	
	obj1.round(); //rounding all the values
	
	
	//setting the file name.
	obj1.setFilename("time_domain_signal_samples");
	
	//outputting the object data to the file.
	obj1.writeinfo();
	
	//prints the output graph
	obj1.printgraph(); 
	

	return 0;
}


//function for reading information from a text file
unsigned int readfile(double &sampfreq, double &itime, double &amp, double &freq, double &phase){
	
	//declaring an ifstream object
	ifstream textin("sine_wave_specification.txt");
	
	//declaring string variable for storing the lines of the file.
	string line;
	
	//getting the 1st line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Number of samples: " != line.substr(0, 19)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the number of samples from the line.
	unsigned int nsamples = stoi(line.substr(18, line.length()-18));
	
	
	//getting the 2nd line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Sampling frequency: " != line.substr(0, 20)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the samp freq from the line.
	sampfreq = stod(line.substr(19, line.length()-19));
	
	
	//getting the 3rd line.
	getline(textin,line);
	
	//error checking the line heading
	if("Initial time: " != line.substr(0, 14)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the initial time from the line.
	itime = stod(line.substr(13, line.length()-13));
	
	
	//getting the 4th line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Amplitude: " != line.substr(0, 11)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the emp  from the line.
	amp = stod(line.substr(10, line.length()- 10 ));
	
	
	
	//getting the 5th line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Frequency: " != line.substr(0, 11)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the frequency  from the line.
	freq = stod(line.substr(10, line.length()- 10 ));
	
	
	
	//getting the 6th line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Phase: " != line.substr(0, 7)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the phase number from the line.
	phase = stod(line.substr(6, line.length()- 6 ));

	textin.close(); //closing the text file
	
	return nsamples; //returning the number of samples
	
	
}




