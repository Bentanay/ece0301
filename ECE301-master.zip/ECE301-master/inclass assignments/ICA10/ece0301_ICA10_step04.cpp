#include <iostream>
#include <fstream>
using std::cout; //using standard for cout statements.
using std::endl; //using standard for endl statements.
using std::string; //using standard for strings.
using std::ofstream; //using standard for ofstream objects


//Class Declaration for signal
class Signal{
	private:
		unsigned int nsamples; //for storing num of samples
		double frequency; //for storing the sampling frequency
		double itime;  //for storing the initial time
		double *sigptr; //pointer to an array that stores the signal samples
		double *timeptr;  //pointer to an array that stores the time samples
		string filename; //string for holding the filename for writing out the samples.

	public:

		Signal(); //default constructor
		~Signal(); //deconstructor
		void setnSamples(int); //mutator for setting number of samples
		void setFrequency(double); //mutator for setting the sampling frequency
		void setiTime(double); //mutator for setting the inital time
		void setFilename(string); //mutator for setting the file name.
		int getnSamples() const; //getter for getting the num of smaples
		double getFrequency() const; //getter for getting the smapling frequencies
		double getiTime() const; //getter for getting the initial time
		double * getSigPtr() const; //getter for getting the pointer to the sample array
		double * getTimePtr() const; //getter for getting the pointer to the time array
		void zerofill(); //function for initializing the array to all zeros.
		void filltime(); //function for initalizing the time array to equal divisions
		void writeinfo(); //function that writes the signal to a file.




};

//default constructor
Signal::Signal(){
	//initalizing the member variables to their default values.
	nsamples = 101;
	frequency = 100.0;
	itime = 0.0;
	filename ="tdsig"; //initializing the filename.
	sigptr = new double[nsamples]; //allocating memory for the sample array
	timeptr = new double[nsamples]; //allocating memory for the time array
	zerofill(); //filling the new array with all zeros
	filltime(); //filling the time array with the right values.
}
//deconstructor
Signal::~Signal(){
	//frees the memory
	delete sigptr;
	delete timeptr;
	

}

 //mutator for setting number of samples
void Signal::setnSamples(int s){
	nsamples = s;
}

//mutator for setting the sampling frequency
void Signal::setFrequency(double f){
	frequency = f;
}

//mutator for setting the inital time
void Signal::setiTime(double t){
	itime = t;
}

//mutator for setting the file name.
void Signal::setFilename(string name){
	filename =name;
}

//getter for getting the num of smaples
int Signal::getnSamples() const{
	return nsamples;
}

//getter for getting the smapling frequencies
double Signal::getFrequency() const{
	return frequency;
}

//getter for getting the initial time
double Signal::getiTime() const{
	return itime;
}

//getter for getting the pointer to the sample array
double * Signal::getSigPtr() const{
	return sigptr;
}

//getter for getting the pointer to the time array
double * Signal::getTimePtr() const{
	return timeptr;
}

//function for initializing the array to all zeros.
void Signal::zerofill(){

	//for loop for looping through the array and setting them all equal to zeros.
	for(int i =0; i< nsamples; i++){
		*(sigptr + i) = 0;
	}

}

 //function for initalizing the time array to equal divisions
void Signal::filltime(){

	double nextnum;  //declaring variable for storing the next num

	//for loop to loop through the array
	for(int i = 0; i < nsamples; i++){
		//calculating the next number to store in the array
		nextnum = itime + (i/frequency);

		//storing it in the actual array
		*(timeptr +i) = nextnum;
	}

}

//function that writes the signal to a file.
void Signal::writeinfo(){

	//declaring an output object
	ofstream output(filename + ".txt");

	//ouputting the object data to the file
	output << "ECE 0301: Time-Domain Signal Samples" << endl;
	output << "The number of samples is " << nsamples << endl;
	output << "The sample rate is " << frequency << endl;
	output << "The initial time is " << itime << endl;
	output << "Here is your signal:" << endl;
	output << "t, s(t)" << endl;

	//outpiting the time and the signal array to the file using the pointers.
	for(int i = 0; i < nsamples; i++){
		output << *(timeptr+i) << ", " << *(sigptr +i) <<endl;
	}


	//closing the output file.
	output.close();

}


//MAIN FUNCTION
int main(){

	//declaring a signal object
	Signal obj1;

	//setting the file name.
	obj1.setFilename("time_domain_signal_samples");

	//outputting the object data to the file.
	obj1.writeinfo();

	return 0;
}
