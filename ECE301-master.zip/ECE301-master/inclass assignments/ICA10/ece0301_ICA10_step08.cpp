#include <iostream>
#include <fstream> 
#include <cmath>
#include <string>
using std::cout; //using standard for cout statements.
using std::endl; //using standard for endl statements.
using std::string; //using standard for strings.
using std::ofstream; //using standard for ofstream objects
using std::ifstream; //using strandard for ifstream objects
using std::string; //using standard for strings


double const pi = 4*atan(1);


//Class Declaration for signal
class Signal{
	private:
		unsigned int nsamples; //for storing num of samples
		double frequency; //for storing the sampling frequency
		double itime;  //for storing the initial time
		double *sigptr; //pointer to an array that stores the signal samples
		double *timeptr;  //pointer to an array that stores the time samples
		string filename; //string for holding the filename for writing out the samples.
		
	public:
		
		Signal(); //default constructor
		Signal(unsigned int,double,double); //overloaded constructor
		~Signal(); //deconstructor
		void setnSamples(int); //mutator for setting number of samples
		void setFrequency(double); //mutator for setting the sampling frequency
		void setiTime(double); //mutator for setting the inital time
		void setFilename(string); //mutator for setting the file name.
		int getnSamples() const; //getter for getting the num of smaples
		double getFrequency() const; //getter for getting the smapling frequencies
		double getiTime() const; //getter for getting the initial time
		double * getSigPtr() const; //getter for getting the pointer to the sample array
		double * getTimePtr() const; //getter for getting the pointer to the time array
		void zerofill(); //function for initializing the array to all zeros.
		void filltime(); //function for initalizing the time array to equal divisions
		void writeinfo(); //function that writes the signal to a file.
		void fillsine(double, double, double); //function that fills signal array with a sinusoid signal
		void round(); //function for rounding the elements in the array
		
		
		
		
	
};

//default constructor
Signal::Signal(){
	//initalizing the member variables to their default values.
	nsamples = 101;
	frequency = 100.0;
	itime = 0.0;
	filename ="tdsig"; //initializing the filename.
	sigptr = new double[nsamples]; //allocating memory for the sample array
	timeptr = new double[nsamples]; //allocating memory for the time array
	zerofill(); //filling the new array with all zeros
	filltime(); //filling the time array with the right values.
}

//overloaded constructor
Signal::Signal(unsigned int nsamp ,double sampfreq ,double t){
	
	//initializing the member variables with the values passed in
	nsamples = nsamp;
	frequency = sampfreq;
	itime = t;
	
	//allocating memory for the arrays
	sigptr = new double[nsamples]; //allocating memory for the sample array
	timeptr = new double[nsamples]; //allocating memory for the time array
	zerofill(); //filling the new array with all zeros
	filltime(); //filling the time array with the right values.
	
	
}


//deconstructor
Signal::~Signal(){
	//frees the memory
	delete sigptr;
	delete timeptr;
	
}

 //mutator for setting number of samples
void Signal::setnSamples(int s){
	nsamples = s;
}

//mutator for setting the sampling frequency
void Signal::setFrequency(double f){
	frequency = f;
}

//mutator for setting the inital time
void Signal::setiTime(double t){
	itime = t;
}

//mutator for setting the file name.
void Signal::setFilename(string name){
	filename =name;
}

//getter for getting the num of smaples
int Signal::getnSamples() const{
	return nsamples;
}

//getter for getting the smapling frequencies
double Signal::getFrequency() const{
	return frequency;
}

//getter for getting the initial time
double Signal::getiTime() const{
	return itime;
}

//getter for getting the pointer to the sample array
double * Signal::getSigPtr() const{
	return sigptr;
}

//getter for getting the pointer to the time array
double * Signal::getTimePtr() const{
	return timeptr;
}

//function for initializing the array to all zeros.
void Signal::zerofill(){
	
	//for loop for looping through the array and setting them all equal to zeros.
	for(int i =0; i< nsamples; i++){
		*(sigptr + i) = 0;
	}
	
}

 //function for initalizing the time array to equal divisions
void Signal::filltime(){
	
	double nextnum;  //declaring variable for storing the next num
	
	//for loop to loop through the array
	for(int i = 0; i < nsamples; i++){
		//calculating the next number to store in the array
		nextnum = itime + (i/frequency);
		
		//storing it in the actual array
		*(timeptr +i) = nextnum;
	}
	
}

//function that writes the signal to a file.
void Signal::writeinfo(){
	
	//declaring an output object
	ofstream output(filename + ".txt");
	
	//ouputting the object data to the file
	output << "ECE 0301: Time-Domain Signal Samples" << endl;
	output << "The number of samples is " << nsamples << endl;
	output << "The sample rate is " << frequency << endl;
	output << "The initial time is " << itime << endl;
	output << "Here is your signal:" << endl;
	output << "t, s(t)" << endl;
	
	//outpiting the time and the signal array to the file using the pointers.
	for(int i = 0; i < nsamples; i++){
		output << *(timeptr+i) << ", " << *(sigptr +i) <<endl;
	}
	
	
	//closing the output file.
	output.close();
	
}

//function that fills signal array with a sinusoid signal
void Signal::fillsine(double amp, double freq, double phase){
	
	//for loop for looping through the array and setting them all equal to the value returned by the calculation
	for(int i =0; i< nsamples; i++){
		*(sigptr + i) = amp*cos(2*pi*freq*(*(timeptr+i)) + phase);
	}
	
}

//function for rounding the elements in the array
void Signal::round(){
	//for loop for looping through the array and rounding all of the values.
	for(int i =0; i< nsamples; i++){
		
		*(sigptr + i) = roundf(*(sigptr + i));
	}
	
	
	
}


//function for reading information from a text file
unsigned int readfile(double &, double &, double &, double &, double &);


//MAIN FUNCTION
int main(){
	
	//declaring variables for the object and for making the sinusoidual signal
	unsigned int nsample;
	double sampfreq, itime, amp, freq, phase;
	
	//calling the read file function to read all the data from the file/
	nsample = readfile(sampfreq, itime, amp, freq, phase);
	
	//declaring a signal object
	Signal obj1 = Signal(nsample,sampfreq,itime);
	
	//filling s(t) 
	obj1.fillsine(amp,freq,phase);
	
	obj1.round(); //rounding all the values
	
	//setting the file name.
	obj1.setFilename("time_domain_signal_samples");
	
	//outputting the object data to the file.
	obj1.writeinfo();

	return 0;
}


//function for reading information from a text file
unsigned int readfile(double &sampfreq, double &itime, double &amp, double &freq, double &phase){
	
	//declaring an ifstream object
	ifstream textin("sine_wave_specification.txt");
	
	//declaring string variable for storing the lines of the file.
	string line;
	
	//getting the 1st line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Number of samples: " != line.substr(0, 19)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the number of samples from the line.
	unsigned int nsamples = stoi(line.substr(18, line.length()-18));
	
	
	//getting the 2nd line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Sampling frequency: " != line.substr(0, 20)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the samp freq from the line.
	sampfreq = stod(line.substr(19, line.length()-19));
	
	
	//getting the 3rd line.
	getline(textin,line);
	
	//error checking the line heading
	if("Initial time: " != line.substr(0, 14)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the initial time from the line.
	itime = stod(line.substr(13, line.length()-13));
	
	
	//getting the 4th line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Amplitude: " != line.substr(0, 11)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the emp  from the line.
	amp = stod(line.substr(10, line.length()- 10 ));
	
	
	
	//getting the 5th line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Frequency: " != line.substr(0, 11)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the frequency  from the line.
	freq = stod(line.substr(10, line.length()- 10 ));
	
	
	
	//getting the 6th line.
	getline(textin,line);
	
	
	//error checking the line heading
	if("Phase: " != line.substr(0, 7)){
		
		//exiting with the error code
		cout << "ERROR! Invalid input file header.";
		exit(-1);
		
	}
	
	//extracting the phase number from the line.
	phase = stod(line.substr(6, line.length()- 6 ));

	textin.close(); //closing the text file
	
	return nsamples; //returning the number of samples
		
	
	
	
	
}




