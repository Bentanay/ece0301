#include <iostream>
#include <fstream> 
#include <cmath>
#include <string>
#include <mgl2/mgl.h>

#include "Signal.h"

//default constructor
Signal::Signal(){
	//initalizing the member variables to their default values.
	nsamples = 101;
	frequency = 100.0;
	itime = 0.0;
	filename ="tdsig"; //initializing the filename.
	sigptr = new double[nsamples]; //allocating memory for the sample array
	timeptr = new double[nsamples]; //allocating memory for the time array
	zerofill(); //filling the new array with all zeros
	filltime(); //filling the time array with the right values.
}

//overloaded constructor
Signal::Signal(unsigned int nsamp ,double sampfreq ,double t){
	
	//initializing the member variables with the values passed in
	nsamples = nsamp;
	frequency = sampfreq;
	itime = t;
	
	//allocating memory for the arrays
	sigptr = new double[nsamples]; //allocating memory for the sample array
	timeptr = new double[nsamples]; //allocating memory for the time array
	zerofill(); //filling the new array with all zeros
	filltime(); //filling the time array with the right values.
	
	
}


//deconstructor
Signal::~Signal(){
	//frees the memory
	delete sigptr;
	delete timeptr;
	
}

 //mutator for setting number of samples
void Signal::setnSamples(int s){
	nsamples = s;
}

//mutator for setting the sampling frequency
void Signal::setFrequency(double f){
	frequency = f;
}

//mutator for setting the inital time
void Signal::setiTime(double t){
	itime = t;
}

//mutator for setting the file name.
void Signal::setFilename(string name){
	filename =name;
}

//getter for getting the num of smaples
int Signal::getnSamples() const{
	return nsamples;
}

//getter for getting the smapling frequencies
double Signal::getFrequency() const{
	return frequency;
}

//getter for getting the initial time
double Signal::getiTime() const{
	return itime;
}

//getter for getting the pointer to the sample array
double * Signal::getSigPtr() const{
	return sigptr;
}

//getter for getting the pointer to the time array
double * Signal::getTimePtr() const{
	return timeptr;
}

//function for initializing the array to all zeros.
void Signal::zerofill(){
	
	//for loop for looping through the array and setting them all equal to zeros.
	for(int i =0; i< nsamples; i++){
		*(sigptr + i) = 0;
	}
	
}

 //function for initalizing the time array to equal divisions
void Signal::filltime(){
	
	double nextnum;  //declaring variable for storing the next num
	
	//for loop to loop through the array
	for(int i = 0; i < nsamples; i++){
		//calculating the next number to store in the array
		nextnum = itime + (i/frequency);
		
		//storing it in the actual array
		*(timeptr +i) = nextnum;
	}
	
}

//function that writes the signal to a file.
void Signal::writeinfo(){
	
	//declaring an output object
	ofstream output(filename + ".txt");
	
	//ouputting the object data to the file
	output << "ECE 0301: Time-Domain Signal Samples" << endl;
	output << "The number of samples is " << nsamples << endl;
	output << "The sample rate is " << frequency << endl;
	output << "The initial time is " << itime << endl;
	output << "Here is your signal:" << endl;
	output << "t, s(t)" << endl;
	
	//outpiting the time and the signal array to the file using the pointers.
	for(int i = 0; i < nsamples; i++){
		output << *(timeptr+i) << ", " << *(sigptr +i) <<endl;
	}
	
	
	//closing the output file.
	output.close();
	
}

//function that fills signal array with a sinusoid signal
void Signal::fillsine(double amp, double freq, double phase){
	
	//for loop for looping through the array and setting them all equal to the value returned by the calculation
	for(int i =0; i< nsamples; i++){
		*(sigptr + i) = amp*cos(2*(4*atan(1))*freq*(*(timeptr+i)) + phase);
	}
	
}

//function for rounding the elements in the array
void Signal::round(){
	//for loop for looping through the array and rounding all of the values.
	for(int i =0; i< nsamples; i++){
		
		*(sigptr + i) = roundf(*(sigptr + i));
	}
	
	
	
}
 //function for using MATHGL to print a graph
void Signal::printgraph(){
	
	//creating the math gl objects
	mglData t_mgl(nsamples), s_mgl(nsamples); 
	double timearr[nsamples], sigarray[nsamples];
	
	//looping through the pointers to get the arrays.
	for( int i =0; i < nsamples; i++){
		timearr[i] = *(timeptr +i);
		sigarray[i] = *(sigptr +i);
	}
	
	//setting the array to te math gl object
	t_mgl.Set(timearr,nsamples);
	s_mgl.Set(sigarray,nsamples);
	
	
	// Create mglGraph object
	mglGraph gr;
	
	gr.Title("Plot of Sinusoidal Signal");
	
	
	double min = timearr[0], max = timearr[0];
	
	//for looping through and getting the min and the max of the time signal
	for(int i =0; i < nsamples; i++){
		//getting the min
		if( min > t_mgl[i]){
			min = t_mgl[i];
			
		}
		//getting the max
		if( max < t_mgl[i]){
			max = t_mgl[i];
		}
	}
	
	//for looping through and getting the max absolute value from the signal
	double maxabs = abs(s_mgl[0]);
	
	for(int i = 0; i < nsamples; i++){
		
		//getting the max absolute value.
		if(maxabs <  abs(s_mgl[i])){
			maxabs = abs(s_mgl[i]);
		}
		
	}
	
	//////////////////IMPORTANT NOTE, I ACCIDENTALLY MODIFIIED THIS WHEN I MEANT TO MODIFY SOMETHING ELSE, IT MIGHT NOT WORK ANYMORE CAUSE I DIDNT
	//RECOMPILE AND RERUN IT. ////////////////////////////////////////////////// I WAS CHANGING SOME OF THE AXIS STUFF
	
	
	// Set axis ranges as (x start, x end, y start, y end)
	gr.SetRanges(min, max, -maxabs, maxabs);
	
	//setting the origin of the plot
	gr.SetOrigin(0, 0);
	
	//setting the horizontal axis tick marks
	gr.SetTicks('x', (max-min)/8, 0, min, "");
	
	//gr.SetTicks('y', (maxabs-(-maxabs))/4, 0, -maxabs, "");
	
	gr.Axis();
	
	// Put a string at (start point, end point, string value)
	gr.Puts(mglPoint(min, -0.1), mglPoint(min, 0.1), (label + "(t)");
	
	// Same as above, but string is horizontal if no second point is given
	gr.Puts(mglPoint((max + min)/2+(max+min)/4, maxabs/3), "t");
	
	//plotting the two signals
	gr.Plot(t_mgl, s_mgl);
	
	//generating the strings
	string eps = filename +".eps", png  = filename + ".png"; 
	
	//writing the files.
	gr.WriteEPS(eps.c_str());
	gr.WritePNG(png.c_str());
	
	
}
