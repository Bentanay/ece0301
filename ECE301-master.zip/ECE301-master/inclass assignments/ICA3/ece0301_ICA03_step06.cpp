
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>


using namespace std;

int main()
{
	cout << "ECE 0301 – Vectors in R2 and Complex Numbers\n"
		 <<"Please enter two numbers, separated by a space,\n"
		 <<"that will represent a vector or a complex number.\n\n";
		 
	double pi=atan(1)*4; //Definting the value of pi.

	double num1, num2; //Creating two variables to store two numbers inputted by the user.
	cin >> num1 >> num2; //Reading in two variables.
	
	//Displays output to the user, displaying three decimal places of the number they entered. 
	cout << "You entered "<< setprecision(3) << fixed << num1 << " and "<< num2 << ".\n\n";

	string response; 
	
	//Asking user if they entered cartesian or polar coordinates.
	cout << "Are these numbers in Cartesian (C) or polar (p) coordinates?\n";  
	cout << "Please enter a single character as your choice.\n";
	cin >> response;
	
	//Testing if the response is equal to the acceptable responses this program can handle. 
	if(response == "c" || response == "C" || response == "p" || response == "P"){
		
		//Declares all the necessary variables for the computation and assigns them the numbers inputted from the user. 
		double radius = num1, theta = num2, x = num1, y= num2; 
		
		//If the response is equal to the corresponding letters for cartesian. 
		if(response == "c" || response == "C"){
			
			//Tell the user what the entered and show the equivalent polar coordinates. 
			cout << "You entered Cartesian coordinates.\n";
			cout << "The equivalent polar coordinates are:\n";
			
			//Calcute the corresponding polar coordinates.
			radius = sqrt(pow(x,2)+pow(y,2)); //Calculates R
			
			
			//Calculating the theta. Branching structure is for determining which equation to use. 
			if(x>= 0){
				theta = atan(y/x); //Calculates theta using formula for given range for x and y. 
			}
			else if( x< 0 && y >= 0){
				theta = atan(y/x) + pi; //Calculates theta using formula for given range for x and y. 
				
			}
			else if(x < 0 && y < 0){
				theta = atan(y/x) - pi; //Calculates theta using formula for given range for x and y. 
				
			}
			
			//Prints out the calculated R and theta. 
			cout << setprecision(3) << fixed << "R = " << radius << ", theta = " << theta << endl;
			
			
		}
		else{
			//Confirming inputs for polar coordinates. 
			if(radius < 0 || theta < (-1 *pi) || theta > pi){
				// Telling user theres an error. 
				cout << "ERROR! Invalid polar coordinates, exiting.";
				return -1;
			}
			else{
				//Telling user what they entered. 
				cout << "You entered polar coordinates." << endl;
				cout << "The equivalent cartesian coordinates are:\n";

				//Calculate the corresponding x and y from the polar coordinates. 
				x= radius*cos(theta);
				y= radius*sin(theta);
				
				cout << setprecision(3) << fixed << "X = " << x << ", Y = " << y << endl;
			}

		}
	}
	else{
		//Telling user there is an invalid error. 
		cout << "ERROR! Invalid selection, exiting.";
		
		return -1; 
	}
	
	//------------------------------------------------------------------------
	//Prompting user to enter two numbers again.
	cout <<"Please enter two numbers, separated by a\nspace, to represent a second vector or complex number.\n\n";
		 
	double num3, num4; //Creating two more variables to store two numbers inputted by the user.
	cin >> num3 >> num4; //Reading in two variables.
	
	//Displays output to the user, displaying three decimal places of the number they entered. 
	cout << "You entered "<< setprecision(3) << fixed << num3 << " and "<< num4 << ".\n\n";
	
	//Asking user if they entered cartesian or polar coordinates.
	cout << "Are these numbers in Cartesian (C) or polar (p) coordinates?\n";  
	cout << "Please enter a single character as your choice.\n";
	cin >> response;
	
	//Testing if the response is equal to the acceptable responses this program can handle. 
	if(response == "c" || response == "C" || response == "p" || response == "P"){
		
		//Declares all the necessary variables for the computation and assigns them the numbers inputted from the user. 
		double radius = num3, theta = num4, x = num3, y= num4; 
		
		//If the response is equal to the corresponding letters for cartesian. 
		if(response == "c" || response == "C"){
			
			//Tell the user what the entered and show the equivalent polar coordinates. 
			cout << "You entered Cartesian coordinates.\n";
			cout << "The equivalent polar coordinates are:\n";
			
			//Calcute the corresponding polar coordinates.
			radius = sqrt(pow(x,2)+pow(y,2)); //Calculates R
			
			
			//Calculating the theta. Branching structure is for determining which equation to use. 
			if(x>= 0){
				theta = atan(y/x); //Calculates theta using formula for given range for x and y. 
			}
			else if( x< 0 && y >= 0){
				theta = atan(y/x) + pi; //Calculates theta using formula for given range for x and y. 
				
			}
			else if(x < 0 && y < 0){
				theta = atan(y/x) - pi; //Calculates theta using formula for given range for x and y. 
				
			}
			
			//Prints out the calculated R and theta. 
			cout << setprecision(3) << fixed << "R = " << radius << ", theta = " << theta <<endl;
			
			
		}
		else{
			//Confirming inputs for polar coordinates. 
			if(radius < 0 || theta < (-1 *pi) || theta > pi){
				// Telling user theres an error. 
				cout << "ERROR! Invalid polar coordinates, exiting.";
				return -1;
			}
			else{
				//Telling user what they entered. 
				cout << "You entered polar coordinates.\n";
				cout << "The equivalent cartesian coordinates are:\n";

				//Calculate the corresponding x and y from the polar coordinates. 
				x= radius*cos(theta);
				y= radius*sin(theta);
				
				cout << setprecision(3) << fixed << "X = " << x << ", Y = " << y <<endl;
			}

		}
	}
	else{
		//Telling user there is an invalid error. 
		cout << "ERROR! Invalid selection, exiting.";
		
		return -1; 
	}
	
	
	
	return 0;
}
