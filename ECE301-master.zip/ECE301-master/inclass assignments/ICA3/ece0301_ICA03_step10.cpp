
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>


using namespace std;

int main()
{
	cout << "ECE 0301 – Vectors in R2 and Complex Numbers\n"
		 <<"Please enter two numbers, separated by a space,\n"
		 <<"that will represent a vector or a complex number.\n\n";
		 
	double pi=atan(1)*4; //Definting the value of pi.

	double r1, t1, x1, y1, r2, t2, x2, y2; //Global varuiables for the vectors. 

	double num1, num2; //Creating two variables to store two numbers inputted by the user.
	cin >> num1 >> num2; //Reading in two variables.
	
	//Displays output to the user, displaying three decimal places of the number they entered. 
	cout << "You entered "<< setprecision(3) << fixed << num1 << " and "<< num2 << ".\n\n";

	string response1; 
	
	//Asking user if they entered cartesian or polar coordinates.
	cout << "Are these numbers in Cartesian (C) or polar (p) coordinates?\n";  
	cout << "Please enter a single character as your choice.\n";
	cin >> response1;
	
	//Testing if the response is equal to the acceptable responses this program can handle. 
	if(response1 == "c" || response1 == "C" || response1 == "p" || response1 == "P"){
		
		//Declares all the necessary variables for the computation and assigns them the numbers inputted from the user. 
		double radius = num1, theta = num2, x = num1, y= num2; 
		
		//If the response is equal to the corresponding letters for cartesian. 
		if(response1 == "c" || response1 == "C"){
			
			//Tell the user what the entered and show the equivalent polar coordinates. 
			cout << "You entered Cartesian coordinates.\n";
			cout << "The equivalent polar coordinates are:\n";
			
			//Calcute the corresponding polar coordinates.
			radius = sqrt(pow(x,2)+pow(y,2)); //Calculates R
			
			
			//Calculating the theta. Branching structure is for determining which equation to use. 
			if(x>= 0){
				theta = atan(y/x); //Calculates theta using formula for given range for x and y. 
			}
			else if( x< 0 && y >= 0){
				theta = atan(y/x) + pi; //Calculates theta using formula for given range for x and y. 
				
			}
			else if(x < 0 && y < 0){
				theta = atan(y/x) - pi; //Calculates theta using formula for given range for x and y. 
				
			}
			
			//Making ther variables so they can be accessed later.
			r1 = radius; 
			t1 = theta;
			
			//Prints out the calculated R and theta. 
			cout << setprecision(3) << fixed << "R = " << radius << ", theta = " << theta << endl;
			
			
		}
		else{
			//Confirming inputs for polar coordinates. 
			if(radius < 0 || theta < (-1 *pi) || theta > pi){
				// Telling user theres an error. 
				cout << "ERROR! Invalid polar coordinates, exiting.";
				return -1; //Ending the program.
			}
			else{
				//Telling user what they entered. 
				cout << "You entered polar coordinates." << endl;
				cout << "The equivalent cartesian coordinates are:\n";

				//Calculate the corresponding x and y from the polar coordinates. 
				x= radius*cos(theta);
				y= radius*sin(theta);
				
				//Making ther variables so they can be accessed later.
				x1 =  x;
				y1 = y;
				
				cout << setprecision(3) << fixed << "X = " << x << ", Y = " << y << endl;
			}

		}
	}
	else{
		//Telling user there is an invalid error. 
		cout << "ERROR! Invalid selection, exiting.";
		
		return -1; 
	}
	
	//------------------------------------------------------------------------
	//Prompting user to enter two numbers again.
	cout <<"Please enter two numbers, separated by a\nspace, to represent a second vector or complex number.\n\n";
		 
	double num3, num4; //Creating two more variables to store two numbers inputted by the user.
	cin >> num3 >> num4; //Reading in two variables.
	
	//Displays output to the user, displaying three decimal places of the number they entered. 
	cout << "You entered "<< setprecision(3) << fixed << num3 << " and "<< num4 << ".\n\n";
	
	string response2; //Storing the second response
	
	//Asking user if they entered cartesian or polar coordinates.
	cout << "Are these numbers in Cartesian (C) or polar (p) coordinates?\n";  
	cout << "Please enter a single character as your choice.\n";
	cin >> response2;
	
	//Testing if the response is equal to the acceptable responses this program can handle. 
	if(response2 == "c" || response2 == "C" || response2 == "p" || response2 == "P"){
		
		//Declares all the necessary variables for the computation and assigns them the numbers inputted from the user. 
		double radius = num3, theta = num4, x = num3, y= num4; 
		
		//If the response is equal to the corresponding letters for cartesian. 
		if(response2 == "c" || response2 == "C"){
			
			//Tell the user what the entered and show the equivalent polar coordinates. 
			cout << "You entered Cartesian coordinates.\n";
			cout << "The equivalent polar coordinates are:\n";
			
			//Calcute the corresponding polar coordinates.
			radius = sqrt(pow(x,2)+pow(y,2)); //Calculates R
			
			
			//Calculating the theta. Branching structure is for determining which equation to use. 
			if(x>= 0){
				theta = atan(y/x); //Calculates theta using formula for given range for x and y. 
			}
			else if( x< 0 && y >= 0){
				theta = atan(y/x) + pi; //Calculates theta using formula for given range for x and y. 
				
			}
			else if(x < 0 && y < 0){
				theta = atan(y/x) - pi; //Calculates theta using formula for given range for x and y. 
				
			}
			
			//Making ther variables so they can be accessed later.
			r2 = radius; 
			t2 = theta;
			
			//Prints out the calculated R and theta. 
			cout << setprecision(3) << fixed << "R = " << radius << ", theta = " << theta <<endl;
			
			
		}
		else{
			//Confirming inputs for polar coordinates. 
			if(radius < 0 || theta < (-1 *pi) || theta > pi){
				// Telling user theres an error. 
				cout << "ERROR! Invalid polar coordinates, exiting.";
				return -1; //Ending the program.
			}
			else{
				//Telling user what they entered. 
				cout << "You entered polar coordinates.\n";
				cout << "The equivalent cartesian coordinates are:\n";

				//Calculate the corresponding x and y from the polar coordinates. 
				x= radius*cos(theta);
				y= radius*sin(theta);
				
				//Making ther variables so they can be accessed later.
				x2 = x; 
				y2 = y;
				
				cout << setprecision(3) << fixed << "X = " << x << ", Y = " << y <<endl;
			}

		}
	}
	else{
		//Telling user there is an invalid error. 
		cout << "ERROR! Invalid selection, exiting.";
		
		return -1; //Ending the program.
	}
	
	cout << endl;
	
	string responseVC; 
	
	cout << "Do the values you entered represent vectors (v) or complex numbers (c)?\n";
	cout << "Please enter a single character as your choice.\n";
	
	cin >> responseVC;
	
	if( responseVC == "v" || responseVC == "V" || responseVC == "C" || responseVC == "c" ){
		
		//Displaying as vectors. 
		if( responseVC == "v" || responseVC == "V"){
			
			//Branching block for determining which variables to use, the ones the user entered or the ones that were calculated.  
			if(response1 == "c" || response1 == "C"){
				//Diplaying the points as vector coordinates.
				cout << "Cartesian:\tv1 = (" << num1 << ", " << num2 << ")\n";
				cout << "Polar:\t\tv1 = (" << r1 << ", " << t1 << ")\n";
				
				//Reassigning the proper variables to the global variables for use later on.
				x1 = num1;
				y1 = num2;
			}
			
			else{
				//Diplaying the points as vector coordinates.
				cout << "Cartesian:\tv1 = (" << x1 << ", " << y1 << ")\n";
				cout << "Polar:\t\tv1 = (" << num1 << ", " << num2 << ")\n";
				
				//Reassigning the proper variables to the global variables for use later on.
				r1 = num1;
				t1 = num2;
				
			}
			
			cout << endl; //Prints a blank line. 
			
			//Branching block for determining which variables to use, the ones the user entered or the ones that were calculated.
			if(response2 == "c" || response2 == "C"){
				//Diplaying the points as vector coordinates.
				cout << "Cartesian:\tv1 = (" << num3 << ", " << num4 << ")\n";
				cout << "Polar:\t\tv1 = (" << r2 << ", " << t2 << ")\n";
				
				//Reassigning the proper variables to the global variables for use later on.
				x2 = num3;
				y2 = num4;
				
			}
			else{
				//Diplaying the points as vector coordinates.
				cout << "Cartesian:\tv1 = (" << x2 << ", " << y2 << ")\n";
				cout << "Polar:\t\tv1 = (" << num3 << ", " << num4 << ")\n";	
				
				//Reassigning the proper variables to the global variables for use later on.
				r2 = num3;
				t2 = num4;
			}
			
			cout << endl;
			
			int menuchoice; //Variable to store menu choice.
			
			//Prompting selection from menu.
			cout << "Which of the following vector sums or differences\nwould you like to compute?\n";
			//Displaying the menu.
			cout << "(1) v1 + v2\n";
			cout << "(2) v1 - v2\n";
			cout << "(3) v2 - v1\n";
			cout << "(4) -v1 - v2\n" << endl;
			
			cin >> menuchoice; //Reading in menuchoice
			
			//declaring variables for vector calculations.
			double coor1cart, coor2cart, radiusconver, thetaconver= 0;
			
			
			switch(menuchoice){
				case 1:
					
					
					coor1cart = x1 + x2; //Adds the first component of the vectors.
					coor2cart = y1 + y2; //Adds the second componet of the vectors. 
					
					radiusconver = sqrt(pow(coor1cart,2)+pow(coor2cart,2)); //Calculates R
					
					//Calculating the theta. Branching structure is for determining which equation to use. 
					if(coor1cart>= 0){
						thetaconver = atan(coor2cart/coor1cart); //Calculates theta using formula for given range for x and y. 
					}
					else if( coor1cart< 0 && coor2cart >= 0){
						thetaconver = atan(coor2cart/coor1cart) + pi; //Calculates theta using formula for given range for x and y. 
						
					}
					else if(coor1cart < 0 && coor2cart < 0){
						thetaconver = atan(coor2cart/coor1cart) - pi; //Calculates theta using formula for given range for x and y. 
						
					}
					
					//Displays ther results of the calculations.
					cout << "Sum, Cartesian:\tv_sum = (" << coor1cart <<", " << coor2cart << ")" << endl;
					cout << "Sum, Polar:\tv_sum = ("  <<radiusconver <<", " << thetaconver  <<")" << endl;
					
					break;
					
				case 2:
				
					coor1cart = x1 - x2; //Adds the second componet of the vectors. 
					coor2cart = y1 - y2; //Adds the second componet of the vectors. 
					
					radiusconver = sqrt(pow(coor1cart,2)+pow(coor2cart,2)); //Calculates R
					
					//Calculating the theta. Branching structure is for determining which equation to use. 
					if(coor1cart>= 0){
						thetaconver = atan(coor2cart/coor1cart); //Calculates theta using formula for given range for x and y. 
					}
					else if( coor1cart< 0 && coor2cart >= 0){
						thetaconver = atan(coor2cart/coor1cart) + pi; //Calculates theta using formula for given range for x and y. 
						
					}
					else if(coor1cart < 0 && coor2cart < 0){
						thetaconver = atan(coor2cart/coor1cart) - pi; //Calculates theta using formula for given range for x and y. 
						
					}
					
					//Displays ther results of the calculations.
					cout << "Sum, Cartesian:\tv_sum = (" << coor1cart <<", " << coor2cart << ")" << endl;
					cout << "Sum, Polar:\tv_sum = ("  <<radiusconver <<", " << thetaconver  <<")" << endl;
				
					break;
					
					
				case 3:
					
					coor1cart = x2 - x1; //Adds the second componet of the vectors. 
					coor2cart = y2 - y1; //Adds the second componet of the vectors. 
					
					radiusconver = sqrt(pow(coor1cart,2)+pow(coor2cart,2)); //Calculates R
					
					//Calculating the theta. Branching structure is for determining which equation to use. 
					if(coor1cart>= 0){
						thetaconver = atan(coor2cart/coor1cart); //Calculates theta using formula for given range for x and y. 
					}
					else if( coor1cart< 0 && coor2cart >= 0){
						thetaconver = atan(coor2cart/coor1cart) + pi; //Calculates theta using formula for given range for x and y. 
						
					}
					else if(coor1cart < 0 && coor2cart < 0){
						thetaconver = atan(coor2cart/coor1cart) - pi; //Calculates theta using formula for given range for x and y. 
						
					}
					
					//Displays ther results of the calculations.
					cout << "Sum, Cartesian:\tv_sum = (" << coor1cart <<", " << coor2cart << ")" << endl;
					cout << "Sum, Polar:\tv_sum = ("  <<radiusconver <<", " << thetaconver  <<")" << endl;
					
					break;
					
				case 4:
				
					coor1cart = -x1 - x2; //Adds the second componet of the vectors. 
					coor2cart = -y1 - y2; //Adds the second componet of the vectors. 
					
					radiusconver = sqrt(pow(coor1cart,2)+pow(coor2cart,2)); //Calculates R
					
					//Calculating the theta. Branching structure is for determining which equation to use. 
					if(coor1cart>= 0){
						thetaconver = atan(coor2cart/coor1cart); //Calculates theta using formula for given range for x and y. 
					}
					else if( coor1cart< 0 && coor2cart >= 0){
						thetaconver = atan(coor2cart/coor1cart) + pi; //Calculates theta using formula for given range for x and y. 
						
					}
					else if(coor1cart < 0 && coor2cart < 0){
						thetaconver = atan(coor2cart/coor1cart) - pi; //Calculates theta using formula for given range for x and y. 
						
					}
					
					//Displays ther results of the calculations.
					cout << "Sum, Cartesian:\tv_sum = (" << coor1cart <<", " << coor2cart << ")" << endl;
					cout << "Sum, Polar:\tv_sum = ("  <<radiusconver <<", " << thetaconver  <<")" << endl;
				
					break;
				
				default:
					//Telling the user their response was invalid.
					cout << "ERROR! Invalid selection, exiting.";
					return -1; //terminating the program
				}
				
					
			
			
		} else{
			
			//Branching block for determining which variables to use, the ones the user entered or the ones that were calculated.  
			if(response1 == "c" || response1 == "C"){
				//Diplaying the points as complex numbers.
				cout << "Cartesian:\tz1 = " << num1 << " + j " << num2 << "\n";
				cout << "Polar:\t\tz1 = " << r1 << " exp(j " << t1 << ")\n";
				
				//Reassigning the proper variables to the global variables for use later on.
				x1 = num1;
				y1 = num2;
				
			}
			
			else{
				//Diplaying the points as complex numbers.
				cout << "Cartesian:\tz1 = " << x1 << " + j " << y1 << "\n";
				cout << "Polar:\t\tz1 = " << num1 << " exp(j " << num2 << ")\n";
				
				//Reassigning the proper variables to the global variables for use later on.
				r1 = num1;
				t1 = num2;
				
			}
			
			cout << endl; //Prints a blank line. 
			
			//Branching block for determining which variables to use, the ones the user entered or the ones that were calculated.
			if(response2 == "c" || response2 == "C"){
				
				//Diplaying the points as complex numbers.
				//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
				//Cartesian print out:
				if(num4 < 0){
					cout << "Cartesian:\tz1 = " << num3 << " - j " << (-1*num4) << "\n";
					
				}
				else{
					cout << "Cartesian:\tz1 = " << num3 << " + j " << num4 << "\n";
				}
				
				//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
				//Polar print out: 	
				if( t2 < 0){
					cout << "Polar:\t\tz1 = " << r2 << " exp(-j " << (-1*t2) << ")\n";
				}
				else{
					cout << "Polar:\t\tz1 = " << r2 << " exp(j " << t2 << ")\n";
				}
				
				
				
				//Reassigning the proper variables to the global variables for use later on.
				x2 = num3;
				y2 = num4;
				
			}
			else{
				//Diplaying the points as complex numbers.
				
				//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
				//Cartesian print out:
				if(y2 < 0){
					cout << "Cartesian:\tz1 = " << x2 << " - j " << (-1*y2) << "\n";
					
				}
				else{
					cout << "Cartesian:\tz1 = " << x2 << " + j " << y2 << "\n";
				}
				
				//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
				//Polar print out: 	
				if( num4 < 0){
					cout << "Polar:\t\tz1 = " << num3 << " exp(-j " << (-1*num4) << ")\n";
				}
				else{
					cout << "Polar:\t\tz1 = " << num3 << " exp(j " << num4 << ")\n";
				}
				
				
				
				
				//Reassigning the proper variables to the global variables for use later on.
				r2 = num3;
				t2 = num4;
			}
			
			cout << endl;
			
			int menuchoice; //Variable to store menu choice.
			
			//Prompting selection from menu.
			cout << "Which of the following vector sums or differences\nwould you like to compute?\n";
			//Displaying the menu.
			cout << "(1) z1 + z2\n";
			cout << "(2) z1 - z2\n";
			cout << "(3) z2 - z1\n";
			cout << "(4) -z1 - z2\n" << endl;
			
			cin >> menuchoice; //Reading in menuchoice
			
			//declaring variables for vector calculations.
			double coor1cart, coor2cart, radiusconver, thetaconver= 0;
			
			
			switch(menuchoice){
				case 1:
					
					
					coor1cart = x1 + x2; //Adds the first component of the vectors.
					coor2cart = y1 + y2; //Adds the second componet of the vectors. 
					
					radiusconver = sqrt(pow(coor1cart,2)+pow(coor2cart,2)); //Calculates R
					
					//Calculating the theta. Branching structure is for determining which equation to use. 
					if(coor1cart>= 0){
						thetaconver = atan(coor2cart/coor1cart); //Calculates theta using formula for given range for x and y. 
					}
					else if( coor1cart< 0 && coor2cart >= 0){
						thetaconver = atan(coor2cart/coor1cart) + pi; //Calculates theta using formula for given range for x and y. 
						
					}
					else if(coor1cart < 0 && coor2cart < 0){
						thetaconver = atan(coor2cart/coor1cart) - pi; //Calculates theta using formula for given range for x and y. 
						
					}
					
					//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
					//Cartesian print out:
					if(coor2cart < 0){
						cout << "Sum, Cartesian:\tz_sum = " << coor1cart <<" - j " << (-1*coor2cart)  << endl;
						
					}
					else{
						cout << "Sum, Cartesian:\tz_sum = " << coor1cart <<" + j " << coor2cart  << endl;
					}
					
					//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
					//Polar print out: 	
					if( thetaconver < 0){
						cout << "Sum, Polar:\tz_sum = "  <<radiusconver <<" exp(-j " << (-1*thetaconver) <<")" << endl;
					}
					else{
						cout << "Sum, Polar:\tz_sum = "  <<radiusconver <<" exp(j " << thetaconver  <<")" << endl;
					}
					
					
					break;
					
				case 2:
				
					coor1cart = x1 - x2; //Adds the second componet of the vectors. 
					coor2cart = y1 - y2; //Adds the second componet of the vectors. 
					
					radiusconver = sqrt(pow(coor1cart,2)+pow(coor2cart,2)); //Calculates R
					
					//Calculating the theta. Branching structure is for determining which equation to use. 
					if(coor1cart>= 0){
						thetaconver = atan(coor2cart/coor1cart); //Calculates theta using formula for given range for x and y. 
					}
					else if( coor1cart< 0 && coor2cart >= 0){
						thetaconver = atan(coor2cart/coor1cart) + pi; //Calculates theta using formula for given range for x and y. 
						
					}
					else if(coor1cart < 0 && coor2cart < 0){
						thetaconver = atan(coor2cart/coor1cart) - pi; //Calculates theta using formula for given range for x and y. 
						
					}
					
					//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
					//Cartesian print out:
					if(coor2cart < 0){
						cout << "Sum, Cartesian:\tz_sum = " << coor1cart <<" - j " << (-1*coor2cart)  << endl;
						
					}
					else{
						cout << "Sum, Cartesian:\tz_sum = " << coor1cart <<" + j " << coor2cart  << endl;
					}
					
					//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
					//Polar print out: 	
					if( thetaconver < 0){
						cout << "Sum, Polar:\tz_sum = "  <<radiusconver <<" exp(-j " << (-1*thetaconver) <<")" << endl;
					}
					else{
						cout << "Sum, Polar:\tz_sum = "  <<radiusconver <<" exp(j " << thetaconver  <<")" << endl;
					}
					
					
				
					break;
					
					
				case 3:
					
					coor1cart = x2 - x1; //Adds the second componet of the vectors. 
					coor2cart = y2 - y1; //Adds the second componet of the vectors. 
					
					radiusconver = sqrt(pow(coor1cart,2)+pow(coor2cart,2)); //Calculates R
					
					//Calculating the theta. Branching structure is for determining which equation to use. 
					if(coor1cart>= 0){
						thetaconver = atan(coor2cart/coor1cart); //Calculates theta using formula for given range for x and y. 
					}
					else if( coor1cart< 0 && coor2cart >= 0){
						thetaconver = atan(coor2cart/coor1cart) + pi; //Calculates theta using formula for given range for x and y. 
						
					}
					else if(coor1cart < 0 && coor2cart < 0){
						thetaconver = atan(coor2cart/coor1cart) - pi; //Calculates theta using formula for given range for x and y. 
						
					}
					
					//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
					//Cartesian print out:
					if(coor2cart < 0){
						cout << "Sum, Cartesian:\tz_sum = " << coor1cart <<" - j " << (-1*coor2cart)  << endl;
						
					}
					else{
						cout << "Sum, Cartesian:\tz_sum = " << coor1cart <<" + j " << coor2cart  << endl;
					}
					
					//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
					//Polar print out: 	
					if( thetaconver < 0){
						cout << "Sum, Polar:\tz_sum = "  <<radiusconver <<" exp(-j " << (-1*thetaconver) <<")" << endl;
					}
					else{
						cout << "Sum, Polar:\tz_sum = "  <<radiusconver <<" exp(j " << thetaconver  <<")" << endl;
					}
					
					break;
					
				case 4:
				
					coor1cart = -x1 - x2; //Adds the second componet of the vectors. 
					coor2cart = -y1 - y2; //Adds the second componet of the vectors. 
					
					radiusconver = sqrt(pow(coor1cart,2)+pow(coor2cart,2)); //Calculates R
					
					//Calculating the theta. Branching structure is for determining which equation to use. 
					if(coor1cart>= 0){
						thetaconver = atan(coor2cart/coor1cart); //Calculates theta using formula for given range for x and y. 
					}
					else if( coor1cart< 0 && coor2cart >= 0){
						thetaconver = atan(coor2cart/coor1cart) + pi; //Calculates theta using formula for given range for x and y. 
						
					}
					else if(coor1cart < 0 && coor2cart < 0){
						thetaconver = atan(coor2cart/coor1cart) - pi; //Calculates theta using formula for given range for x and y. 
						
					}
					
					//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
					//Cartesian print out:
					if(coor2cart < 0){
						cout << "Sum, Cartesian:\tz_sum = " << coor1cart <<" - j " << (-1*coor2cart)  << endl;
						
					}
					else{
						cout << "Sum, Cartesian:\tz_sum = " << coor1cart <<" + j " << coor2cart  << endl;
					}
					
					//Displays ther results of the calculations using if statements to accoutn for the placement of the negative sign for the second term.
					//Polar print out: 	
					if( thetaconver < 0){
						cout << "Sum, Polar:\tz_sum = "  <<radiusconver <<" exp(-j " << (-1*thetaconver) <<")" << endl;
					}
					else{
						cout << "Sum, Polar:\tz_sum = "  <<radiusconver <<" exp(j " << thetaconver  <<")" << endl;
					}
					
					
					break;
				
				default:
					//Telling the user their response was invalid.
					cout << "ERROR! Invalid selection, exiting.";
					return -1; //terminating the program
				}
			
			
			
			
			
		}
		
		
	}
	else{
		
		cout << "ERROR! Invalid selection, exiting.";
		return -1; //Ending the program.
	}
	
	
	
	return 0;
}
