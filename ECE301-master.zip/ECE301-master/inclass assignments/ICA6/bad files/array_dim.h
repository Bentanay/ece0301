const int DIM = 2;
