
#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>
#include <mgl2/mgl.h>
#include "array_dim.h" //including the .h file with the dimension of matrices and vectors.

using namespace std;

//FUNCTION FOR READING HTE DIMENSION OF THE ARRAY FROM THE FILE.
int ArrayRead(double [][DIM], double [], ifstream &);


int main(){
	
	 // creating a file object for output during this program. 
	ofstream textout("ECE0301_ICA06_Axeqb_solution.txt");
	
	//Outputting introduction.
	textout << "ECE 0301 – Matrix-Vector Computations,\nDeterminants and Cramer's Rule.\n\n";
	
	//outting array dimension
	textout << "Global array dimension: DIM = " << DIM << endl; 
	
	//declaring an ifstream object for reading in the file. 
	ifstream dim2in("ECE0301_ICA06_Axeqb_problem.txt"); 
	
	//declaring the arrays to hold A and b arrays
	double A[DIM][DIM];
	double b[DIM];  
	
	
	//storing dimension of the array and printing it out to the file.
	int dimN = ArrayRead(A, b,dim2in); 
	textout  << "Input file: N = " << dimN;
	
	
	
	
	
	//closing the files for input and output.
	textout.close();
	dim2in.close();
	
	return 0; 
	
	
}

//FUNCTION FOR READING HTE DIMENSION OF THE ARRAY FROM THE FILE.
int ArrayRead(double A[][DIM], double b[],ifstream &dim2in){
	
	
	string line1, line2, line3, line2check; //storing the lines from the file. 
	string Nstr; //storing the number into a string
	
	getline(dim2in, line1); //getting the 1st line from the file.
	getline(dim2in, line2); //getting the 2nd line from the file.
	getline(dim2in, line3);//getting the 3nd line from the file.
	
	//getting the first 4 characters of line2. 
	//line2check = line2.substr(0,4);
	
	/*cout<<line1 << endl;
	cout << "ECE 0301: Ax = b Problem" << endl;*/
		
		
	line1.pop_back();
		
	if(line1 == "ECE 0301: Ax = b Problem"){
		if(line2check.compare("N = ") == 0){
			
			
			
		}
		else{
			//exiting because there was an error.
			cout << "ERROR! Input file format error.";
			exit(-1);
			
			
		}
		
	}else{
		//exiting because there was an error.
		cout << "ERROR! Input file format error.";
		cout << "outer if is broken";
		exit(-1);

	}
	
	
	
	return 0;
	
}


































	
	
