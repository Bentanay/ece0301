#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <fstream>
#include "array_dim.h" //including the .h file with the dimension of matrices and vectors.

using namespace std;

//FUNCTION FOR READING HTE DIMENSION OF THE ARRAY FROM THE FILE.
int ArrayRead(double [][DIM], double [], ifstream &);

//FUNCTION FOR PRINTING THE ARRAY.
void ArrayPrint(int N, double [][DIM], double [], ofstream &, double []);

//function for doing matrix vector multiplication
void multiply(double [][DIM], double [], double []);

//function for displaying some rows and some columns.
void displaycertain(double [][DIM], double, ofstream &);

//function for matrix copying removing row i and column j
void copymatrix(double [][DIM], double [DIM][DIM], int, int, int);

//calculating the determinant function step 12
double det(double [][DIM], int);

int main(){
	
	 // creating a file object for output during this program. 
	ofstream textout("ECE0301_ICA06_Axeqb_solution.txt");
	
	//declaring an ifstream object for reading in the file. 
	ifstream dim2in("ECE0301_ICA06_Axeqb_problem.txt"); 
	
	
	//declaring the arrays to hold A and b arrays
	double A[DIM][DIM];
	double b[DIM];  
	
	//reading in the contents.
	int N = ArrayRead(A, b,dim2in); 
	
	displaycertain(A,N,textout);
	
	//initalizing variables for nxn matrix removing ith row and jth column.
	/* stuff for other steps
	int i =1, j=0, n=3;
	displaycertain(A,n, textout);
	
	double copiedmatrix[5][5];
	
	copymatrix(A,copiedmatrix,i,j,n);
	textout << endl << endl;
	
	displaycertain(copiedmatrix,n-1,textout);
	*/
	double num = det(A,N); 
	textout << "det(A) = " << num;
	
	/* stuff for other steps
	
	double x[N]; //defining x array
	
	//reading in the elements for x
	cout << "Start entering your elements" << endl; 
	for(int i = 0; i <N; i++){
		cin >> x[i];
	}
	
	multiply(A,x,b);
	
	//printing out the array	
	ArrayPrint(N, A , b, textout,x);
	
	*/
	
	//closing the files for input and output.
	textout.close();
	dim2in.close();
	
	return 0; 
	
	
}
//calculating the determinant function step 12
double det(double A[DIM][DIM],int n){
	//setting the determinant equal to zero
	double determinant = 0;
	
	//if n is a one by one matrix
	if(n==1){
		return A[0][0];
	}
	else{
		determinant = 0; //setting determinant to be zero.
		double nsub[DIM][DIM]; //submatrix of dimension dim by dim.
		for(int j = 0; j < n; j++){	//looping through the columns of the first row
			
			//copying the matrix to the submatrix with the row and column deleted.
			copymatrix(A, nsub,0,j,n); 
			
			//summing the determinant 
			determinant += (A[0][j]*det(nsub,n-1)*pow(-1,j));
		} 
	}
	return determinant;

}



//function for matrix copying removing row i and column j
void copymatrix(double orig[][DIM] , double copy[][DIM], int i,int j ,int n){
	
	int w =0; //initializing w
	 for(int k =0; k <n; k++){ //looping through row
		w = 0;
		if(k < i){ //if index is less than specified deleted row
			while(w<n){ 
				if(w<j){ //if index is less than specified deleted column
					copy[k][w] = orig[k][w];
				}else if(w>j){
					copy[k][w-1] = orig[k][w]; //account for it if its not
				}
				w++;
			}
		}
		else if(k > i){ //if it is greater than deleted row index
			while(w<n){
				if(w<j){ //if index is less than specified deleted column
					copy[k-1][w] = orig[k][w];
				}else if(w>j){
					copy[k-1][w-1] = orig[k][w]; //account for it if its not
				}
				w++; //increment w
			}
		}			
	 }	
}





//function for displaying some rows and some columns.
void displaycertain(double array[][DIM], double N, ofstream &textout){
	
	//looping through rows and columns
	for(int i = 0; i<N; i++){
		textout << "[ "; //opening row brace
		for(int j = 0; j<N; j++){
				textout << setw(10) << array[i][j]; //printing the element
		}
		textout << " ]" << endl; //closing row brace
	}
	
}

//function for doing matrix vector multiplication
void multiply(double A[][DIM], double x[], double b[]){
	
	double accum = 0;
	//looping through rows and columns
	for(int i = 0; i < DIM; i++){
		for(int j = 0; j<=DIM; j++){
			//adding on the element for multiplying the row by the column
			accum += A[i][j]*x[j];
		} 
		b[i] = accum; //storing it in array
		accum = 0;
	} 
	

	
}


//*****************************************************************************************
//*****************************************************************************************
//*****************************************************************************************

//FUNCTION FOR PRINTING THE ARRAY.
void ArrayPrint(int N, double A[][DIM], double b[], ofstream &textout, double x[]){
	
	//Outputting introduction.
	textout << "ECE 0301 - Matrix-Vector Computations,\nDeterminants and Cramer's Rule.\n\n";
	
	//outting array dimension
	textout << "Global array dimension: DIM = " << DIM << endl; 
	textout  << "Input file: N = " << N << endl << endl;
	
	textout << "A = " << endl;

	//looping through array to print it
	for(int i = 0; i<N; i++){
		textout << "[ ";
		for(int j = 0; j<N; j++){
				textout << setw(10) << A[i][j];
		}
		textout << " ]" << endl;
	}
	textout << endl;
	
	//looping through array to print it
	textout << "b = " << endl;
	for(int j = 0; j< N; j++){
			textout << "[ "<< setw(10) << b[j] << " ]\n";
	}
	
	//looping through solution array
	textout << endl <<"A * x = b" << endl;
	for(int i = 0; i<N; i++){
		textout << "[ ";
		
		
		for(int j = 0; j<N; j++){
				textout << setw(10) << A[i][j];
		}
		
		//putting equal and times sign in the right places.
		if(N %2 == 1){
			if(i==N/2){
				textout << " ] * [ " << setw(10) << x[i] << " ] = [ " << setw(10) << b[i] << " ]" << endl;
			}
			else{
				textout << " ]   [ " << setw(10) << x[i] << " ]   [ " << setw(10) <<b[i] << " ]" << endl;
			}
		}
		else{
			if(i==N/2-1){
				textout << " ] * [ " << setw(10) << x[i] << " ] = [ " <<setw(10) << b[i] << " ]" << endl;
			}
			else{
				textout << " ]   [ " << setw(10) << x[i] << " ]   [ " << setw(10) <<b[i] << " ]" << endl;
			}
			
			
		}
	
	}

}

//*****************************************************************************************
//*****************************************************************************************
//*****************************************************************************************

//FUNCTION FOR READING HTE DIMENSION OF THE ARRAY FROM THE FILE.
int ArrayRead(double A[][DIM], double b[],ifstream &dim2in){
	
	
	string line1, line2, line3, line2check; //storing the lines from the file. 
	string Nstr; //storing the number into a string
	
	getline(dim2in, line1); //getting the 1st line from the file.
	getline(dim2in, line2); //getting the 2nd line from the file.
	getline(dim2in, line3);//getting the 3nd line from the file.
	
	line2check = line2.substr(0,4);
	
	
	if(line1 == "ECE 0301: Ax = b Problem"){
		
		if(line2check == "N = "){
			
		
			Nstr = line2.substr(4,1); //getting the character at that index 4. 
		
			int Nnum = stoi(Nstr); //converting the string to a number.
			
			//checking if DIM and the dimension read from the file is the same.
			if(Nnum == DIM){
				
				if(line3 != "A = "){
					//exiting because there was an error.
					cout << "ERROR! Input file format error.";
					exit(-1);
				}
				
				else{
								
					string temp; //for holding variable read from file.
					
					double tempnum = 0; // temporary variable 
					//reading the A matrix from the file
					for(int i = 0; i<DIM; i++){
						for(int j = 0; j<DIM; j++){
							
							getline(dim2in, temp);							
							tempnum =stod(temp);
							
							//storing the number into the array.
							A[i][j] = tempnum;
							
						}
					}
					
					//getting the next line
					string bline;
					getline(dim2in,bline);
					if( bline == "b = "){
						for(int i = 0; i < DIM; i++){
							getline(dim2in, temp);
							tempnum = stod(temp);
							b[i] = tempnum;

						}
						return Nnum; // returning N num back to main if everything works. 
					}
					else{
						//exiting because there was an error.
						cout << "ERROR! Dimension mismatch, N != DIM.";
						exit(-1);
					}
					
				}
				
			}
			else{
				//exiting because there was an error.
				cout << "ERROR! Dimension mismatch, N != DIM.";
				exit(-1);
			}
			

		}else{
			//exiting because there was an error.
			cout << "ERROR! Input file format error.";
			exit(-1);
		}	
	}
	else{
		//exiting because there was an error.
		cout << "ERROR! Input file format error.";
		exit(-1);	
	}
	return 0;
}


































	
	

