const int DIM = 4;
