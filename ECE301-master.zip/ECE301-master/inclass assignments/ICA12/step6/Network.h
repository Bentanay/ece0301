#include <iostream>
#include <fstream>
#include "Component.cpp"
using namespace std;

//include guard
#ifndef NETWORK_H
#define NETWORK_H

//NETWORK CLASS
class Network{
	
	private:
		static int numnet; //static member for storing the number of networks
		int netindex; //for storing the network index num
		int numnodesinnet; //for storing the number of nodes in the net
		Node *nodearr; //a pointer to an array of nodes.
		
	
	public:
		
		Network(int = 2); //constructor with a default value of 2.
		~Network(); //destructor
		int getNetindex() const; //getter for getting the network index
		int getNumnodesinnet() const; //getter for getting the number of nodes in the network
		int getTotnodes() const; //returns the total number of nodes in existence
		void setNodevoltage(int, double); //function that alters the voltage of one of the nodes.
		void writeinfo(ofstream &); //function to write the info to a textfile.
		void connectComp(Component *, int, int); //connecting a component between two nodes in a network.
		
};

#endif


