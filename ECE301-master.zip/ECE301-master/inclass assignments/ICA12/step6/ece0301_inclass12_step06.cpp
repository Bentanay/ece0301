#include <iostream>
#include <fstream>
#include <cmath>
#include "Node.cpp" //including the node class
#include "Network.cpp" //including the network class

using namespace std;


//main function
int main(){
	
	//declaring an ofstream object
	ofstream out("ECE 0301 - Electrical Network Reports.txt");
	
	//printing the header to the file
	out << "ECE 0301 - Electrical Network Simulation" << endl;
	
	//defining a network with 3 nodes.
	Network net1 = Network(3);
	
	//definign 3 comoneents to be used in the network
	Component comp0 = Component();
	Component comp1 = Component();
	Component comp2 = Component();
	
	//connecting the components to nodes.
	net1.connectComp(&comp0, 0, 1);
	net1.connectComp(&comp1, 1, 2);
	net1.connectComp(&comp2, 2, 0);
	
	//setting the voltages at two of the nodes. 
	net1.setNodevoltage(1,-5);
	net1.setNodevoltage(2,1.25);
	
	//printing out the network information
	net1.writeinfo(out);
	
	//printing out the information of each component.
	comp0.printinfo(out);
	comp1.printinfo(out);
	comp2.printinfo(out);
	
	//closing the output file
	out.close();
	
	
	return 0;
}
