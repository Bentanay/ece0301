
#include "Network.h" //including the class

int Network::numnet = 0; //initializing the static mem variable


//constructor
Network::Network(int num){
	
	//sets the index, allocates the node array, and incremments the number of networks.
	netindex = numnet;
	numnet++;
	numnodesinnet = num;
	
	nodearr = new Node[numnodesinnet];
	
}

//destructor.
Network::~Network(){
	 //deletes the ptr
	delete [] nodearr;
	
}

//gets the network index and returns it
int Network::getNetindex() const{
	
	return netindex;
}

//gets the number of nodes in the network
int Network::getNumnodesinnet() const{
	
	return numnodesinnet;
}

//gets the total number of nodes.
int Network::getTotnodes() const{
	return nodearr -> getNumnode();
}

//setter to the set the node voltage
void Network::setNodevoltage(int indexer, double volt){
	
	(nodearr + indexer) -> setVoltage(volt);
	
}

//void function to write the function to an output
void Network::writeinfo(ofstream &out){
	
	out << endl; //printing out a new line.
	
	//printing out 48 charges. 
	for( int i =0; i<48; i++){
		out << "-";
	}
	
	out << endl; //printing out a new line
	
	//printing out the network index
	out << endl << "Data for Electric Network # " << netindex << ":" << endl;
	
	//printing out the present networks and nodes in existence
	out << "At present, there are " << numnet << " Networks in existence." << endl;
	out << "At present, there are " << getTotnodes() << " nodes in existence." << endl;
	
	//printing out the network index and the nodes in the network
	out << "Network # " << netindex << " contains " << numnodesinnet << " nodes." << endl;
	
	//printing out each othe nodes info
	for( int i =0; i < numnodesinnet; i++){
		
		(nodearr +i) -> printinfo(out);	
	}
	
}

//connecting a component between two nodes in a network.
void Network::connectComp(Component *ptr, int termAindex, int termBindex){
	
	//connecting the component inside of the network.
	ptr -> setTermA(nodearr + termAindex);
	ptr -> setTermB(nodearr + termBindex);
	
	
}














