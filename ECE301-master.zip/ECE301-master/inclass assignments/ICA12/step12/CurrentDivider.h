
//include guard for current divider class
#ifndef CURRENTDIVIDER_H
#define CURRENTDIVIDER_H

//derived class for resistor
class CurrentDivider:public Network{
	private:
		DCCurrentSource dc; //dc current source object
		Resistor R1; //resistor one
		Resistor R2; //resistor two
	
	public:
		CurrentDivider(); //constructor
		CurrentDivider(double,double,double); //overloaded constructor
		void setSourceCurrent(double); //setting the source current
		void setResistors(double,double); //setting both the resistances.
		void printDividerinfo(ofstream &); //function for printing out the current divider info.
		void calculateValues(); //function for calculating all the values in the circuit.
		
	
		
		
		
		
	
};


#endif



