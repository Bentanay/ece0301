#include <iostream>
#include <fstream>
using namespace std;

//include guard
#ifndef COMPONENT_H
#define COMPONENT_H

//component class
class Component{
	
	private:
		static int numcomp; //static var for the number of components.
		int compindex; //component index 
		Node *termA; //a pointer to a node object for determining which nodes the component is connected to
		Node *termB; //a pointer to a node object for determining which nodes the component is connected to
	
	public:
		Component(); //constructor
		int getNumcomp() const; //getter for returning the number of components.
		int getCompindex() const; //getter for returing the component index
		void setTermA(Node *); //setter for setting the node connected to terminal A
		void setTermB(Node *); //setter for setting the node conencted to terminal B
		int getNodeindextermA() const; //getter for returning the node inex connected to terminal A
		int getNodeindextermB() const; //getter for returning the node inex connected to terminal B
		void printinfo(ofstream &) const; //printing the information of the component.
		double getTermvoltage() const; //function for returning the voltage across the component.
};

#endif



