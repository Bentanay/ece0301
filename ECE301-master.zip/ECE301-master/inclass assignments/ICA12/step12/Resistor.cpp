#include "Resistor.h" //including the class
#include <fstream>
#include <iostream>
using namespace std;

//constructor
Resistor:: Resistor(){
	
	//defaulting resistance to 1000
	resistance = 1000;
	
	
}

//setter forsetting the resistor resistance
void Resistor::setResistance(double r ){
	
	resistance = r;
}

//getter for returning the resistor value
double Resistor::getResistance() const{
	
	return resistance;
}

//print function for displaying resistor component info to the file.
void Resistor::printResistorinfo(ofstream &out){
	
	//prints out the component information and says what kind of component it is
	out << "Component # " << getCompindex() << " is a Resistor, R = " << resistance << " Ohms." << endl;
	printinfo(out); //calling component print out function
	
	//prints out the current through the resistor
	out << "The current in this Resistor = " << abs(getRescurrent()) << " Amps," << endl;
	
	//if statement for determining which way the current is flowing and printing that out correctly.
	if(getTermvoltage() > 0)
		out << "flowing from Node " << getNodeindextermA() << " to Node " <<getNodeindextermB() << "." << endl;
	else
		out << "flowing from Node " << getNodeindextermB() << " to Node " <<getNodeindextermA() << "." << endl;
		
	//printing out the power dissipate by the resistor.
	out << "The power dissipated in this Resistor = " << getRespower() << " Watts." << endl;
	
	
}

//function for calculating the resistor current using ohms law
double Resistor::getRescurrent() const{
	
	return getTermvoltage()/resistance;
	
}


//function for calculating the resistor power 
double Resistor::getRespower() const{
	
	return getTermvoltage()*getRescurrent();
}

