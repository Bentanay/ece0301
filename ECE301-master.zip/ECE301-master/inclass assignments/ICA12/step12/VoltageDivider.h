
//include guard for voltagedivider class
#ifndef VOLTAGEDIVIDER_H
#define VOLTAGEDIVIDER_H

//derived class for resistor
class VoltageDivider:public Network{
	private:
		DCVoltageSource dc;
		Resistor R1;
		Resistor R2;
	
	public:
		VoltageDivider();
		VoltageDivider(double,double,double);
		void setSourceVoltage(double);
		void setResistors(double,double);
		void printDividerinfo(ofstream &);
		void calculateValues();
		
		
		
		
	
};


#endif


