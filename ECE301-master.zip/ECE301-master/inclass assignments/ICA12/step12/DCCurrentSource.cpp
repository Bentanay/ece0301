#include "DCCurrentSource.h" //inlcuding the dc current source class
#include <fstream>
#include <iostream>
using namespace std;

//setting the current to 0
DCCurrentSource::DCCurrentSource(){
	
	current = 0;
	
}

//function for setting the current source value
void DCCurrentSource::setSourcecurrent(double i){
	
	current = i;
}

//function for returning the source current
double DCCurrentSource::getSourcecurrent() const{
	return current;
}

//function for returning the power of the source
double DCCurrentSource::getPower() const{
	
	return current*getTermvoltage();
}

//function for printing out the info
void DCCurrentSource::printSourceinfocurr(ofstream &out){
	//printing out the type of source
	out << "Component # " << getCompindex() << " is a DC Current Source, Is = " << current << " Amps." << endl;
	printinfo(out); //printing out the component info
	out << "The current in this DC Current Source = " << abs(current) << " Amps," << endl;
	
	//if else for determining which direction the node flows
	if(getTermvoltage() < 0)
		out << "flowing from Node " << getNodeindextermA() << " to Node " <<getNodeindextermB() << "." << endl;
	else
		out << "flowing from Node " << getNodeindextermB() << " to Node " <<getNodeindextermA() << "." << endl;
	
	//printing out the power dissipate by the resistor.
	out << "The power supplied by this DC Current Source = " << abs(getPower()) << " Watts." << endl;
	
			
	
	
}

