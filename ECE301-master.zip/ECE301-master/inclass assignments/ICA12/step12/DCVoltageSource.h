//include guard
#ifndef DCVOLTAGESOURCE_H
#define DCVOLTAGESOURCE_H

//derived class for DC volate source.
class DCVoltageSource:public Component{
	
	private:
		double voltage; //for storing the source voltage
		double current; //for storing the current drawn
	public:
		DCVoltageSource(); //constructor
		void setSourcevoltage(double); //setter for setting the source voltage
		double getSourcevoltage() const; //getter for getting the sourc voltage
		void printSourceinfo(ofstream &);  //function that prints out the source information
		void setCurrent(double); //function that sets the current that is being drawn from the source
		double getCurrent() const; //function that returns the current.
		double getPower() const; //function that calculates the power supplied.
	
};


#endif
