#include <iostream>
#include <fstream>
using namespace std;


//include guard
#ifndef NODE_H
#define NODE_H

//NODE CLASS
class Node{
	private:
		static int numnode; //for storing the number of bodes
		int index; //for storing the node index
		double voltage; //for storing the voltage at the node
	public:
		Node(); //constructor
		int getIndex() const; //getting for getting the index
		int getNumnode() const; //getter for getting the number of nodes
		void setVoltage(double); //setter for setting the node voltage.
		double getVoltage() const; //getter for getting the node voltage
		void printinfo(ofstream &) const; //function that prints out the nodes info.


};

#endif
