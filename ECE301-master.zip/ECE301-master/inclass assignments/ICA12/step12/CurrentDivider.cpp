#include "CurrentDivider.h" //including the class spec file
#include <fstream>
#include <iostream>
using namespace std;


//calling the network contructor beofre the current divider instructor
CurrentDivider::CurrentDivider():Network::Network(2){
	dc.setSourcecurrent(1); //sets the current source to one app
	R1.setResistance(1000); //sets the resistance to a thousand ohms
	R2.setResistance(1000); //sets the resistance to a thousand ohms
	connectComp(&dc,0,1); //connects the dc current source
	connectComp(&R1,0,1); //connects the resistor in the circuit
	connectComp(&R2,0,1); //connects the resistor in the circuit
	calculateValues(); //runs calculate values to calculate all the values in the circuit
}

//calling the network contructor beofre the current divider instructor
CurrentDivider::CurrentDivider(double i,double r1,double r2):Network::Network(2){
	
	dc.setSourcecurrent(i); //sets the current source to the value passed in
	R1.setResistance(r1);//sets the resistor to the value passed in
	R2.setResistance(r2); //sets the resistor to the value passed in
	connectComp(&dc,0,1);//connects the current source
	connectComp(&R1,0,1); //conncects the resistor
	connectComp(&R2,0,1); //conncects the resistor
	calculateValues(); //runs calculate values to calculate all the values in the circuit
	
	
}

//function for setting the value of the current source
void CurrentDivider::setSourceCurrent(double i){
	
	dc.setSourcecurrent(i); //setting the current
	calculateValues(); //runs calculate values to calculate all the values in the circuit
	
	
}

//function for setting the valies of the resistors
void CurrentDivider::setResistors(double r1,double r2){
	
	//setting the resistor values
	R1.setResistance(r1);
	R2.setResistance(r2);
	calculateValues(); //runs calculate values to calculate all the values in the circuit
	
	
}
void CurrentDivider::printDividerinfo(ofstream &out){
	
	out << endl; //printing out a new line.
	
	//printing out 48 charges. 
	for( int i =0; i<48; i++){
		out << "-";
	}
	
	out << endl; //printing out a new line
	
	//printing out the network index
	out << endl << "Data for Electric Network # " << getNetindex() << ":" << endl;
	out << "Network # " << getNetindex() << " is a Current Divider." << endl;
	
	writeinfo(out); //printing out the network info
	out << "At present, there are " << dc.getNumcomp() << " components in existence." << endl << endl;
	
	//printing out the info the three components
	dc.printSourceinfocurr(out);
	out << endl;
	R1.printResistorinfo(out);
	out << endl;
	R2.printResistorinfo(out);
	
}

//runs calculate values to calculate all the values in the circuit
void CurrentDivider::calculateValues(){
	//calculating the voltage at node one.
	double calc = (R1.getResistance()*R2.getResistance())/(R1.getResistance()+R2.getResistance()); 
	getNodeptr(0) ->setVoltage(0); //setting the ground
	getNodeptr(1) ->setVoltage(dc.getSourcecurrent()*calc); //setting node 1 voltage
	
}
		
