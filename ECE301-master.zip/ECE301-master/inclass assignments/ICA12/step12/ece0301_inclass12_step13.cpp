#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include "Node.cpp" //including the node class
#include "Network.cpp" //including the network class
#include "DCVoltageSource.cpp" //including the dc voltage source dervied class
#include "Resistor.cpp" //including the resistor class
#include "DCCurrentSource.cpp" //inlcuding the current source class
#include "VoltageDivider.cpp" //inclduing the voltage divider class
#include "CurrentDivider.cpp" //including the current divider class


using namespace std;


//main function
int main(){
	
	ifstream in("ECE 0301 - Circuits to Simulate.txt");
	
	//declaring an ofstream object
	ofstream out("ECE 0301 - Electrical Network Reports.txt");
	
	//printing the header to the file
	out << "ECE 0301 - Electrical Network Simulation" << endl;
	
	//strings for reading in the input file
	string line1, templine;
	
	//doubles for the source and the resistors
	double source,r1,r2;
	
	
	//while loop for reading in to the end of the file
	while(getline(in,line1)){
		
		//its not equal to line1 or line2..
		if(line1 != "Voltage Divider" && line1 !="Current Divider"){
			
			//exit the program
			cout << "ERROR! Invalid network type." << endl;
			exit(-1);
		
		//if its voltage divider
		}else if(line1 == "Voltage Divider"){
			
			//read in 3 lines and convert them all to doubles
			getline(in,templine);
			source = stod(templine);
			getline(in,templine);
			r1= stod(templine);
			getline(in,templine);
			r2= stod(templine);
			
			//create a voltage divider object with the values from the file
			VoltageDivider vd = VoltageDivider(source,r1,r2);
			vd.printDividerinfo(out); //printing out the info
			
			
			//if its a current divider
		} else if(line1 == "Current Divider"){
			
			//read in 3 lines and convert them all to doubles
			getline(in,templine);
			source = stod(templine);
			getline(in,templine);
			r1= stod(templine);
			getline(in,templine);
			r2= stod(templine);
			
			//create a current divider object with the values from the file
			CurrentDivider cd = CurrentDivider(source,r1,r2);
			cd.printDividerinfo(out); //print out the current info.
			
			
		}
	
	}
	
	
	
	
	
	
	//closing the files
	out.close();
	in.close();
	
	
	return 0;
}

