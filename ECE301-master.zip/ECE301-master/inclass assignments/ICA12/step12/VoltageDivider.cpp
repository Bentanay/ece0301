#include "VoltageDivider.h" //including the spec file
#include <fstream>
#include <iostream>
using namespace std;


//calling the network constructor in the voltage divider contructor
VoltageDivider::VoltageDivider():Network::Network(3){
	
	dc.setSourcevoltage(1); //set the source voltage
	R1.setResistance(1000); //set the resistance to 1k
	R2.setResistance(1000); //set the resistance to 1k
	connectComp(&dc,0,1); //connect the dc source
	connectComp(&R1,1,2); //connect the resistor
	connectComp(&R2,2,0); //connect the resistor
	calculateValues(); //calculate the values for the circuit
	
	
	
}



//calling the network constructor in the voltage divider contructor
VoltageDivider::VoltageDivider(double v ,double r1 ,double r2):Network::Network(3){
	
	dc.setSourcevoltage(v); //set the source voltage
	R1.setResistance(r1); //set the resistance to the value passed in
	R2.setResistance(r2); //set the resistance to the value passed in
	connectComp(&dc,0,1); //connect the dc source
	connectComp(&R1,1,2); //connect the resistor
	connectComp(&R2,2,0); //connect the resistor
	calculateValues(); //calculate the values for the circuit
}

//set the source voltage
void VoltageDivider::setSourceVoltage(double v){
	
	dc.setSourcevoltage(v); 
	calculateValues(); //calculate the values for the circuit
	
}

//set the resistor values
void VoltageDivider::setResistors(double r1,double r2){
	
	R1.setResistance(r1);
	R2.setResistance(r2);
	calculateValues(); //calculate the values for the circuit
	
}

//print the the divider info
void VoltageDivider::printDividerinfo(ofstream &out){
	out << endl; //printing out a new line.
	
	//printing out 48 charges. 
	for( int i =0; i<48; i++){
		out << "-";
	}
	
	out << endl; //printing out a new line
	
	//printing out the network index
	out << endl << "Data for Electric Network # " << getNetindex() << ":" << endl;
	out << "Network # " << getNetindex() << " is a Voltage Divider." << endl;
	
	//print the network info out
	writeinfo(out);
	out << "At present, there are " << dc.getNumcomp() << " components in existence." << endl << endl;
	
	
	//print out the component infos
	dc.printSourceinfo(out);
	out << endl;
	R1.printResistorinfo(out);
	out << endl;
	R2.printResistorinfo(out);
	
	
}

//function for calculating the values for the circuit
void VoltageDivider::calculateValues(){
	
	//setting the node voltages and setting the current from the voltage divider
	getNodeptr(0) ->setVoltage(0); 
	getNodeptr(1) ->setVoltage(dc.getSourcevoltage());
	dc.setCurrent(dc.getSourcevoltage()/(R1.getResistance()+R2.getResistance()));
	getNodeptr(2) ->setVoltage(dc.getCurrent()*R2.getResistance());
	
	
	
}

		
		
	




