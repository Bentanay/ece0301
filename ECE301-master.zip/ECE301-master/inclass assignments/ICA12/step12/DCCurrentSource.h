
//include guard for dc current source class
#ifndef DCCURRENTSOURCE_H
#define DCCURRENTSOURCE_H

//
class DCCurrentSource: public Component{
	private:
		double current; //for storing the source current
	public:
		
		DCCurrentSource(); //constructor
		void setSourcecurrent(double); //setter for setting the source current
		double getSourcecurrent() const; //getter for getting the sourc current
		void printSourceinfocurr(ofstream &);  //function that prints out the source information
		double getPower() const; //function that calculates the power supplied.

};


#endif
