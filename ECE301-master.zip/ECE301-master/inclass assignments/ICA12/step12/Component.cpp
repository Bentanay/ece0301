#include "Component.h" //includiing the class

int Component::numcomp = 0; //initializing the static variable

//constructor
Component::Component(){
	//setting the index and incrementing the number of components
	compindex = numcomp;
	numcomp++;
	
	//setting the pointers asnull pointers
	termA = nullptr;
	termB = nullptr;
}

//getter for getting the number of components
int Component::getNumcomp() const{
	
	return numcomp;
	
}

//getter for getting the coponent index.
int Component::getCompindex() const{
	
	return compindex;
}

//setter for connecting terminal A to a node
void Component:: setTermA(Node *ptr){
	termA = ptr;
}

//setter for connecting terminal B to a node
void Component::setTermB(Node *ptr){
	
	termB = ptr;
	
}

//getter for returnning the node index at terminal A
int Component::getNodeindextermA() const{
	
	return termA -> getIndex();
	
}
//getter for returnning the node index at terminal B
int Component::getNodeindextermB() const{
	
	return termB -> getIndex();
	
}

//function for returning the different between two terminals
double Component::getTermvoltage() const{
	
	//returning the calculation
	return termA -> getVoltage() - termB -> getVoltage();

	
}

//function for printing out the data of the component.
void Component::printinfo(ofstream &out) const{
	
	double temp = getTermvoltage(); //temp var for storing the voltage difference between nodes
	
	//printing out the initial component data
	out << "Component # " << compindex << " is connected between node " << getNodeindextermA() << " and node " << getNodeindextermB()  << "."<<endl; 
	out << "The Voltage across Component # " << compindex << " = " << abs(temp) << " Volts," << endl;
	
	//if else for determining which node is the negative node. and adjusting the printout accordingly.
	if(temp <= 0)
		out << "with the negative terminal at node " << getNodeindextermA() << "." << endl;  
	else 
		out << "with the negative terminal at node " << getNodeindextermB() << "." << endl;
}




