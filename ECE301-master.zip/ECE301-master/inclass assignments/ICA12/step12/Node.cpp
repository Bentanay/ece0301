
#include "Node.h" //including the class

int Node::numnode = 0; //instantiating the static member variable

//constructor
Node::Node(){
	
	//intitalzing the values and incremementing num nodes.
	index = numnode; 
	numnode++;
	voltage = 0;
	
}

//getter for getting the index of the node.
int Node::getIndex() const{
	
	return index;
	
}

//getter for getting the number of nodes that exist
int Node::getNumnode() const{
	return numnode;
}

//setter for setting the voltage at the end.
void Node::setVoltage(double v){
	
	voltage = v;
	
}

//getter for getting the voltage of the node
double Node::getVoltage() const{
	
	return voltage;
	
}

//print function to print out the nodes info.
void Node::printinfo(ofstream &textout) const{
	
	textout << "Voltage at node " << index << " = " << voltage << "." << endl;
	
	
}


