
//include guard for resistor class
#ifndef RESISTOR_H
#define RESISTOR_H

//derived class for resistor
class Resistor:public Component{
	
	private:
		double resistance; //member var for holding resistance
	public:
		Resistor(); //constructor 
		void setResistance(double); //setter for setting the resistance
		double getResistance() const; //getter for getting the resistacne
		void printResistorinfo(ofstream &);  //function for printing out the resistor info
		double getRescurrent() const; //function for calulcating the resistor current.
		double getRespower() const; //functin for calculating the resisitor power.
		
	
};


#endif
