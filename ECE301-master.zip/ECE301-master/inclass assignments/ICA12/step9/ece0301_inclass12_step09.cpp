#include <iostream>
#include <fstream>
#include <cmath>
#include "Node.cpp" //including the node class
#include "Network.cpp" //including the network class
#include "DCVoltageSource.cpp" //including the dc voltage source dervied class
#include "Resistor.cpp" //including the resistor class

using namespace std;


//main function
int main(){
	
	//declaring an ofstream object
	ofstream out("ECE 0301 - Electrical Network Reports.txt");
	
	//printing the header to the file
	out << "ECE 0301 - Electrical Network Simulation" << endl;
	
	//defining a network with 3 nodes.
	Network net1 = Network(3);
	
	DCVoltageSource dc1;
	dc1.setSourcevoltage(12);
	
	net1.connectComp(&dc1,0,1);
	
	Resistor res = Resistor();
	res.setResistance(200);
	
	
	Resistor res2 = Resistor();
	res2.setResistance(100);
	
	net1.connectComp(&res, 1, 2);
	net1.connectComp(&res2, 2, 0);
	
	net1.setNodevoltage(1,12);
	net1.setNodevoltage(2,4);
	 
		
	dc1.setCurrent(dc1.getSourcevoltage() / (res.getResistance() + res2.getResistance()));
	 
	//printing out the network information
	net1.writeinfo(out);
	out << endl;
	
	//printing out the information of each component.
	dc1.printSourceinfo(out);
	out << endl;
	res.printResistorinfo(out);
	out << endl;
	res2.printResistorinfo(out);
	
	//closing the output file
	out.close();
	
	
	return 0;
}
