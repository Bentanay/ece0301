#include "DCVoltageSource.h"
#include <fstream>
#include <iostream>
using namespace std;

//constructor  
DCVoltageSource:: DCVoltageSource(){
	
	voltage = 0; //initializes the voltage to zero
	
}

//setter for setting the voltage
void DCVoltageSource::setSourcevoltage(double v ){
	
	voltage = v;
}

//getter for getting the source voltage
double DCVoltageSource::getSourcevoltage() const{
	
	return voltage;
}

//function for printing out the source information tothe file
void DCVoltageSource::printSourceinfo(ofstream &out){
	
	//prints out the type of component
	out << "Component # " << getCompindex() << " is a DC Voltage Source, Vs = " << voltage << " Volts." << endl;
	printinfo(out); //calls the component class's print out function
	
	//prints out the calculated current 
	out << "The current in this DC Voltage Source = " << abs(current) << " Amps," << endl;
	
	//if statement for determining which node the current flows from and adjusting the output text to matchthat.
	if(getTermvoltage() < 0)
		out << "flowing from Node " << getNodeindextermA() << " to Node " <<getNodeindextermB() << "." << endl;
	else
		out << "flowing from Node " << getNodeindextermB() << " to Node " <<getNodeindextermA() << "." << endl;
		
	//prints out the power supplied by the source.
	out << "The power supplied by this DC Voltage Source = " << getPower() << " Watts." << endl;
	
}

//setter for setting the current drawn by the source
void DCVoltageSource::setCurrent(double i ){
	
	current = i;
}

//getter for getting the current drawn from the source.
double DCVoltageSource::getCurrent() const{
	return current;
	
}

//getter for getting the power supplied by the source.
double DCVoltageSource::getPower() const{
	return voltage*current;
	
}
