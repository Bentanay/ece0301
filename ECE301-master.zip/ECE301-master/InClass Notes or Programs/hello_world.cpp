/*
  hello_world.cpp
 */
 
 #include <iostream>
 using namespace std; //std stands for standard 
 
 int main() //main will always return an integer value
 {
	 
	 cout << "Hello World!\a"; //stream object
	 return 0;
 }
 
 /*
  * or you can do this:
  * 
  * std::cout << "Hello World!";
  * using namespace std gets all the names, a bunch of which you wont use
  * 
  * 
  */
 
 
 
