#include <iostream>
using namespace std;

void octalBits(int, bool &, bool &, bool &);

int main()
{
	int num;
	cout << "Please Enter a number betweeen 0 and 7:\n";
	cin >> num;
	if ( num<0 || num>7 )
	{
		cout << "ERROR!  Non-octal input.\n";
		return -1;
	}

	bool bit2, bit1, bit0;
	octalBits(num, bit2, bit1, bit0);

	cout << "Octal: " << num << endl;
	cout << "Binary: " << bit2 << bit1 << bit0 << endl;
	
	return 0;
}

void octalBits(int n, bool &b2, bool &b1, bool &b0)
{	
	b2 = (n>3);
	b1 = (n/2)%2;
	b0 = n%2;
}
