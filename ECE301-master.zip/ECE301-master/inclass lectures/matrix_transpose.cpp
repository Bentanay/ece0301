#include <iostream>
using namespace std;

const int SIZE = 3;

void diag_swap(int[][SIZE], int, int);
void transpose(int[][SIZE]);

int main()
{
	int x[SIZE][SIZE] =  {	{1, 2, 3},
							{4, 5, 6},
							{7, 8, 9}  };
							
	cout << "Original Matrix:\n";
	for (int i=0; i<SIZE; i++)
	{
		for (int j=0; j<SIZE; j++)
			cout << x[i][j] << "  ";
		cout << "\n";
	}
	
	transpose(x);

	cout << "\nTransposed Matrix:\n";
	for (int i=0; i<SIZE; i++)
	{
		for (int j=0; j<SIZE; j++)
			cout << x[i][j] << "  ";
		cout << "\n";
	}
	
	return 0;
}

void diag_swap(int a[][SIZE], int i, int j)
{
	cout << "\nSwapping element (" << i << "," << j << ") ";
	cout << "with element ("<< j << "," << i << ")\n";
	cout << "a[" << i << "][" << j << "] = " << a[i][j] << "\n";
	cout << "a[" << j << "][" << i << "] = " << a[j][i] << "\n";

	int temp = a[i][j];
	a[i][j] = a[j][i];
	a[j][i] = temp;

	cout << "\na[" << i << "][" << j << "] = " << a[i][j] << "\n";
	cout << "a[" << j << "][" << i << "] = " << a[j][i] << "\n";
}

void transpose(int a[][SIZE])
{
	for(int i=0; i<SIZE; i++)
		for (int j=0; j<i; j++)
			diag_swap(a, i, j);
}
