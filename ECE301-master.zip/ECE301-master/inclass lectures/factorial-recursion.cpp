#include <iostream>
using namespace std;

int factorialrecur(int);
int factorial(int);

int main()
{
	int num;

	cin >> num;
	
	cout << "factorial " << num << " is: ";
	cout << factorialrecur(num) << endl;
	cout << factorial(num);
	
	return 0;
}

int factorialrecur(int n)
{
	int factorial =1;
	
	if(n>0){
		factorial *= n*factorialrecur(n-1);
	}
	return factorial;
}

int factorial(int n){
	
	int factorial = 1;
	while(n >0){
		factorial *= n;
		n--; 
	}
	return factorial;
	
}




