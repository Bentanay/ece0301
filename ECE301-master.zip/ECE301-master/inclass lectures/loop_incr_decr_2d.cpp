/*
	loop_incr_decr_2d.cpp
*/
#include <iostream>
using namespace std;

int main()
{
	int N = 5, n = 0, k;
	long int sum=0;
	
	while (n++ < N)
		for(k=n; --k>=0; k--)
		{
			sum += n*k;
			cout << "n = " << n << ", k = " << k
				<< ", sum = " << sum << endl;
		}
		
	return 0;
}


// n runs 5 times
// n = 1 k = 0 sum = 0
// n = 2 k = 1 sum = 2
// n = 3 k = 2 sum = 8
// n = 3 k = 0 sum = 8
// n = 4 k = 3 sum = 20
// n = 4 k = 1 sum = 24
// n = 5 k = 4 sum = 44
// n = 5 k = 2 sum = 54
// n = 5 k = 0 sum = 54

