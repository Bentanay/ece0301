#include <iostream>
using namespace std;

int main()
{
	int num;
	cout << "Please Enter a number betweeen 0 and 7:\n";
	cin >> num;
	if ( num<0 || num>7 )
	{
		cout << "ERROR!  Non-octal input.\n";
		return -1;
	}

	bool bit2, bit1, bit0;
	bit0 = (num >> 0) % 2;
	bit1 = (num >> 1) % 2;
	bit2 = (num >> 2) % 2;

	cout << "Octal: " << num << endl;
	cout << "Binary: " << bit2 << bit1 << bit0 << endl;
	
	return 0;
}
