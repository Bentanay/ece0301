/*
	loop_incr_decr_2c.cpp
*/
#include <iostream>
using namespace std;

int main()
{
	int N = 5, n = 0, k;
	long int sum=0;
	
	while (n++ < N)
		for(k=n; k-->=0; k--)
		{
			sum += n*k;
			cout << "n = " << n << ", k = " << k
				<< ", sum = " << sum << endl;
		}
		
	return 0;
}


/*
 * n runs 5 times
 * n = 1 k = 0 sum = 0
 * n = 2 k = 2 sum = 2
 * n = 2 k = 2 sum = 0
 * */
