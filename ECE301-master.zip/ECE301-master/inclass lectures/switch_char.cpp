#include <iostream>
using namespace std;

int main(int argc, char **argv)
{
	
	char c;
	
	cout << "Please enter a number betweeen a and c\n";
	
	cin >> c;
	
	switch(c)
	{
		case 'A':
		case 'a':
			cout << "You entered a\n";
			break;
			
		case 'B':	
		case 'b':
			cout << "You entered b\n";
			break;
		
		case 'C':	
		case 'c':
			cout << "You entered c\n";
			break;
		
		default:
			cout << "You chose a wrong number";
	}
	
	return 0;
}

