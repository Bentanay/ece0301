#include <iostream>
using namespace std;

int main(int argc, char **argv)
{
	
	int c;
	
	cout << "Please enter a number\n";
	
	cin >> c;
	
	switch(c>1)
	{
		case 1:
			cout << "True\n";
			break;
			
		case 0:
			cout << "False\n";
			break;
			
		default:
			cout << "You chose a wrong number";
	}
	
	return 0;
}

