#include <iostream>
using namespace std;

bool octalMSB(int);
bool octalMidBit(int);
bool octalLSB(int);

int main()
{
	int num;
	cout << "Please Enter a number betweeen 0 and 7:\n";
	cin >> num;

	if ( num<0 || num>7 )
	{
		cout << "ERROR!  Non-octal input.\n";
		return -1;
	}

	cout << "Octal: " << num << endl;
	cout << "Binary: " << octalMSB(num) << octalMidBit(num)
		<< octalLSB(num) << endl;
	
	return 0;
}

bool octalMSB(int n)
{	
	return n>3;
}

bool octalMidBit(int n)
{
	return (n/2)%2;
}

bool octalLSB(int n)
{	
	return n%2;
}
