/*
	loop_incr_decr_1b.cpp
*/
#include <iostream>
using namespace std;

int main()
{
	int N = 5, n = 0;
	long int sum=0;
	
	while (n++ < N)
	{
		sum += n;
		cout << "n = " << n << ", sum = " << sum << endl;
	}

	return 0;
}

//n=1 sum=1
//n=2 sum=3
//n=3 sum=6
//n=4 sum=10
//n=5 sum=15
