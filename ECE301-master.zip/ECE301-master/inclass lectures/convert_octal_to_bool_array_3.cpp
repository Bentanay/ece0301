#include <iostream>
using namespace std;

bool octalBit(int, int=0);

int main()
{
	int num;
	cout << "Please Enter a number betweeen 0 and 7:\n";
	cin >> num;
	if ( num<0 || num>7 )
	{
		cout << "ERROR!  Non-octal input.\n";
		return -1;
	}

	cout << "Octal: " << num << endl;
	cout << "Binary: " << octalBit(num,2) << octalBit(num,1)
		<< octalBit(num) << endl;
	
	return 0;
}

bool octalBit(int n, int index)
{	
	if (index == 2)
		return n>3;
	else if (index == 1)
		return (n/2)%2;
	else
		return n%2;
}
