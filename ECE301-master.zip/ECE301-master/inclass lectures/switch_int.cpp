#include <iostream>
using namespace std;

int main(int argc, char **argv)
{
	
	int c;
	
	cout << "Please enter a number betweeen 1 and 3\n";
	
	cin >> c;
	
	switch(c)
	{
		case 1:
			cout << "You entered 1\n";
			break;
			
		case 2:
			cout << "You entered 2\n";
			break;
			
		case 3:
			cout << "You entered 3\n";
			break;
		
		default:
			cout << "You chose a wrong number";
	}
	
	return 0;
}

