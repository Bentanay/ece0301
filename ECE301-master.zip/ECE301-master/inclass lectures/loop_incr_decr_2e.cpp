/*
	loop_incr_decr_2e.cpp
*/
#include <iostream>
using namespace std;

int main()
{
	int N = 5, n = 0, k;
	long int sum=0;
	
	while (n++ < N) //n=4
		for(k=0; ++k<=n; k++)
		{
			//
			//1+(
			++sum += n++*++k;
			cout << "n = " << ++n << ", k = " << k++
				<< ", sum = " << ++sum << endl;
		}
		
	return 0;
}


// n = 3 k = 2 sum = 4
// n = 6 k = 2 sum = 14
// n = 8 k = 6 sum = 52

