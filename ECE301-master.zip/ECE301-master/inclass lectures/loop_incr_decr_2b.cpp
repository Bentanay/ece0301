/*
	loop_incr_decr_2b.cpp
*/
#include <iostream>
using namespace std;

int main()
{
	int N = 5, n = 0, k;
	long int sum=0;
	
	while (n++ < N)
		for(k=n; k>=0; k--)
		{
			sum += n*k;
			cout << "n = " << n << ", k = " << k
				<< ", sum = " << sum << endl;
		}
		
	return 0;
}


