
/*Joe’s Pizza Palace needs a program to calculate the number of slices a pizza of any size can be divided into. The program 
 * should perform the following steps:
Ask the user for the diameter of the pizza in inches.
Calculate the number of slices that may be taken from a pizza of that size.
Display a message telling the number of slices.

To calculate the number of slices that may be taken from the pizza, you must know the following facts:

Each slice should have an area of 14.125 square inches. To calculate the number of slices, simply divide the area of t
* he pizza by 14.125. The area of the pizza is calculated with this formula: Area = "pi r squared" where pi is approximately 
* 3.14159 and r is the radius (half the the diameter).
* 
Sample Run

↵ →→→→Enter·pizza·diameter:10
↵ →→→→·5·slices
↵ →→→→
↵ →→→

*/

#include <iostream>
#include <cmath>
using namespace std;

int main(){
	double pdiameter, parea, numslices;
	const double pi = 3.14159, mustarea = 14.125;
	
	
	cout << "Enter pizza diameter: " ;
	cin >> pdiameter;
	
	parea = pi*pow(pdiameter/2,2);
	
	numslices = parea / mustarea;
	
	cout << static_cast<int>(numslices) << " slices";
	
	return 0;
}
