/*
Write a program that calculates the average rainfall for three months. The program should 
* ask the user to enter the name of each month, such as June or July, and the amount of rain (in inches) that 
* fell each month. The program should display a message similar to the following (please note the 2 decimal places 
* for the average rainfall):

The average rainfall for June, July, and August is 6.72 inches.

Sample Run

﻿Enter month: May
Enter rainfall for May: 15

Enter month: June
Enter rainfall for June: 8.33333
Enter month: July
Enter rainfall for July: 1.0000

The average rainfall for May, June, and July is 8.11 inches.

*/
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main(){
	string month1, month2, month3;
	double rainfall1,rainfall2, rainfall3;
	double average;
	
	
	cout << "Enter month: ";
	cin >> month1;
	cout << "Enter rainfall for " << month1 << ": ";
	cin >> rainfall1;
	
	cout << "Enter month: ";
	cin >> month2;
	cout << "Enter rainfall for " << month2 << ": ";
	cin >> rainfall2;
	
	cout << "Enter month: ";
	cin >> month3;
	cout << "Enter rainfall for " << month3 << ": ";
	cin >> rainfall3;
	
	average = (rainfall1 + rainfall2 + rainfall3)/3;
	
	cout <<setprecision(2) << fixed << "The average rainfall for May, June, and July is " << average << " inches.";
	
	
	
	
	return 0;
}
