#include <iostream>
#include <string>

using namespace std;


class Month{
	private:
		int month; 
		static string montharr[12]; 
	public: 
	Month(){
		month = 1; 
	}
	
	Month(int num){
		month = num; 
	}
	
	void setMonth(int num){
		month =num;
	}
	void setMonth(string str){
		for(int i =0; i< 12; i++){
			
			if(str == montharr[i]){
				month = i+1;
			}
		}
	}
	
	Month& operator++(){
		if(month == 12){
			month =1;
		}
		else{
			month++;
		}
		return *this;
	}
	Month& operator--(){
		if(month == 1){
			month =12;
		}
		else{
			month--;
		}
		return *this;
	}
	
	Month operator++(int){
		Month temp(month);
		++month;
		return temp;
	}
	
	Month operator--(int){
		Month temp(month);
		--month;
		return temp;
	}
	
	friend ostream& operator<< (ostream &streamy, Month &numobj);
	friend istream& operator>> (istream &streamy, Month &numobj);

	
};

	ostream& operator<< (ostream &streamy, Month &numobj){
		
		streamy << numobj.montharr[numobj.month-1];
		
		return streamy; 
	}
	istream& operator>> (istream &streamy, Month &numobj){
		
		streamy >> numobj.month;
		
		return streamy;  
	}


 string Month::montharr[12] = {"January","February","March","April","May","June","July","August","September","October","November","December"};


int main(){
	
	Month obj;
	
	
	
	cout << "Enter:";
	cin >> obj;
	
	
	
	cout << " month number (1-12):The next 8 months are: " << obj << ", ";
	
	for( int i =0; i <7; i++){
		if( i !=6){
			cout << ++obj << ", "; 
		}
		else{
			cout << ++obj << "."; 
		}
	}
	cout << endl;
	
	cout << "Enter:";
	cin >> obj;
	
	
	
	cout << " another month number (1-12):The previous 8 months were: " << obj << ", ";
	
	for( int i =0; i <7; i++){
		if( i !=6){
			cout << --obj << ", "; 
		}
		else{
			cout << --obj << "."; 
		}
	}
	cout << endl;

	
	
	
	
	return 0;
}

