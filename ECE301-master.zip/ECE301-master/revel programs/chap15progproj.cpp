#include <iostream>
#include <string>


using namespace std;



class PersonData{
	private:
		string lastName;
		string firstName;
		string address;
		string city;
		string state;
		string zip;
		string phone;
	public:
		string getlastname(){
			return lastName;
		}
		string getfirstname(){
			return firstName;
		}
		string getaddress(){
			return address;
		}
		string getcity(){
			return city;
		}
		string getstate(){
			return state;
		}
		string getzip(){
			return zip;
		}
		string getphone(){
			return phone;
		}


		void setlastname(string s){
			lastName = s;
		}
		void setfirstname(string s){
			 firstName = s;
		}
		void setaddress(string s){
			address = s;
		}
		void setcity(string s){
			 city =s;
		}
		void setstate(string s){
			state = s;
		}
		void setzip(string s){
			zip = s;
		}
		void setphone(string s){
			phone =s;
		}


};

class CustomerData: public PersonData{

	private:
		int customerNumber;
		bool mailingList;

	public:
		int getcustomernumber(){
			return customerNumber;
		}
		bool getmailinglist(){
			return mailingList;
		}


		void setcustomernumber(int s){
			customerNumber = s;
		}
		void setmailinglist(bool s){
			 mailingList = s;
		}
};




int main(){
	string temp;
	CustomerData customer1;
	cout << "Creating derived class or subclass CustomerData from base class PersonData with: \'CustomerData customer1;'\n";

	cout << "Enter customer's last name:";
	getline(cin,temp);
	customer1.setlastname(temp);
	cout << "customer1.setLastName(\"" << customer1.getlastname() << "\");\n";

	cout << "Enter customer\'s first name:";
	getline(cin,temp);
	customer1.setfirstname(temp);
	cout<<"customer1.setFirstName(\"" << customer1.getfirstname() << "\");\n";

	cout << "Enter customer\'s address:";
	getline(cin,temp);
	customer1.setaddress(temp);
	cout << "customer1.setAddress(\"" << customer1.getaddress() << "\");\n";

	cout << "Enter customer\'s City:";
	getline(cin,temp);
	customer1.setcity(temp);
	cout << "customer1.setCity(\"" << customer1.getcity() << "\");\n";

	cout << "Enter customer\'s State:";
	getline(cin,temp);
	customer1.setstate(temp);
	cout << "customer1.setState(\"" << customer1.getstate() << "\");\n";

	cout << "Enter customer\'s Zip:";
	getline(cin,temp);
	customer1.setzip(temp);
	cout << "customer1.setZip(" << customer1.getzip() << ");\n";

	cout << "Enter customer\'s Phone number:";
	getline(cin,temp);
	customer1.setphone(temp);
	cout << "customer1.setPhone(" << customer1.getphone() << ");\n";

	cout << "Enter customer\'s Customer Number:";
	getline(cin,temp);
	customer1.setcustomernumber(stod(temp));
	cout << "customer1.setCustomerNumber(" << customer1.getcustomernumber() << ");\n";

	cout << "Enter \'y\' if customer is on mailing listing list or \'n\' if not.";
	getline(cin,temp);
	if(temp == "y")
		customer1.setmailinglist(1);

	else
		customer1.setmailinglist(0);

	cout << "customer1.setMailingList("<< customer1.getmailinglist()<<");\n\n\n";



	cout << "Using all the get functions from both the base and derived class to show state of CustomerData object:\n";

	cout << "customer1.getLastName()= "<< customer1.getlastname() << endl;
	cout << "customer1.getFirstName()= "<< customer1.getfirstname() << endl;
	cout << "customer1.getAddress()= "<< customer1.getaddress() << endl;
	cout << "customer1.getCity()= "<< customer1.getcity() << endl;
	cout << "customer1.getState()= "<< customer1.getstate() << endl;
	cout << "customer1.getZip()= "<< customer1.getzip() << endl;
	cout << "customer1.getPhone()= "<< customer1.getphone() << endl;
	cout << "customer1.getCustomerNumber()= "<< customer1.getcustomernumber() << endl;
	cout << "customer1.getMailingList()= "<< boolalpha << customer1.getmailinglist() << "." << endl;

	



	return 0;
}
