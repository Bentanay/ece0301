#include <iostream>
#include <fstream>


int * arraything(int [], int);

using namespace std;

int main(){
	
	int N = 0;
	cin >> N;
	int arrayread[N];
	int *ptr = nullptr;
	
	if( !(N < 0 || N > 50)){
		
	
	
		ifstream input("data");
		
		for( int i = 0;  i < N; i++){
			input >> arrayread[i];
		}
		
		
		ptr = arraything(arrayread, N);
		
		for( int i = 0; i < N*2; i++){
			cout << ptr[i] << endl;
		
	}
	
	
	
	
		
	}
	return 0;
}

int * arraything(int array[], int SIZE){
	
	int *ptr = new int[SIZE*2];
	
	for(int i = 0; i < SIZE*2; i++){
		if( i < SIZE){
			ptr[i] = array[i];
		}
		else{
			ptr[i] = 0;
		}
	}
	
	return ptr;
} 
