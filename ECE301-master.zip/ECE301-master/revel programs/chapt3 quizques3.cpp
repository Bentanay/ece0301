/*
Write a program that plays a word game with the user. The program should ask the user to enter the following:
His or her name
The name of a city
His or her age
The name of a college
A profession
A type of animal
A pet’s name
After the user has entered these items, the program should display the following story, inserting the user’s input into the appropriate locations:

There once was a person named name who lived in city. At the age of age,
*  name went to college at college. name graduated and went to work as a profession. Then, name 
* adopted a(n) animal named petname. They both lived happily ever after!

Sample Run

↵ →→→→·Enter·name:Al·Smith
↵ →→→→·Enter·city:Brooklyn
↵ →→→→·Enter·age:43
↵ →→→→·Enter·college:School·of·Hard·Knocks
↵ →→→→·Enter·profession:Politician
↵ →→→→·Enter·animal:Pitbull
↵ →→→→·Enter·pet·name:Toodles
↵ →→→→·
↵ →→→→
↵ →→→→There·once·was·a·person·named·Al·Smith·who·lived·in·Brooklyn.
↵ →→→→At·the·age·of·43,·Al·Smith·went·to·college·at·School·of·Hard·Knocks.
↵ →→→→Al·Smith·graduated·and·went·to·work·as·a·Politician.
↵ →→→→Then,·Al·Smith·adopted·a(n)·Pitbull·named·Toodles.
↵ →→→→They·both·lived·happily·ever·after!
↵ →→→→
↵ →→→→
↵ →→→

*/

#include <iostream>
#include <mgl2/mgl.h>
using namespace std;

int main()
{
	string name, city, age, college, profession, animal, petname;
	
	cout << "Enter name: "; getline(cin,name);
	cout << "Enter city: "; getline(cin,city);
	cout << "Enter age: "; cin >> age; 
	cin.ignore();
	cout << "Enter college: "; getline(cin,college);
	cout << "Enter profession: "; getline(cin,profession);
	cout << "Enter animal: "; getline(cin,animal);
	cout << "Enter pet name: "; getline(cin,petname);
	cout << endl << endl;
	
	cout << "There once was a person named " << name << " who lived in " << city << ".\n";
	cout << "At the age of " << age << ", "<< name << " went to college at " <<college << ".\n";
	cout << name << " graduated and went to work as a " << profession << ".\n";
	cout << "Then, " << name << " adopted a(n) " << animal << " named " << petname << ".\n";
	cout << "They both lived happily ever after!";
	
	
	return 0;
}
