#include <iostream>
#include <fstream>
#include <vector>
using std::cout;
using std::endl;
using std::vector;

int * arrayfunc(int *, int);

int main(){
  ifstream textin("data");
  int N;
  textin >> N;
  if(N < 0 || N > 50){
    exit(0);
  }
  int *array = new int[N];
  for(int i =0; i < N; i++){
    textin >> *(array+i);

  }
  int * newarr = arrayfunc(array,N);

  for (int i = 0; i < N*2; i++) {
    cout << *(newarr+i);
  }





  return 0;
}

int * arrayfunc(int * arr, int size){
  int * arrptr = new int[size*2];

  for(int i =0; i < size*2; i++){
    if(i < size){
        *(arrptr+i) = arr[i];

    } else{
      *(arrptr+i) = 0;
    }


  }
  return arrptr;


}

vector<double>fun{4,3,2,2,3};
vector<double>fun2(10,0);
fun2.resize(14,4);
cout << fun2[4];
fun.push_back(2);
fun.pop_back(3);
//check these
